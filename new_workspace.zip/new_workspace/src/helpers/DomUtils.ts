import { v4 } from 'uuid';
import React from 'react';

export function convertTemplateId(templateId: string) {
  return templateId.toString().toLowerCase().trim().replaceAll("'", '').replaceAll('&', '').replaceAll(' ', '-').replaceAll('(', '-').replaceAll(')', '-').replaceAll('+', '-');
}

function handler() {
  const mfeContainer = (entrypoint?: string, sectionId?: string | null) => {
    const id: string = ((entrypoint ? entrypoint : '') + (sectionId ? `_${sectionId}` : '')).replaceAll(' ', '_').replaceAll("'", '_').replaceAll('+', '_').replaceAll('@', '_').replaceAll('.', '_').replaceAll('-', '_');
    return `a-${id.toString().toLowerCase()}-a`;
  };

  const addRemoveControlTowerClassOnBody = (className: string) => {
    let cls: string = document.body.getAttribute('class') || '';

    cls = cls.replaceAll('control-tower-cls', '');
    if (className.indexOf('BuildMap') >= 0 || document.getElementById('a-buildmap-a')) cls = `${cls ? cls + ' ' : ''}control-tower-cls`;

    document.body.setAttribute('class', cls);
  };

  const getMfeClassName = (entrypoint: string, sectionId?: string) => {
    return `head_element_${entrypoint}${sectionId && `_${convertTemplateId(sectionId)}`}_${v4()}`;
  };

  const createScript = (className: string, entrypoint: string, scriptPath: string, sectionId?: string, jsonData?: string) => {
    console.log('Unused jsonData', jsonData);
    const script = document.createElement('script');
    script.className = className;
    script.crossOrigin = '';
    script.setAttribute('app-name', mfeContainer(entrypoint, sectionId));
    script.setAttribute('src-uuid', v4());
    if (sectionId) script.setAttribute('sectionId', sectionId);
    script.src = `${scriptPath}`;
    return script;
  };

  const createStyle = (className: string, scriptPath: string) => {
    const link = document.createElement('link');
    link.className = className;
    link.href = `${scriptPath}`;
    link.rel = 'stylesheet';
    return link;
  };

  const bindScript = (scriptObject: any) => {
    document.head.appendChild(scriptObject);
  };

  const bindStyle = (styleObject: any) => {
    document.head.appendChild(styleObject);
  };

  const bindEntryPoints = (otherEntrypoints: any, className: string, path: string, entrypoint: string, sectionId?: string, jsonData?: string) => {
    const entrypointFiles: string[] = otherEntrypoints[entrypoint];

    addRemoveControlTowerClassOnBody(className);
    entrypointFiles.forEach(filePath => {
      if (filePath.endsWith('.js')) {
        bindScript(createScript(className, entrypoint, `${path}/${filePath}`, sectionId, jsonData));
      }

      if (filePath.endsWith('.css')) {
        bindStyle(DomUtils.createStyle(className, `${path}/${filePath}`));
      }
    });
  };

  const unMountHtml = (className: string) => {
    document.querySelectorAll(`.${className}`).forEach(o => {
      if (o.tagName.toUpperCase() === 'SCRIPT' && o.getAttribute('src')) {
        document.dispatchEvent(new CustomEvent(`veronica-script-unmount-${o.getAttribute('src')}-${o.getAttribute('app-name')}-${o.getAttribute('src-uuid')}`));
      }
      o && o.remove();
    });
  };

  const getModaMfeContainer = (elementId: string, element: JSX.Element) => {
    return React.createElement('div', { id: elementId, className: 'p-dialog-mask p-dialog-visible p-dialog-draggable p-dialog-resizable single-modal-mask p-dialog-center p-dailog-focus p-dailog-active' }, element);
  };

  return {
    mfeContainer,
    getMfeClassName,
    createScript,
    createStyle,
    bindScript,
    bindStyle,
    bindEntryPoints,
    unMountHtml,
    getModaMfeContainer,
  };
}

export const DomUtils = handler();
