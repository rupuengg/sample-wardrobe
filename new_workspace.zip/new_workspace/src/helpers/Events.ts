export enum E_Type_Of_Event {
  MODAL_EVENT = 'onModalEventChange',
  INVENTORY_SEARCH_EVENT = 'onInventorySearchChange',
  MOVEMENT_SEARCH_EVENT = 'onMovementSearchChange',
  NOTIFICATION_MESSAGE_EVENT = 'onNotificationMessageChange',
  WORLSPACE_MENU_EVENT = 'onWorkspaceMenuChange',
  DATA_MANAGEMENT_EVENT = 'onDataManagementEventChange',
}

export enum E_Custom_Dispatch_Event {
  // Modal Action
  MODAL_OPEN = 'MODAL_OPEN',
  MODAL_CLOSE = 'MODAL_CLOSE',
  MODAL_FULL_SCREEN_MODE = 'MODAL_FULL_SCREEN_MODE',

  TEMPLATE_SHOW = 'TEMPLATE_SHOW',
  TEMPLATE_LIST_SHOW = 'TEMPLATE_LIST_SHOW',
  CLOSE_TEMPLATE = 'CLOSE_TEMPLATE',
  SAVE_UPDATE_TEMPLATE = 'SAVE_UPDATE_TEMPLATE',
  OPEN_FROM_MORE = 'OPEN_FROM_MORE',
  AUTO_REFRESH = 'AUTO_REFRESH',
  CELL_UPDATE_ONLY = 'CELL_UPDATE_ONLY',

  // Inventory Event Action
  INVENTORY_MODAL_MAXIMIZE = 'INVENTORY_MODAL_MAXIMIZE',
  INVENTORY_MODAL_BACK_TO_LIST = 'INVENTORY_MODAL_BACK_TO_LIST',
  INVENTORY_EDIT_CRITERIA = 'INVENTORY_EDIT_CRITERIA',
  INVENTORY_DIRECTORY_OPEN = 'INVENTORY_DIRECTORY_OPEN',
  INVENTORY_PREFERENCE_ACTION = 'INVENTORY_PREFERENCE_ACTION',

  // Notification Message Action
  NOTIFICATION_MESSAGE_SHOW = 'NOTIFICATION_MESSAGE_SHOW',

  // Workspace Menu Change Action
  WORKSPACE_MENU_CHANGE = 'WORKSPACE_MENU_CHANGE',

  // Data Management Change Action
  DM_OPEN_NEW_MFE = 'DM_OPEN_NEW_MFE',
  DM_CLOSE_NEW_MFE = 'DM_CLOSE_NEW_MFE',
  DM_LIVE_USER_UNREAD_MESSAGE_COUNT = 'DM_LIVE_USER_UNREAD_MESSAGE_COUNT',
}

export function customDispatchEvent(typeOfAction: E_Type_Of_Event, action: E_Custom_Dispatch_Event, data: any) {
  document.dispatchEvent(new CustomEvent(typeOfAction, { detail: { action, data } }));
}

export function customEventListener(eventType: E_Type_Of_Event, listener: EventListener) {
  document.addEventListener(eventType, listener);

  return () => {
    document.removeEventListener(eventType, listener);
  };
}
