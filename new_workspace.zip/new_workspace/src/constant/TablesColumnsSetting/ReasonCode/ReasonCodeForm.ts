import { DropdownOptions, GroupCheckboxProps, GroupRadioButtonProp } from 'veronica-ui-component/dist/component/core';

export const reasonCodeRequiredFieldList: string[] = ['type', 'code'];

// Reason Code field options
export const typeDropdownOptions: DropdownOptions[] = [
  { dropdownLabel: 'Terminal Equipment Go Slow Reason', tagLabel: 'Terminal Equipment Go Slow Reason', value: 'terminalEquipmentGoSlowReason' },
  { dropdownLabel: 'Delay Reason', tagLabel: 'Delay Reason', value: 'delayReason' },
  { dropdownLabel: 'Reason for Problem Tractor/ Invalid Entry', tagLabel: 'Reason for Problem Tractor/ Invalid Entry', value: 'gateProblemReason' },
  { dropdownLabel: 'IT Suspend Reason', tagLabel: 'IT Suspend Reason', value: 'itSuspendReason' },
  { dropdownLabel: 'Crane Delay', tagLabel: 'Crane Delay', value: 'craneDelay' },
  { dropdownLabel: 'Unavailable Area Reason', tagLabel: 'Unavailable Area Reason', value: 'unavailableAreaReason' },
  { dropdownLabel: 'YC Suspend Reason', tagLabel: 'IT Suspend Reason', value: 'ycSuspendReason' },
];

// Reason Code field options
export const delayReasonCategoryDropdownOptions: DropdownOptions[] = [
  { dropdownLabel: 'All', tagLabel: 'All', value: 'all' },
  { dropdownLabel: 'ETA Delay', tagLabel: 'ETA Delay', value: 'eta' },
  { dropdownLabel: 'ETB Delay', tagLabel: 'ETB Delay', value: 'etb' },
  { dropdownLabel: 'ETD Delay', tagLabel: 'ETD Delay', value: 'etd' },
  { dropdownLabel: 'Report Delay', tagLabel: 'Report Delay', value: 'brp' },
  { dropdownLabel: 'Arrange Delay', tagLabel: 'Arrange Delay', value: 'bat' },
  { dropdownLabel: 'Change Berth Terminal', tagLabel: 'Change Berth Terminal', value: 'cbt' },
];

export const goSlowCodeApplyToRadioOptions: GroupRadioButtonProp[] = [
  {
    inputId: 1,
    key: 'IT',
    name: 'Internal Tractor',
  },
  {
    inputId: 2,
    key: 'QC',
    name: 'Quay Crane',
  },
  {
    inputId: 3,
    key: 'YC',
    name: 'Yard Crane',
  },
];

export const delayReasonApplyToCheckBoxOptions: GroupCheckboxProps[] = [
  {
    name: 'Voyage',
    key: 'vsl',
  },
  {
    name: 'Barge',
    key: 'bar',
  },
];

export const craneDelayCodeApplyToRadioOption: GroupRadioButtonProp[] = [
  {
    inputId: 1,
    key: 'Terminal',
    name: 'Terminal',
  },
  {
    inputId: 2,
    key: 'Shipping Line',
    name: 'Shipping Line',
  },
];
export const unavailableCodeApplyToCheckBoxOptions: GroupCheckboxProps[] = [
  {
    name: 'Unavailable Berth',
    key: 'Unavailable Berth',
  },
  {
    name: 'Unavailable Quay Crane',
    key: 'Unavailable Quay Crane',
  },
  {
    name: 'Unavailable Yard Area',
    key: 'Unavailable Yard Area',
  },
];
