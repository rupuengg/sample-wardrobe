import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { ReasonCodeEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

export function getReasonCodeColumnSetting(anaInfo?: ANAInfoModel): (ColDef<ReasonCodeEntity> | ColGroupDef<ReasonCodeEntity>)[] {
  return [
    {
      field: 'typeString',
      headerName: 'Type',
      width: 260,
    },
    {
      field: 'categoryString',
      headerName: 'Category',
      width: 260,
    },
    {
      field: 'code',
      headerName: 'Code',
      width: 160,
      pinned: 'left',
    },
    {
      field: 'description',
      headerName: 'Description',
      width: 160,
    },
    {
      field: 'applyToString',
      headerName: 'Apply To',
      width: 300,
    },
    {
      field: 'kiosk',
      headerName: 'Kiosk',
      width: 110,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<ReasonCodeEntity> | ColGroupDef<ReasonCodeEntity>)[]),
  ];
}
