import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { GateQueueEntity } from 'entities';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';
import { GateQueueConstants } from './GateQueueConstants';

// export const gateQueueCellRenderer = (params: any, fieldKey: string) => {
//     // console.log(params, fieldKey);
//     const clsKey: string = fieldKey + 'Class';
//     let icon: JSX.Element = <></>;
//     if (fieldKey === 'totalWaiting') {
//         return <span className='gate-yard-complete'>
//             <span className={`gate-queue-cell ${params.data[clsKey]}`}>{params.data[fieldKey]}</span>
//             {
//                 params.data[clsKey].toString().trim() !== '' &&
//                 <IconButton fileName="Icon-alert" size="small" toolTipPlacement='left' tooltipDisable={false} toolTipText={GateQueueConstants.WAITING.ALERT_TOOLTIP_TEXT.replaceAll('{xx}', params.data.totalWaitingText.toString())} onClick={() => { }} />
//             }
//         </span>;
//     }

//     return <span className='gate-yard-complete'><span className={`gate-queue-cell ${params.data[clsKey]}`}><span className={`circle ${params.data[clsKey]}`}></span>{params.data[fieldKey]}</span>{icon}</span>;
// }

export function getGateQueueMaintenanceColumnSetting(anaInfo?: ANAInfoModel): (ColDef<GateQueueEntity> | ColGroupDef<GateQueueEntity>)[] {
  return [
    {
      field: 'terminal',
      headerName: GateQueueConstants.FIELDS.TERMINAL_SHORT,
      width: 90,
    },
    {
      field: 'yardZone',
      headerName: GateQueueConstants.FIELDS.YARD_ZONE,
      width: 150,
    },
    {
      field: 'cmsNo',
      headerName: GateQueueConstants.FIELDS.CMS_NO,
      width: 140,
    },
    {
      field: 'groundType',
      headerName: GateQueueConstants.FIELDS.GROUND_TYPE,
      width: 140,
    },
    {
      field: 'tractorNo',
      headerName: GateQueueConstants.FIELDS.TRACTOR_NO,
      width: 125,
    },
    {
      field: 'tractorZoneText',
      headerName: GateQueueConstants.FIELDS.TRACTOR_ZONE,
      width: 130,
    },
    {
      field: 'gateIn',
      headerName: GateQueueConstants.FIELDS.GATE_IN_MIN,
      width: 140,
      //   cellRenderer: (params: any) => gateQueueCellRenderer(params, 'gateIn'),
      //   dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'gateQueue',
      headerName: GateQueueConstants.FIELDS.GATE_QUEUE_MIN,
      width: 160,
      //   cellRenderer: (params: any) => gateQueueCellRenderer(params, 'gateQueue'),
      //   dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'pending',
      headerName: GateQueueConstants.FIELDS.PENDING,
      width: 150,
      //   cellRenderer: (params: any) => gateQueueCellRenderer(params, 'pending'),
      //   dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'active',
      headerName: GateQueueConstants.FIELDS.ACTIVE,
      width: 140,
      //   cellRenderer: (params: any) => gateQueueCellRenderer(params, 'active'),
      //   dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'hot',
      headerName: GateQueueConstants.FIELDS.HOT,
      width: 120,
      //   cellRenderer: (params: any) => gateQueueCellRenderer(params, 'hot'),
      //   dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'yardComplete',
      headerName: GateQueueConstants.FIELDS.YARD_COMPLETE,
      width: 190,
      //   cellRenderer: (params: any) => gateQueueCellRenderer(params, 'yardComplete'),
      //   dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'totalWaiting',
      headerName: GateQueueConstants.FIELDS.TOTAL_WAITING,
      width: 180,
      //   cellRenderer: (params: any) => gateQueueCellRenderer(params, 'totalWaiting'),
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'location',
      headerName: GateQueueConstants.FIELDS.LOCATION, //Location (location display A1/20)
      width: 140,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<GateQueueEntity> | ColGroupDef<GateQueueEntity>)[]),
  ];
}
