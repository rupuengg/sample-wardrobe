import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { GradeCodeEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';
import { GradeCodeConstants } from './gradeCodeConstants';

export function getGradeCodeColumnSetting(anaInfo?: ANAInfoModel): (ColDef<GradeCodeEntity> | ColGroupDef<GradeCodeEntity>)[] {
  return [
    {
      field: 'code',
      headerName: GradeCodeConstants.FIELD.CODE,
      width: 160,
      pinned: 'left',
    },
    {
      field: 'description',
      headerName: GradeCodeConstants.FIELD.DESCRIPTON,
      width: 160,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<GradeCodeEntity> | ColGroupDef<GradeCodeEntity>)[]),
  ];
}
