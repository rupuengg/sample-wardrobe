export const GradeCodeConstants = {
  TITLE: {
    HEADER: 'Grade Code',
    NEW: 'NEW GRADE CODE',
  },
  FIELD: {
    CODE: 'Code',
    DESCRIPTON: 'Description',
  },
  ERROR: {
    CODE: 'Code is mandatory',
    DESCRIPTON: 'Description is mandatory',
  },
};
