export const gradeCodeRequiredFieldList: string[] = ['code'];
