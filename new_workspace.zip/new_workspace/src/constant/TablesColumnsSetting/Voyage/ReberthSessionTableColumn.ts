import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { ReberthSessionEntity } from 'entities';
import { E_Renderer_Type } from 'enums';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';

export function getReberthSessionColumnSetting(anaInfo?: ANAInfoModel): (ColDef<ReberthSessionEntity> | ColGroupDef<ReberthSessionEntity>)[] {
  return [
    {
      field: 'id',
      headerName: 'ID',
      width: 100,
    },
    {
      field: 'arrivalDate',
      headerName: 'Arrival Date Time',
      cellDataType: E_Renderer_Type.DATE,
      width: 160,
    },
    {
      field: 'berthDate',
      headerName: 'Berthing Date Time',
      cellDataType: E_Renderer_Type.DATE,
      width: 160,
    },
    {
      field: 'departureDate',
      headerName: 'Departure Date Time',
      cellDataType: E_Renderer_Type.DATE,
      width: 160,
    },
    {
      field: 'berthingTerminal',
      headerName: 'Berthing Terminal',
      width: 150,
    },
    {
      field: 'berthingBridge',
      headerName: 'Berthing Bridge',
      width: 150,
    },
    {
      field: 'startBitt',
      headerName: 'Start Bitt',
      width: 100,
      //   dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'endBitt',
      headerName: 'End Bitt',
      width: 100,
      //   dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'quayCrane',
      headerName: 'Quay Crane',
      width: 150,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<ReberthSessionEntity> | ColGroupDef<ReberthSessionEntity>)[]),
  ];
}
