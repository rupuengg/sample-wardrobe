import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef, ValueGetterParams } from 'ag-grid-community';
import { VoyageEntity } from 'entities';
import { E_Renderer_Type } from 'enums';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';

const dualVoyageRenderer = (params: { [x: string]: any }) => {
  const dualVoyageCompCode = params?.data?.dualVoyageCompCode ?? '-';
  const dualVoyageVslCode = params?.data?.dualVoyageVslCode ?? '-';
  const dualVoyageCode = params?.data?.dualVoyageCode ?? '-';

  if (dualVoyageCompCode === '-' && dualVoyageVslCode === '-' && dualVoyageCode === '-') {
    return '';
  } else {
    return `${dualVoyageCompCode}/${dualVoyageVslCode}/${dualVoyageCode}`;
  }
};

export function getVoyageColumnSetting(anaInfo?: ANAInfoModel): (ColDef<VoyageEntity> | ColGroupDef<VoyageEntity>)[] {
  return [
    {
      field: 'coVslVoy',
      headerName: 'Co/Vsl/Voy',
      width: 160,
      valueGetter: (params: ValueGetterParams) => {
        return `${params.data.voyageCompCode}/${params.data.voyageVslCode}/${params.data.voyageCode}`;
      },
      pinned: 'left',
    },
    {
      field: 'vesselName',
      headerName: 'Vessel Name',
      width: 160,
    },
    {
      field: 'serviceCode',
      headerName: 'Service Code',
      width: 160,
    },
    {
      field: 'soa',
      headerName: 'SOA',
      width: 100,
    },
    {
      field: 'voyageStatus',
      headerName: 'Voyage Status',
      width: 170,
    },
    {
      field: 'arrivalDateTime',
      headerName: 'ETA',
      cellDataType: E_Renderer_Type.DATE,
      width: 160,
    },
    {
      field: 'berthingDateTime',
      headerName: 'ETB',
      cellDataType: E_Renderer_Type.DATE,
      width: 160,
    },
    {
      field: 'departureDateTime',
      headerName: 'ETD',
      cellDataType: E_Renderer_Type.DATE,
      width: 160,
    },
    {
      field: 'berthingTerminal',
      headerName: 'Berthing Terminal',
    },
    {
      field: 'berthingBridge',
      headerName: 'Berthing Bridge',
    },
    {
      field: 'subBerthId',
      headerName: 'Sub Berth',
    },
    {
      field: 'side',
      headerName: 'Berth Side',
    },
    {
      field: 'vesselBoardingAgent',
      headerName: 'Vessel Agent',
    },
    {
      field: '',
      headerName: 'Dual Voyage',
      valueGetter: (params: ValueGetterParams) => {
        return dualVoyageRenderer(params);
      },
    },
    {
      field: 'pilotName',
      headerName: 'Pilot On Board',
    },
    {
      field: 'prevPod',
      headerName: 'Previous Port',
    },
    {
      field: 'nextPod',
      headerName: 'Next Port',
    },
    {
      field: 'bunkeringHours',
      headerName: 'Bunkering Hours',
      //   dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'startBitt',
      headerName: 'Start Bollard',
      //   dataType: 'number',
      comparator: numberComparator,
      valueGetter: (params: ValueGetterParams) => {
        return (parseFloat(params.data.bollardFrom || '0') + parseFloat(params.data.startBittNextBittPortion || '0.0')).toString();
      },
    },
    {
      field: 'endBitt',
      headerName: 'End Bollard',
      //   dataType: 'number',
      comparator: numberComparator,
      valueGetter: (params: ValueGetterParams) => {
        return (parseFloat(params.data.bollardTo || '0') + parseFloat(params.data.endBittNextBittPortion || '0.0')).toString();
      },
    },
    {
      field: 'targetQcRate',
      headerName: 'QCR (mph)',
      //   dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'qcIdsText',
      headerName: 'Assigned QC',
      valueGetter: (params: ValueGetterParams) => {
        return params.data?.qcIds?.filter((i: string) => i !== '')?.join(', ');
      },
    },
    {
      field: 'specialArrangements',
      headerName: 'Special Arrangement',
    },
    {
      field: 'remarks',
      headerName: 'Remarks',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<VoyageEntity> | ColGroupDef<VoyageEntity>)[]),
  ];
}
