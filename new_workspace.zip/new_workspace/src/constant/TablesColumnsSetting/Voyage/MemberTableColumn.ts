import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { MemberEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

export function getVoyageMemberColumnSetting(anaInfo?: ANAInfoModel): (ColDef<MemberEntity> | ColGroupDef<MemberEntity>)[] {
  return [
    {
      field: 'memberSlotBuyer',
      headerName: 'Member/Slot Buyer',
      width: 160,
    },
    {
      field: 'memberRegion',
      headerName: 'Member Region',
      width: 160,
    },
    {
      field: 'slotProvider',
      headerName: 'Slot Provider',
      width: 160,
    },
    {
      field: 'slotProviderRegion',
      headerName: 'Slot Provider Region',
      width: 160,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<MemberEntity> | ColGroupDef<MemberEntity>)[]),
  ];
}
