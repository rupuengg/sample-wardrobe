import { DropdownOptions, GroupCheckboxProps, GroupRadioButtonProp } from 'veronica-ui-component/dist/component/core';

export const voyageGeneralInformationRequiredFieldList: string[] = [
  'voyageCompCode',
  'voyageVslCode',
  'voyageCode',
  'serviceCode',
  'soa',
  'voyageStatus',
  'operationMode',
  'arrivalDateTime',
  'berthingDateTime',
  'departureDateTime',
  'berthingTerminal',
  'berthingBridge',
  'side',
];

export const memberRequiredFieldList: string[] = ['memberSlotBuyer'];

export const reberthRequiredFieldList: string[] = ['id', 'arrivalDate', 'berthDate', 'departureDate', 'berthingTerminal', 'berthingBridge', 'startBitt', 'endBitt'];

export const voyageStatusRadioOption: GroupRadioButtonProp[] = [
  { inputId: 1, key: 'Open', name: 'Open' },
  { inputId: 2, key: 'Close', name: 'Close' },
  { inputId: 3, key: 'Freeze', name: 'Freeze' },
];

export const voyageOperationModeRadioOption: GroupRadioButtonProp[] = [
  { inputId: 1, key: 'Vessel', name: 'Vessel' },
  { inputId: 2, key: 'MIDStream', name: 'MIDStream' },
  { inputId: 3, key: 'Barge', name: 'Barge' },
];

export const voyageDualTypeDropdownOption: DropdownOptions[] = [
  { dropdownLabel: 'DS-Discharge', tagLabel: 'DS', value: 'DS' },
  { dropdownLabel: 'LD-Loading', tagLabel: 'LD', value: 'LD' },
];

export const voyageDestinDropdownOption: DropdownOptions[] = [
  { dropdownLabel: 'Yes', tagLabel: 'O1', value: 'Yes' },
  { dropdownLabel: 'No', tagLabel: 'O2', value: 'No' },
];

export const voyageScheduleStatusDropdownOption: DropdownOptions[] = [
  { dropdownLabel: 'Confirmed', tagLabel: 'O1', value: 'Confirmed' },
  { dropdownLabel: 'Finalized', tagLabel: 'O2', value: 'Finalized' },
];

export const voyageSideRadioOption: GroupRadioButtonProp[] = [
  { inputId: 1, key: 'Port', name: 'Port' },
  { inputId: 2, key: 'Starboard', name: 'Starboard' },
];

export const voyageFreezeCheckboxOption: GroupCheckboxProps[] = [{ key: 'freeze', name: '', disabled: false }];

export interface VoyageGeneralInformationDynamicDropdownOptions {
  serviceDropdownOption: { [key: string]: DropdownOptions[] };
  soaDropdownOptions: DropdownOptions[];
  terminalDropdownOptions: DropdownOptions[];
  berthDropdownOptions: DropdownOptions[];
  subBerthDropdownOptions: { [key: string]: DropdownOptions[] };
  pilotOnBoardDropdownOptions: DropdownOptions[];
  quayCraneDropdownOptions: DropdownOptions[];
  lineDropdownOption: DropdownOptions[];
  regionDropdownOption: { [key: string]: DropdownOptions[] };
  splArrangementDropdownOption: DropdownOptions[];
}
