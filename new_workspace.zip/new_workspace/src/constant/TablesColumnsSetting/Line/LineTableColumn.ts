import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { LineEntity } from 'entities';
import { E_Renderer_Type } from 'enums';
import { ANAInfoModel } from 'module/Ana';

export function getLineColumnSetting(anaInfo?: ANAInfoModel): (ColDef<LineEntity> | ColGroupDef<LineEntity>)[] {
  return [
    {
      field: 'lineCode',
      headerName: 'Line Code',
      minWidth: 103,
      pinned: 'left',
    },
    {
      field: 'lineCompanyName',
      headerName: 'Name',
    },
    {
      field: 'localName',
      headerName: 'Local Name',
    },
    {
      field: 'agentName',
      headerName: 'Agent',
    },
    {
      field: 'lineCategory',
      headerName: 'Type',
      minWidth: 125,
    },
    {
      field: 'contractual',
      headerName: 'Contractual',
      minWidth: 150,
      cellDataType: E_Renderer_Type.TICK,
    },
    {
      field: 'contractOperationUnit',
      headerName: 'Contract Operator',
    },
    {
      field: 'color',
      headerName: 'Color',
      minWidth: 104,
      cellDataType: E_Renderer_Type.COLOR,
    },
    {
      field: 'phoneNo',
      headerName: 'Phone',
    },
    {
      field: 'emailAddress',
      headerName: 'Email',
    },
    {
      field: 'address',
      headerName: 'Address',
    },
    {
      field: 'remark',
      headerName: 'Remark',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<LineEntity> | ColGroupDef<LineEntity>)[]),
  ];
}
