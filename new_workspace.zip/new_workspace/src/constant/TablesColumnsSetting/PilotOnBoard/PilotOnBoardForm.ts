import { GroupCheckboxProps } from 'veronica-ui-component/dist/component/core';

export const isDefaultCheckboxOption: GroupCheckboxProps[] = [{ key: 'isDefault', name: '' }];
export const pilotOnBoardRequiredFieldList: string[] = ['pilotOnBoard', 'timeToBerthHr', 'isDefault'];
