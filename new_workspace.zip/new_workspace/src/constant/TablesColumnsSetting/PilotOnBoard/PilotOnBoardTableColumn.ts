import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { PilotOnBoardEntity } from 'entities';
import { E_Renderer_Type } from 'enums';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';

export function getPilotOnBoardColumnSetting(anaInfo?: ANAInfoModel): (ColDef<PilotOnBoardEntity> | ColGroupDef<PilotOnBoardEntity>)[] {
  return [
    {
      field: 'pilotOnBoard',
      headerName: 'Pilot On Board',
    },
    {
      field: 'description',
      headerName: 'Description',
    },
    {
      field: 'timeToBerthHr',
      headerName: 'Time To Berth (Hour)',
      cellDataType: E_Renderer_Type.TICK,
      comparator: numberComparator,
    },
    {
      field: 'isDefault',
      headerName: 'Default',
      cellDataType: E_Renderer_Type.TICK,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<PilotOnBoardEntity> | ColGroupDef<PilotOnBoardEntity>)[]),
  ];
}
