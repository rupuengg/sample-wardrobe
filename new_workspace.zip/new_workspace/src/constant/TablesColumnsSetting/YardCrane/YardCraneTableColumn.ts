import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { YardCraneEntity } from 'entities';
import { E_Renderer_Type } from 'enums';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';

export function getYardCraneColumnSetting(anaInfo?: ANAInfoModel): (ColDef<YardCraneEntity> | ColGroupDef<YardCraneEntity>)[] {
  return [
    {
      field: 'yardCraneNo',
      headerName: 'Yard Crane No.',
      pinned: 'left',
    },
    {
      field: 'yardCraneTypeText',
      headerName: 'Type',
    },
    {
      field: 'yardCraneSubType',
      headerName: 'Subtype',
    },
    {
      field: 'heightLimitInFeet',
      headerName: 'Height Limit (Feet)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'stackableHeightInFeet',
      headerName: 'Stackable Height (Feet)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'operationMode',
      headerName: 'Operation Mode',
    },
    {
      field: 'isVgmCertified',
      headerName: 'VGM Certified',
      cellDataType: E_Renderer_Type.TICK,
    },
    {
      field: 'isTieDown',
      headerName: 'Tie Down',
      cellDataType: E_Renderer_Type.TICK,
    },
    {
      field: 'maintenance',
      headerName: 'Maintenance',
    },
    {
      field: 'specialHandlingList',
      headerName: 'Special Handling',
    },
    {
      field: 'servingArea',
      headerName: 'Serving Area',
    },
    {
      field: 'workloadLimit',
      headerName: 'Workload Limit (no. of moves)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'containerWidthLimitInFeet',
      headerName: 'Container Width Limit (Feet)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<YardCraneEntity> | ColGroupDef<YardCraneEntity>)[]),
  ];
}
