import { DropdownOptions, GroupCheckboxProps, GroupRadioButtonProp, GroupRadioList } from 'veronica-ui-component/dist/component/core';

export const yardCraneTypeRadioOption: GroupRadioList[] = [
  {
    inputId: 1,
    key: 'Automatic Stacking Crane',
    name: 'Automatic Stacking Crane',
  },
  {
    inputId: 2,
    key: 'Bridge Crane',
    name: 'Bridge Crane',
  },
  {
    inputId: 'M',
    key: 'M',
    name: 'Rail Mounted Crane',
  },
  {
    inputId: 'T',
    key: 'T',
    name: 'Rubber Tyre Crane',
  },
];

export const operationModeRadioOption: GroupRadioButtonProp[] = [
  {
    inputId: 1,
    key: 'PDS',
    name: 'PDS',
  },
  {
    inputId: 2,
    key: 'Remote',
    name: 'Remote',
  },
  {
    inputId: 3,
    key: 'VMT',
    name: 'VMT',
  },
];

export const maintenanceRadioOption: GroupRadioButtonProp[] = [
  {
    inputId: 1,
    key: 'Repair',
    name: 'Repair',
  },
  {
    inputId: 2,
    key: 'Maintenance',
    name: 'Maintenance',
  },
];

export const servingAreaRadioOption: GroupRadioButtonProp[] = [
  {
    inputId: 1,
    key: 'All',
    name: 'All',
  },
  {
    inputId: 2,
    key: 'Seaside',
    name: 'Seaside',
  },
  {
    inputId: 3,
    key: 'Non-Seaside',
    name: 'Non-Seaside',
  },
];
export const specialHandlingCheckBoxOptions: GroupCheckboxProps[] = [
  {
    name: '20',
    key: '20',
  },
  {
    name: '40',
    key: '40',
  },
  {
    name: '45',
    key: '45',
  },
  {
    name: 'No Open Door',
    key: 'No Open Door',
  },
  {
    name: 'Open Door & 48',
    key: 'Open Door & 48',
  },
  {
    name: 'Others',
    key: 'Others',
  },
];

export const ycTieDownCheckboxOption: GroupCheckboxProps[] = [{ key: 'isTieDown', name: '' }];
export const ycVgmCheckboxOption: GroupCheckboxProps[] = [{ key: 'isVgmCertified', name: '' }];

export const yardCraneRequiredFieldList: string[] = ['yardCraneNo', 'yardCraneType', 'heightLimitInFeet', 'stackableHeightInFeet', 'operationMode', 'servingArea', 'workloadLimit', 'containerWidthLimitInFeet'];

export interface yardCraneDynamicDropdownOptions {
  subTypeDropdownOption: DropdownOptions[];
}
