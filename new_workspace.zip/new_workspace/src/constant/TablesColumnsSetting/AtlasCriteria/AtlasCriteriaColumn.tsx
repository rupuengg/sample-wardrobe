import { ColDef, ColGroupDef } from 'ag-grid-enterprise';
import { AtlasCriteriaConstants } from './AtlasCriteriaConstants';

export const atlasCriteriaTableColumn: (ColDef<any> | ColGroupDef<any>)[] = [
  {
    field: 'atlasStrategyPriority',
    filter: 'agNumberColumnFilter',
    headerName: AtlasCriteriaConstants.FIELDS.PRIORITY,
    sortable: false,
    rowDrag: true,
    width: 115,
    maxWidth: 115,
    minWidth: 67,
    suppressMovable: true,
    lockPosition: 'left',
    lockVisible: true,
    suppressColumnsToolPanel: true,
    hide: true, //!ana.allowUpdate,
  },
  {
    field: 'strategyName',
    filter: 'agTextColumnFilter',
    headerName: AtlasCriteriaConstants.FIELDS.STRATEGY,
    width: 200,
    sortable: false,
  },
  {
    field: 'searchAlgorithm',
    filter: 'agSetColumnFilter',
    headerName: AtlasCriteriaConstants.FIELDS.SEARCH_ALGORITHM,
    width: 200,
    sortable: false,
  },
  {
    field: 'terminal',
    filter: 'agTextColumnFilter',
    headerName: AtlasCriteriaConstants.FIELDS.TERMINAL,
    width: 128,
    sortable: false,
  },
  {
    field: 'berth',
    filter: 'agTextColumnFilter',
    headerName: AtlasCriteriaConstants.FIELDS.BERTH,
    width: 128,
    sortable: false,
  },
  {
    field: 'quayCrane',
    filter: 'agTextColumnFilter',
    headerName: AtlasCriteriaConstants.FIELDS.QUAY_CRANE,
    width: 170,
    sortable: false,
  },
  {
    field: 'movementReference',
    filter: 'agTextColumnFilter',
    headerName: AtlasCriteriaConstants.FIELDS.MOVEMENT_REFERENCE,
    width: 170,
    sortable: false,
  },
  {
    field: 'cntrStatus',
    filter: 'agTextColumnFilter',
    headerName: AtlasCriteriaConstants.FIELDS.CONTAINER_STATUS,
    width: 170,
    sortable: false,
  },
  {
    field: 'consolidatedCategory',
    filter: 'agTextColumnFilter',
    headerName: AtlasCriteriaConstants.FIELDS.CON_CATEGORY,
    width: 170,
    sortable: false,
  },
  {
    field: 'area',
    filter: 'agTextColumnFilter',
    headerName: AtlasCriteriaConstants.FIELDS.AREA_LIST,
    width: 148,
    sortable: false,
  },
  //   {
  //     field: 'enabledString',
  //     filter: 'agSetColumnFilter',
  //     headerName: AtlasCriteriaConstants.FIELDS.ENABLED,
  //     width: 113,
  //     sortable: false,
  //     cellRenderer: (params: any) => {
  //       return params.value ? <IconButton iconClassName='tick-icon' fileName='Icon-tick' size='medium' tooltipDisable={true} /> : '';
  //     },
  //   },
  //   {
  //     field: 'DeleteItem',
  //     lockPinned: true,
  //     suppressHeaderMenuButton: true,
  //     suppressAutoSize: true,
  //     columnChooserParams: {
  //       suppressColumnFilter: true,
  //     },
  //     headerName: ' ',
  //     sortable: false,
  //     width: 55,
  //     resizable: false,
  //     suppressMovable: true,
  //     lockPosition: 'right',
  //     lockVisible: true,
  //     suppressColumnsToolPanel: true,
  //     cellRenderer: (params: any) => {
  //       return <IconButton fileName='Icon-trash' size='medium' tooltipDisable={true} disabled={false} onClick={() => props.handleDelete(params.data)} />;
  //     },
  //     hide: true, //!ana.allowDelete,
  //   },
];
