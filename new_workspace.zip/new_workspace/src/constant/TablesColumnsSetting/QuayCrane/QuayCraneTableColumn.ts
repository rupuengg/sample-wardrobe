import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { QuayCraneEntity } from 'entities';
import { E_Renderer_Type } from 'enums';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';
import { qcmaintenanceRadioOption } from './QuayCraneForm';

export function getQuayCraneColumnSetting(anaInfo?: ANAInfoModel): (ColDef<QuayCraneEntity> | ColGroupDef<QuayCraneEntity>)[] {
  return [
    {
      field: 'berthingTml',
      headerName: 'Berth Tml',
      width: 106,
    },
    {
      field: 'quayCraneNo',
      headerName: 'Quay Crane No.',
      pinned: 'left',
    },
    {
      field: 'sequentialOrder',
      headerName: 'Sequential Order',
      width: 150,
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'type',
      headerName: 'Type',
      // dataType: 'select',
      // options: [
      //     { label: 'Quay Crane', value: 'Q' },
      //     { label: 'Jeep Crane', value: 'J' },
      //     { label: 'Dummy Crane', value: 'D' },
      //     { label: 'Self-Sustain', value: 'S' }
      // ],
      width: 135,
    },
    {
      field: 'berth',
      headerName: 'Berth',
      width: 106,
    },
    {
      field: 'subBerth',
      headerName: 'SubBerth',
      width: 135,
    },
    {
      field: 'workableBerthString',
      headerName: 'Workable Berth',
    },
    {
      field: 'inDeploymentSinceDateTime',
      headerName: 'Deployment Date Time',
      cellDataType: E_Renderer_Type.DATE,
    },
    {
      field: 'tieDownIndr',
      headerName: 'Tie Down',
      cellDataType: E_Renderer_Type.TICK,
      width: 110,
    },
    {
      field: 'maintenance',
      headerName: 'Maintenance',
      width: 150,
      cellRenderer: (params: any) => {
        const index = qcmaintenanceRadioOption.findIndex(d => d.key === params.data.maintenance);
        return index >= 0 ? params.data.maintenance : 'N';
      },
    },
    {
      field: 'tieDownBollard',
      headerName: 'Tie Down Bollard',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'cablePit',
      headerName: 'Cable Pitt (Bollard)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'operationStartBollard',
      headerName: 'Operation Start Bollard',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'operationEndBollard',
      headerName: 'Operation End Bollard',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'outreachLengthByMeter',
      headerName: 'Outreach (Meter)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'outreachLengthByBoxes',
      headerName: 'Outreach (Boxes)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'width',
      headerName: 'Width (Meter)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'liftingHeightLimit',
      headerName: 'Lifting Height (Meter)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'liftingSingleTonnage',
      headerName: 'Single Lift (Ton)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'liftingTwinTonnage',
      headerName: 'Twin Lift (Ton)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'favariance',
      headerName: 'F/A Variance (Ton)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'liftingTanDemTonnage',
      headerName: 'Tandem Lift (Ton)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'color',
      headerName: 'Color',
      cellDataType: E_Renderer_Type.COLOR,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<QuayCraneEntity> | ColGroupDef<QuayCraneEntity>)[]),
  ];
}
