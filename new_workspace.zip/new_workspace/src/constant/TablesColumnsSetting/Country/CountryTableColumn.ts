import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { CountryEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

export function getCountryColumnSetting(anaInfo?: ANAInfoModel): (ColDef<CountryEntity> | ColGroupDef<CountryEntity>)[] {
  return [
    {
      field: 'countryCode',
      headerName: 'Country Code',
      pinned: 'left',
    },
    {
      field: 'countryName',
      headerName: 'Country Name',
    },
    {
      field: 'countryNameLocalized',
      headerName: 'Country Name (Local)',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<CountryEntity> | ColGroupDef<CountryEntity>)[]),
  ];
}
