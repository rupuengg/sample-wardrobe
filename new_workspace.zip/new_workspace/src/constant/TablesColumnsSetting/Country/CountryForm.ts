export const countryRequiredFieldList: string[] = ['countryCode', 'countryName'];
