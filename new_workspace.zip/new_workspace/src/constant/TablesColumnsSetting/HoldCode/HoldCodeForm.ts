export const holdCodeRequiredFieldList: string[] = ['holdConditionCode', 'description'];
