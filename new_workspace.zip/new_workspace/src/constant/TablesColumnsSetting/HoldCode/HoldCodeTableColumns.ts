import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { HoldCodeEntity } from 'entities';
import { E_Renderer_Type } from 'enums';
import { ANAInfoModel } from 'module/Ana';

export function getHoldCodeColumnSetting(anaInfo?: ANAInfoModel): (ColDef<HoldCodeEntity> | ColGroupDef<HoldCodeEntity>)[] {
  return [
    {
      field: 'holdConditionCode',
      headerName: 'Hold Code',
      pinned: 'left',
    },
    {
      field: 'description',
      headerName: 'Description',
    },
    {
      field: 'isSystemDefined',
      headerName: 'System Defined',
      cellDataType: E_Renderer_Type.TICK,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<HoldCodeEntity> | ColGroupDef<HoldCodeEntity>)[]),
  ];
}
