import { GroupRadioButtonProp } from 'veronica-ui-component/dist/component/core';

export const containerHandlingVehicleRequiredFieldList: string[] = ['containerHandlingVehicleNo', 'type', 'heightLimitMeter', 'liftingWeightLimitTon'];

export const containerHandlingVehicleTypeRadioOption: GroupRadioButtonProp[] = [
  {
    inputId: 1,
    key: 'Frontloader',
    name: 'Frontloader',
  },
  {
    inputId: 2,
    key: 'Reach Stacker',
    name: 'Reach Stacker',
  },
  {
    inputId: 3,
    key: 'Straddle Carrier',
    name: 'Straddle Carrier',
  },
];

export const containerHandlingVehicleContainerTypeHandlingRadioOption: GroupRadioButtonProp[] = [
  {
    inputId: 1,
    key: 'Empty',
    name: 'Empty',
  },
  {
    inputId: 2,
    key: 'Laden',
    name: 'Laden',
  },
];

export const containerHandlingVehicleMaintenanceRadioOption: GroupRadioButtonProp[] = [
  {
    inputId: 1,
    key: 'Repair',
    name: 'Repair',
  },
  {
    inputId: 2,
    key: 'Maintenance',
    name: 'Maintenance',
  },
];
