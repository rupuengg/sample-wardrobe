import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef, ValueFormatterParams } from 'ag-grid-community';
import { ContainerHandlingVehicleEntity } from 'entities';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';
import { containerHandlingVehicleMaintenanceRadioOption } from './ContainerHandlingVehicleForm';

export function getContainerHandlingVehicleColumnSetting(anaInfo?: ANAInfoModel): (ColDef<ContainerHandlingVehicleEntity> | ColGroupDef<ContainerHandlingVehicleEntity>)[] {
  return [
    {
      field: 'containerHandlingVehicleNo',
      headerName: 'Container Handling Vehicle No.',
      pinned: 'left',
    },
    {
      field: 'type',
      headerName: 'Type',
    },
    {
      field: 'containerTypeHandling',
      headerName: 'Container Type Handling',
    },
    {
      field: 'heightLimitMeter',
      headerName: 'Height Limit (Meter)',
      comparator: numberComparator,
    },
    {
      field: 'liftingWeightLimitTon',
      headerName: 'Lifting Weight Limit (Ton)',
      comparator: numberComparator,
    },
    {
      field: 'maintenance',
      headerName: 'Maintenance',
      cellRenderer: (params: any) => {
        const index = containerHandlingVehicleMaintenanceRadioOption.findIndex(d => d.key === params.data.maintenance);
        return index >= 0 ? params.data.maintenance : 'N';
      },
    },
    {
      field: 'specialHandling',
      headerName: 'Special Handling',
      valueFormatter: (params: ValueFormatterParams) => {
        return params.data?.specialHandling?.join(', ') ?? null;
      },
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<ContainerHandlingVehicleEntity> | ColGroupDef<ContainerHandlingVehicleEntity>)[]),
  ];
}
