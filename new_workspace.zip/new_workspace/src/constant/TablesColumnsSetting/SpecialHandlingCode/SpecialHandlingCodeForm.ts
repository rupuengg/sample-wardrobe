export const specialHandlingCodeRequiredFieldList: string[] = ['specialHandleCode', 'description'];
