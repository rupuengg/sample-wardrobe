import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { SpecialHandlingCodeEntity } from 'entities';
import { E_Renderer_Type } from 'enums';
import { ANAInfoModel } from 'module/Ana';

export function getSpecialHandlingCodeColumnSetting(anaInfo?: ANAInfoModel): (ColDef<SpecialHandlingCodeEntity> | ColGroupDef<SpecialHandlingCodeEntity>)[] {
  return [
    {
      field: 'specialHandleCode',
      headerName: 'Special Handling Code',
      pinned: 'left',
    },
    {
      field: 'description',
      headerName: 'Description',
    },
    {
      field: 'isSystemDefined',
      headerName: 'System Defined',
      cellDataType: E_Renderer_Type.TICK,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<SpecialHandlingCodeEntity> | ColGroupDef<SpecialHandlingCodeEntity>)[]),
  ];
}
