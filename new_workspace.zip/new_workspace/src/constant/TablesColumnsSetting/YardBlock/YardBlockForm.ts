import { DropdownOptions, GroupCheckboxList, GroupRadioList } from 'veronica-ui-component/dist/component/core';

export const yardBlockBlockUsageOption: DropdownOptions[] = [
  { dropdownLabel: 'General Stacking', tagLabel: 'General Stacking', value: 'General Stacking' },
  { dropdownLabel: 'Customs', tagLabel: 'Customs', value: 'Customs' },
];

export const yardBlockEquipmentTypeOption: DropdownOptions[] = [
  { dropdownLabel: 'T-RTGC', tagLabel: 'T-RTGC', value: 'T-RTGC' },
  { dropdownLabel: 'F-Front Loader', tagLabel: 'F-Front Loader', value: 'F-Front Loader' },
];

export const yardBlockTerminalRunwayPositionOption: DropdownOptions[] = [
  { dropdownLabel: 'Smaller Lane Number', tagLabel: 'Smaller Lane Number', value: 'Smaller Lane Number' },
  { dropdownLabel: 'Larger Lane Number', tagLabel: 'Larger Lane Number', value: 'Larger Lane Number' },
];

export const yardBlockTerminalRunwayTracficDirectionOption: DropdownOptions[] = [
  { dropdownLabel: 'Ascending', tagLabel: 'Ascending', value: 'Ascending' },
  { dropdownLabel: 'Descending', tagLabel: 'Descending', value: 'Descending' },
];

export const doorDirectionOption: GroupRadioList[] = [
  { name: 'Larger Stack No.', key: 'Larger Stack No.', inputId: 'Larger Stack No.' },
  { name: 'Smaller Stack No.', key: 'Smaller Stack No.', inputId: 'Smaller Stack No.' },
];

export const dgGroundingStrategyOption: DropdownOptions[] = [
  { dropdownLabel: 'Mixed DG Codes', tagLabel: 'Mixed DG Codes', value: 'Mixed DG Codes' },
  { dropdownLabel: 'Pure Prefix', tagLabel: 'Pure Prefix', value: 'Pure Prefix' },
  { dropdownLabel: 'Mixed Prefix', tagLabel: 'Mixed Prefix', value: 'Mixed Prefix' },
];

export const undgAllowedOption: DropdownOptions[] = [
  { dropdownLabel: '10', tagLabel: '10', value: '10' },
  { dropdownLabel: '20', tagLabel: '20', value: '20' },
  { dropdownLabel: '30', tagLabel: '30', value: '30' },
  { dropdownLabel: '40', tagLabel: '40', value: '40' },
  { dropdownLabel: '45', tagLabel: '45', value: '45' },
  { dropdownLabel: '48', tagLabel: '48', value: '48' },
  { dropdownLabel: '53', tagLabel: '53', value: '53' },
];

export const reeferVoltageAllowedOptions: DropdownOptions[] = [
  { dropdownLabel: '220', tagLabel: '220', value: '220' },
  { dropdownLabel: '440', tagLabel: '440', value: '440' },
];

export const useExtendedHeightOptions: GroupCheckboxList[] = [{ name: '', key: '1', disabled: false }];

export const laneTypeOptions: GroupCheckboxList[] = [
  { name: 'IB', key: 'IB' },
  { name: 'OB', key: 'OB' },
  { name: 'T/S', key: 'T/S' },
  { name: 'EM', key: 'EM' },
];

export const voidOptions: GroupCheckboxList[] = [{ name: '', key: '1', disabled: false }];

export const densityCheckOptions: GroupCheckboxList[] = [{ name: '', key: '1', disabled: false }];
