import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { IHistory, LineEntity, StackEntity, YardBlockEntity } from 'entities';
import { E_Renderer_Type } from 'enums';
import { ANAInfoModel } from 'module/Ana';
import { YardBlockConstants } from './YardBlockConstants';

export function getYardBlockColumnSetting(anaInfo?: ANAInfoModel): (ColDef<YardBlockEntity> | ColGroupDef<YardBlockEntity>)[] {
  return [
    {
      field: 'blockId',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.BLOCK_ID,
      width: 130,
      pinned: 'left',
    },
    {
      field: 'terminal',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.TERMINAL,
      width: 130,
    },
    {
      field: 'yardAreaID',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.YARD_AREA_ID,
      width: 160,
    },
    {
      field: 'railStationCode',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.RAIL_STATION_CODE,
      width: 190,
    },
    {
      field: 'blockUsage',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.BLOCK_USAGE,
      width: 160,
    },
    {
      field: 'equipmentType',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.EQUIPMENT_TYPE,
      width: 185,
    },
    {
      field: 'firstRunwayPosition',
      headerName: '1st Rwy Position',
      width: 200,
    },
    {
      field: 'firstRunwayTrafficDirection',
      headerName: '1st Rwy Traffic Direction',
      width: 200,
    },
    {
      field: 'secondRunwayPosition',
      headerName: '2nd Rwy Position',
      width: 200,
    },
    {
      field: 'secondRunwayTrafficDirection',
      headerName: '2nd Rwy Traffic Direction',
      width: 200,
    },
    {
      field: 'safety',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.SAFETY,
      cellDataType: E_Renderer_Type.TICK,
      width: 130,
    },
    {
      field: 'remark',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.REMARK,
      width: 130,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<YardBlockEntity> | ColGroupDef<YardBlockEntity>)[]),
  ];
}

export function getYardStackColumnSetting(anaInfo?: ANAInfoModel): (ColDef<StackEntity> | ColGroupDef<StackEntity>)[] {
  return [
    {
      field: 'stackId',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.STACK_ID,
      width: 130,
    },
    {
      field: 'noOfLanes',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.No_OF_LANES,
      width: 110,
    },
    {
      field: 'maxContainerAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.MAX_CONTAINR_ALLOWED,
      width: 170,
    },
    {
      field: 'plannedStackableHeight',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.PLANNED_STACKABLE_HEIGHT,
      width: 200,
    },
    {
      field: 'safetyStackableHeight',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.SAFETY_STACKABLE_HEIGHT,
      width: 190,
    },
    {
      field: 'maxExtendedHeight',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.MAX_EXTENDED_HEIGHT,
      width: 170,
    },
    {
      field: 'doorDirection',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.DOOR_DIRECTION,
      width: 140,
    },
    {
      field: 'tmpContainerSizeAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.CONTAINER_SIZE_ALLOWED,
      width: 160,
    },
    {
      field: 'tmpNextContainerSize',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.NEXT_CONTAINER_SIZE,
      width: 170,
    },
    {
      field: 'tmpCurrentContainerSize',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.CURRENT_CONTAINER_SIZE,
      width: 180,
    },
    {
      field: 'tmpContainerTypeGroupAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.CONTAINER_TYPE_GROUP_ALLOWED,
      width: 180,
    },
    {
      field: 'tmpContainerHeightAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.CONTAINER_HEIGHT_ALLOWED,
      width: 190,
    },
    {
      field: 'tmpGrossWeightLimitAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.GROSS_WEIGHT_LIMIT_ALLOWED,
      width: 220,
    },
    {
      field: 'tmpReeferVoltageAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.REEFER_VOLTAGE_ALLOWED,
      width: 170,
    },
    {
      field: 'tmpTradeModeAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.TRADE_MODE_ALLOWED,
      width: 150,
    },
    {
      field: 'tmpDgGroundingStrategy',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.DG_GROUNDING_STRATEGY,
      width: 170,
    },
    {
      field: 'tmpImdgAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.IMDG,
      width: 125,
    },
    {
      field: 'tmpUndgAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.UNDG,
      width: 125,
    },
    {
      field: 'tmpEquipmentCodeAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.EQUIPMENT_CODE,
      width: 165,
    },
    {
      field: 'tmpHoldCodeAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.HOLD_CODE,
      width: 140,
    },
    {
      field: 'tmpSpecialHandleCodeAllowed',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.SPECIAL_HANDLE_CODE,
      width: 185,
    },
    // {
    //
    //     field: 'tmpDamageCodeAllowed',
    //     headerName: YardBlockConstants.YARD_BLOCK.LABEL.DAMAGE_CODE,
    //     width: 165,
    // },
    {
      field: 'tmpCheckIsolatedLane',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.CHECK_ISOLATED_LANE,
      // dataType: 'boolean',
      width: 160,
    },
    {
      field: 'tmpIsolatedLaneHeightLimitInFeet',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.ISOLATED_LANE_HEIGHT_LIMIT,
      width: 210,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<StackEntity> | ColGroupDef<StackEntity>)[]),
  ];
}

export function getYardLaneColumnSetting(anaInfo?: ANAInfoModel): (ColDef<LineEntity> | ColGroupDef<LineEntity>)[] {
  return [
    {
      field: 'laneID',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.LANE_ID,
      width: 120,
    },
    {
      field: 'stackableHeight',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.STACKABLE_HEIGHT,
      width: 160,
    },
    {
      field: 'useExtendedHeight',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.USE_EXTENDED_HEIGHT,
      width: 180,
    },
    {
      field: 'tmpLaneType',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.LANE_TYPE,
      width: 100,
    },
    {
      field: 'void',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.VOID,
      // dataType: 'boolean',
      width: 100,
    },
    {
      field: 'densityCheck',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.DENSITY_CHECK,
      // dataType: 'boolean',
      width: 120,
    },
    {
      field: 'tmpNoGrounding',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.NO_GROUNDING,
      // dataType: 'boolean',
      width: 150,
    },
    {
      field: 'tmpNoShuffleGrounding',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.NO_SHUFFLE_GROUNDING,
      // dataType: 'boolean',
      width: 180,
    },
    {
      field: 'tmpNoPickup',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.NO_PICKUP,
      // dataType: 'boolean',
      width: 120,
    },
    {
      field: 'tmpNoMarshallingPickup',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.NO_MARSHALLING_PICKUP,
      // dataType: 'boolean',
    },
    {
      field: 'tmpNoGateGeneralEMPickup',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.NO_GATE_GENERAL_EM_PICKUP,
      // dataType: 'boolean',
    },
    {
      field: 'tmpNoGateNominatePickup',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.NO_GATE_NOMINATE_PICKUP,
      // dataType: 'boolean',
    },
    {
      field: 'tmpNoIMPickup',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.NO_IM_PICKUP,
      // dataType: 'boolean',
      width: 120,
    },
    {
      field: 'tmpNoEMLoading',
      headerName: YardBlockConstants.YARD_BLOCK.LABEL.NO_EM_LOADING,
      // dataType: 'boolean',
      width: 130,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<LineEntity> | ColGroupDef<LineEntity>)[]),
  ];
}

export function getBlockAmendHistoryColumnSetting(anaInfo?: ANAInfoModel): (ColDef<IHistory> | ColGroupDef<IHistory>)[] {
  return [
    {
      field: 'updatedTime',
      headerName: 'Updated Date Time',
      width: 260,
    },
    {
      field: 'amendItem',
      headerName: 'Amend Item',
      width: 260,
    },
    {
      field: 'staffId',
      headerName: 'Staff ID',
      width: 260,
    },
    {
      field: 'previousValue',
      headerName: 'Previous Value',
      width: 200,
    },
    {
      field: 'updatedValue',
      headerName: 'Updated Value',
      width: 270,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<IHistory> | ColGroupDef<IHistory>)[]),
  ];
}
