import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { VesselEntity } from 'entities';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';

export function getVesselColumnSetting(anaInfo?: ANAInfoModel): (ColDef<VesselEntity> | ColGroupDef<VesselEntity>)[] {
  return [
    {
      field: 'vesselCode',
      headerName: 'Master Vessel Code',
      pinned: 'left',
    },
    {
      field: 'vesselName',
      headerName: 'Vessel Name',
    },
    {
      field: 'soa',
      headerName: 'SOA',
    },
    {
      field: 'loa',
      headerName: 'LOA (meter)',
      comparator: numberComparator,
    },
    {
      field: 'teuCapacity',
      headerName: 'Vessel Capacity (TEU)',
      comparator: numberComparator,
    },
    {
      field: 'foreBridgeLength',
      headerName: 'Bridge Position (meter)',
      comparator: numberComparator,
    },
    {
      field: 'vesselType',
      headerName: 'Type',
    },
    {
      field: 'vesselModelName',
      headerName: 'Vessel Model Name',
    },
    {
      field: 'callSign',
      headerName: 'Call Sign',
    },
    {
      field: 'lloydsCode',
      headerName: "Lloyd's Code",
    },
    {
      field: 'berthSide',
      headerName: 'Berth Side',
    },
    {
      field: 'nationality',
      headerName: 'Nationality',
    },
    {
      field: 'remarks',
      headerName: 'Remarks',
    },
    {
      field: 'deadWeightInMetricTon',
      headerName: 'Dead Weight (ton)',
      comparator: numberComparator,
    },
    {
      field: 'netWeightInMetricTon',
      headerName: 'Net Weight (ton)',
      comparator: numberComparator,
    },
    {
      field: 'grossWeightInMetricTon',
      headerName: 'Gross Weight (ton)',
      comparator: numberComparator,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<VesselEntity> | ColGroupDef<VesselEntity>)[]),
  ];
}
