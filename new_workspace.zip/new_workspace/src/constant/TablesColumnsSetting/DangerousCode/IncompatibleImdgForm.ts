export const incompatibleImdgRequiredFieldList: string[] = ['imdgCode', 'minSegregationDistanceStack', 'minSegregationDistanceMeter'];
