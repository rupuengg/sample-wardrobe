import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { IncompatibleImdgEntity } from 'entities';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';

export function getIncompatibleImdgColumnSetting(anaInfo?: ANAInfoModel): (ColDef<IncompatibleImdgEntity> | ColGroupDef<IncompatibleImdgEntity>)[] {
  return [
    {
      field: 'imdgCode',
      headerName: 'IMDG Code',
    },
    {
      field: 'minSegregationDistanceStack',
      headerName: 'Min Segregation Distance (Stack)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'minSegregationDistanceMeter',
      headerName: 'Min Segregation Distance (Meter)',
      // dataType: 'number',
      comparator: numberComparator,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<IncompatibleImdgEntity> | ColGroupDef<IncompatibleImdgEntity>)[]),
  ];
}
