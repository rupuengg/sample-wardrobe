import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { DangerousCodeEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

export function getDangerousCodeColumnSetting(anaInfo?: ANAInfoModel): (ColDef<DangerousCodeEntity> | ColGroupDef<DangerousCodeEntity>)[] {
  return [
    {
      field: 'imdgCode',
      headerName: 'IMDG Code',
      pinned: 'left',
    },
    {
      field: 'imdgGoodsName',
      headerName: 'IMDG Goods Name',
    },
    {
      field: 'compatibleImdgString',
      headerName: 'Compatible IMDG',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<DangerousCodeEntity> | ColGroupDef<DangerousCodeEntity>)[]),
  ];
}
