import { DropdownOptions } from 'store';

export const dangerousCodeRequiredFieldList: string[] = ['imdgCode'];

export interface dangerousCodeDynamicDropdownOptions {
  imdgCodeDropdownOption: DropdownOptions[];
}
