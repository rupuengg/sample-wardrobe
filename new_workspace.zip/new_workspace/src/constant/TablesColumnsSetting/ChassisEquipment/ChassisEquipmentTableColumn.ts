import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { ChassisEquipmentEntity } from 'entities';
import { E_Renderer_Type } from 'enums';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';

const includeExcludeCellRenderer = (params: any, field: string) => {
  if (params?.value === 'ALL' && (params?.data[field] === 'N' || params?.data[field] === '')) return '';
  return (params?.data[field] === 'A' ? 'ALL' : params?.value) + (params?.data[field] === 'A' ? '' : `(${params?.data[field] === '' ? 'I' : params?.data[field]})`);
};

export function getChassisTypeColumnSetting(anaInfo?: ANAInfoModel): (ColDef<ChassisEquipmentEntity> | ColGroupDef<ChassisEquipmentEntity>)[] {
  return [
    {
      field: 'chassisType',
      headerName: 'Chassis Type',
      width: 140,
      pinned: 'left',
    },
    {
      field: 'chassisWeightWithoutCargo',
      headerName: 'Chassis Wt (ton)',
      width: 160,
      comparator: numberComparator,
    },
    {
      field: 'maximumCargoWeight',
      headerName: 'Handling Wt (ton)',
      width: 160,
      comparator: numberComparator,
    },
    {
      field: 'containerLengthList',
      headerName: 'Container Size (Include/Exclude)',
      width: 200,
      cellRenderer: (params: any) => includeExcludeCellRenderer(params, 'containerLengthListModifier'),
    },
    {
      field: 'containerTypeGroupList',
      headerName: 'Container Type (Include/Exclude)',
      width: 200,
      cellRenderer: (params: any) => includeExcludeCellRenderer(params, 'containerTypeGroupListModifier'),
    },
    {
      //   field: 'positionRestiction',
      headerName: 'Position Restriction',
      width: 160,
      cellDataType: E_Renderer_Type.VALUE_EITHER_N,
    },
    {
      field: 'equipmentCodeList',
      headerName: 'Equipment Code (Include/Exclude)',
      width: 200,
      cellRenderer: (params: any) => includeExcludeCellRenderer(params, 'equipmentCodeListModifier'),
    },
    {
      field: 'specialHandleCodeList',
      headerName: 'Special Handling Code (Include/Exclude)',
      width: 250,
      cellRenderer: (params: any) => includeExcludeCellRenderer(params, 'specialHandleCodeListModifier'),
    },
    {
      //   field: '',
      headerName: 'QC',
      width: 100,
    },
    {
      //   field: '',
      headerName: 'MSSH Cat',
      width: 160,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<ChassisEquipmentEntity> | ColGroupDef<ChassisEquipmentEntity>)[]),
  ];
}
