export const itPagerRequiredFieldList: string[] = ['pagerNo', 'pagerType', 'pagerDisplayLanguageList', 'pagingChannelId'];

export const itPagerTypeList: string[] = ['physicalAddr', 'pagerNo', 'pagerType', 'pagerDisplayLanguageList', 'pagingChannelId'];
