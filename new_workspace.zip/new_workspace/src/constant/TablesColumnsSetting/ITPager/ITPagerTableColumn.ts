import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { ITPagerEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

const includeExcludeCellRenderer = (params: any, index: number, field: string = '') => {
  if (!params?.value || params?.value === '') return '';

  if (index === 1 && params?.data[field] && params?.data[field] !== '') {
    return params?.data[field];
  }

  const ar = params?.value?.split(',');
  switch (index) {
    case 0:
      return ar[index] ? ar[index] : '';
    case 1:
      return ar[index] ? ar[index] : '';
  }
};

export function getITPagerColumnSetting(anaInfo?: ANAInfoModel): (ColDef<ITPagerEntity> | ColGroupDef<ITPagerEntity>)[] {
  return [
    {
      field: 'pagerNo',
      headerName: 'Pager No.',
      width: 160,
      pinned: 'left',
    },
    {
      field: 'physicalAddr',
      headerName: 'Physical Address',
      width: 190,
      cellRenderer: (params: any) => includeExcludeCellRenderer(params, 0),
    },
    {
      field: 'physicalAddr',
      headerName: 'XTML Address',
      width: 160,
      cellRenderer: (params: any) => includeExcludeCellRenderer(params, 1, 'xmlAddr'),
    },
    {
      field: 'tractorAssigned',
      headerName: 'Tractor Assigned',
      width: 190,
    },
    {
      field: 'pagingChannelId',
      headerName: 'Type',
      width: 160,
    },
    {
      field: 'suspendReason',
      headerName: 'Remark',
      width: 200,
    },
    {
      field: 'pagerDisplayLanguageList',
      headerName: 'Pager Language',
      width: 190,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<ITPagerEntity> | ColGroupDef<ITPagerEntity>)[]),
  ];
}
