import { DropdownOptions } from 'store';

export const pagerLanguageDropdownOptions: DropdownOptions[] = [{ dropdownLabel: 'ENG', value: 'ENG' }];

export const pagerTypeDropdownOptions: DropdownOptions[] = [
  { dropdownLabel: 'P - Private', value: 'P', tagLabel: 'Private' },
  { dropdownLabel: 'G - GPRS', value: 'G', tagLabel: 'GPRS' },
  { dropdownLabel: 'W - Wifi', value: 'W', tagLabel: 'Wi-fi' },
  { dropdownLabel: 'N - nTRACS', value: 'N', tagLabel: 'nTRACS' },
  { dropdownLabel: 'A - Autonomous Truck', value: 'A', tagLabel: 'Autonomous Truck' },
];
