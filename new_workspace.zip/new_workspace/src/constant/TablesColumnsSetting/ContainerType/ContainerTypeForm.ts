export const containerTypeRequiredFieldList: string[] = ['cntrType', 'encodedScheme'];
