import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { ContainerTypeEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

export function getContainerTypeColumnSetting(anaInfo?: ANAInfoModel): (ColDef<ContainerTypeEntity> | ColGroupDef<ContainerTypeEntity>)[] {
  return [
    {
      field: 'cntrType',
      headerName: 'Container Type',
      pinned: 'left',
    },
    {
      field: 'encodedScheme',
      headerName: 'Encoded Scheme',
    },
    {
      field: 'description',
      headerName: 'Description',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<ContainerTypeEntity> | ColGroupDef<ContainerTypeEntity>)[]),
  ];
}
