import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { OperatorConfigEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

export function getOperatorConfigColumnSetting(anaInfo?: ANAInfoModel): (ColDef<OperatorConfigEntity> | ColGroupDef<OperatorConfigEntity>)[] {
  return [
    {
      field: 'code',
      headerName: 'Code',
    },
    {
      field: 'description',
      headerName: 'Description',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<OperatorConfigEntity> | ColGroupDef<OperatorConfigEntity>)[]),
  ];
}
