import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { TieDownLocationEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

const idBodyTemplate = (params: any) => {
  return params?.value?.split('-')?.join('/');
};

export function getTieDownLocationColumnSetting(anaInfo?: ANAInfoModel): (ColDef<TieDownLocationEntity> | ColGroupDef<TieDownLocationEntity>)[] {
  return [
    {
      field: 'id',
      headerName: 'ID',
      width: 160,
      cellRenderer: idBodyTemplate,
      pinned: 'left',
    },
    {
      field: 'tmlId',
      headerName: 'Terminal ID',
      width: 160,
    },
    {
      field: 'locType',
      headerName: 'Location Type',
      width: 160,
    },
    {
      field: 'locShortName',
      headerName: 'Location Short Name',
      width: 240,
    },
    {
      field: 'desc',
      headerName: 'Description',
      width: 200,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<TieDownLocationEntity> | ColGroupDef<TieDownLocationEntity>)[]),
  ];
}
