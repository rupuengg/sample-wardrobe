export const tieDownLocationRequiredFieldList: string[] = ['tmlId', 'locType', 'blockId', 'stack', 'lane', 'tier'];
