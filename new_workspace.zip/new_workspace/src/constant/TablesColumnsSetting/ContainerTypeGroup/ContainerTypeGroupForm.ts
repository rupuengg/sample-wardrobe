import { DropdownOptions } from 'veronica-ui-component/dist/component/core';

export const containerTypeGroupRequiredFieldList: string[] = ['cntrTypeGroup'];

export interface containerTypeDynamicDropdownOptions {
  containerTypeDropdownOption: DropdownOptions[];
}
