import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { ContainerTypeGroupEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

export function getContainerTypeGroupColumnSetting(anaInfo?: ANAInfoModel): (ColDef<ContainerTypeGroupEntity> | ColGroupDef<ContainerTypeGroupEntity>)[] {
  return [
    {
      field: 'cntrTypeGroup',
      headerName: 'Container Type Group',
      pinned: 'left',
    },
    {
      field: 'description',
      headerName: 'Description',
    },
    {
      field: 'istnContainerType',
      headerName: 'Container Type (ISTN)',
    },
    {
      field: 'istoContainerType',
      headerName: 'Container Type (ISTO)',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<ContainerTypeGroupEntity> | ColGroupDef<ContainerTypeGroupEntity>)[]),
  ];
}
