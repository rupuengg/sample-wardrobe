import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { DamageCodeEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

export function getDamageCodeColumnsSetting(anaInfo?: ANAInfoModel): (ColDef<DamageCodeEntity> | ColGroupDef<DamageCodeEntity>)[] {
  return [
    {
      field: 'code',
      headerName: 'Code',
      pinned: 'left',
    },
    {
      field: 'type',
      headerName: 'Type',
      //   dataType: 'select',
      //   options: [
      //     { value: 'Severity', label: 'Severity' },
      //     { value: 'Position', label: 'Position' },
      //     { value: 'DamageContent', label: 'Damage Content' },
      //   ],
    },
    {
      field: 'description',
      headerName: 'Description',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<DamageCodeEntity> | ColGroupDef<DamageCodeEntity>)[]),
  ];
}
