import { GroupRadioButtonProp } from 'veronica-ui-component/dist/component/core';

export const damageCodeRequiredFieldList: string[] = ['code', 'type'];

export const damageCodeTypeRadioOption: GroupRadioButtonProp[] = [
  {
    inputId: 1,
    key: 'Severity',
    name: 'Severity',
  },
  {
    inputId: 2,
    key: 'Position',
    name: 'Position',
  },
  {
    inputId: 3,
    key: 'DamageContent',
    name: 'Damage Content',
  },
];
