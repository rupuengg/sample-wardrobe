import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { LocationGroupEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

export function getLocationGroupColumnSetting(anaInfo?: ANAInfoModel): (ColDef<LocationGroupEntity> | ColGroupDef<LocationGroupEntity>)[] {
  return [
    {
      field: 'groupName',
      headerName: 'Group Name',
    },
    {
      field: 'criteriaType',
      headerName: 'Include/ Exclude',
    },
    {
      field: 'locationTypes',
      headerName: 'Location Types',
      // dataType: 'select',
    },
    {
      field: 'virtualLocations',
      headerName: 'Virtual Locations',
      // dataType: 'select',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<LocationGroupEntity> | ColGroupDef<LocationGroupEntity>)[]),
  ];
}
