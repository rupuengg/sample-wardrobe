import { DropdownOptions, GroupCheckboxProps } from 'veronica-ui-component/dist/component/core';

export interface locationGroupDynamicDropdownOptions {
  virtualLocationDropdownOption: DropdownOptions[];
  locationTypeDropdownOption: DropdownOptions[];
}

export const locationGroupRequiredFieldList: string[] = ['groupName', 'criteriaType'];

export const convertToDropdownOption = (valueObj: string[] | undefined): DropdownOptions[] => {
  return Object.values(valueObj!).map(value => ({
    dropdownLabel: value,
    value: value,
  }));
};

export const criteriaTypeRadioOption: GroupCheckboxProps[] = [
  {
    inputId: 1,
    key: 'INCLUDE',
    name: 'Include',
  },
  {
    inputId: 2,
    key: 'EXCLUDE',
    name: 'Exclude',
  },
];
