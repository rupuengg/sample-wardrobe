import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { IHistory, RangeEntity, YardZoneEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

export function getYardZoneColumnSetting(anaInfo?: ANAInfoModel): (ColDef<YardZoneEntity> | ColGroupDef<YardZoneEntity>)[] {
  return [
    {
      field: 'zoneId',
      headerName: 'Zone Id',
      width: 150,
      pinned: 'left',
    },
    {
      //   disabled: true,
      field: 'category',
      headerName: 'Category',
    },
    {
      field: 'description',
      headerName: 'Description',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<YardZoneEntity> | ColGroupDef<YardZoneEntity>)[]),
  ];
}

export function getYardZoneRanegColumnSetting(anaInfo?: ANAInfoModel): (ColDef<RangeEntity> | ColGroupDef<RangeEntity>)[] {
  return [
    {
      field: 'fromBlockId',
      headerName: 'Block No From',
      width: 150,
    },
    {
      field: 'fromStackId',
      headerName: 'Stack No From',
    },
    {
      field: 'toBlockId',
      headerName: 'Block No To',
    },
    {
      field: 'toStackId',
      headerName: 'Stack No To',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<RangeEntity> | ColGroupDef<RangeEntity>)[]),
  ];
}

export function getZoneAmendHistoryColumnSetting(anaInfo?: ANAInfoModel): (ColDef<IHistory> | ColGroupDef<IHistory>)[] {
  return [
    {
      field: 'updatedTime',
      headerName: 'Updated Date Time',
      width: 260,
    },
    {
      field: 'amendItem',
      headerName: 'Amend Item',
      width: 260,
    },
    {
      field: 'staffId',
      headerName: 'Staff ID',
      width: 260,
    },
    {
      field: 'previousValue',
      headerName: 'Previous Value',
      width: 200,
    },
    {
      field: 'updatedValue',
      headerName: 'Updated Value',
      width: 270,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<IHistory> | ColGroupDef<IHistory>)[]),
  ];
}
