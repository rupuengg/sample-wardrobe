import { DropdownOptions } from 'veronica-ui-component/dist/component/core';

export const yardZoneRequiredFieldList: string[] = ['zoneId', 'category'];

export const yardZoneRangeRequiredFieldList: string[] = ['fromBlockId', 'fromStackId', 'toBlockId', 'toStackId'];

export const yardZoneCategoryOptions: DropdownOptions[] = [
  { dropdownLabel: 'BC-OPR - Bridge Crane Operation', tagLabel: 'BC-OPR - Bridge Crane Operation', value: 'BC-OPR' },
  { dropdownLabel: 'YP-PA - Yard Plan PA Definition', tagLabel: 'YP-PA - Yard Plan PA Definition', value: 'YP-PA' },
  { dropdownLabel: 'BC-TRT - Bridge Crane Tractor Selection', tagLabel: 'BC-TRT - Bridge Crane Tractor Selection', value: 'BC-TRT' },
];
