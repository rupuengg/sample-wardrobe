export const temRequiredFieldList: string[] = [];

export const isFieldMissing = (val: any): boolean => {
  return val === null || val === undefined || val === '' || (typeof val == 'number' && isNaN(val));
};

export const generateMissingMessage = (key: string, value: any): string => {
  return temRequiredFieldList.includes(key) && isFieldMissing(value) ? 'Missing.' : '';
};
