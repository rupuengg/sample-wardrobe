import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { InternalTractorEntity } from 'entities';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';

export function getInternalTractorColumnSetting(anaInfo?: ANAInfoModel): (ColDef<InternalTractorEntity> | ColGroupDef<InternalTractorEntity>)[] {
  return [
    {
      field: 'tractorNo',
      headerName: 'Tractor No.',
      width: 160,
      pinned: 'left',
    },
    {
      field: 'pagerNo',
      headerName: 'Available Pager',
      width: 250,
    },
    {
      field: 'chassisType',
      headerName: 'Chassis Type',
      width: 250,
    },
    {
      field: 'loadingCapacity',
      headerName: 'Loading Capacity (Ton)',
      width: 250,
      // dataType: 'number',
      comparator: numberComparator,
    },
    {
      field: 'itOperatingStaffId',
      headerName: 'IT Contractor',
      width: 200,
    },
    {
      field: 'itWeightWithoutChassis',
      headerName: 'IT Weight (Kg)',
      width: 160,
      //   dataType: 'number',
      comparator: numberComparator,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<InternalTractorEntity> | ColGroupDef<InternalTractorEntity>)[]),
  ];
}
