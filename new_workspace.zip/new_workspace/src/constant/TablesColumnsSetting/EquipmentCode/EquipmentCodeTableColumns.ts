import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { EquipmentCodeEntity } from 'entities';
import { E_Renderer_Type } from 'enums';
import { ANAInfoModel } from 'module/Ana';

export function getEquipmentCodeColumnSetting(anaInfo?: ANAInfoModel): (ColDef<EquipmentCodeEntity> | ColGroupDef<EquipmentCodeEntity>)[] {
  return [
    {
      field: 'equipmentCode',
      headerName: 'Equipment Code',
      pinned: 'left',
    },
    {
      field: 'description',
      headerName: 'Description',
    },
    {
      field: 'nature',
      headerName: 'Nature',
    },
    {
      field: 'isSystemDefined',
      headerName: 'System Defined',
      cellDataType: E_Renderer_Type.TICK,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<EquipmentCodeEntity> | ColGroupDef<EquipmentCodeEntity>)[]),
  ];
}
