import { GroupRadioButtonProp } from 'veronica-ui-component/dist/component/core';

export const equipmentCodeRequiredFieldList: string[] = ['equipmentCode', 'description', 'nature'];

export const equipmentCodeNatureRadioOption: GroupRadioButtonProp[] = [
  {
    inputId: 1,
    key: 'Permanent',
    name: 'Permanent',
  },
  {
    inputId: 2,
    key: 'Temporary',
    name: 'Temporary',
  },
];
