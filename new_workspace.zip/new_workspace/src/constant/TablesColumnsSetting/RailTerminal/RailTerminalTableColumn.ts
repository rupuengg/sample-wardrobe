import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { RailTerminalEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';

export function getRailTerminalColumnSetting(anaInfo?: ANAInfoModel): (ColDef<RailTerminalEntity> | ColGroupDef<RailTerminalEntity>)[] {
  return [
    {
      field: 'code',
      headerName: 'Code',
    },
    {
      field: 'description',
      headerName: 'Description',
    },
    {
      field: 'defaultPortDrawingOrder',
      headerName: 'Default Port Drawing Order',
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<RailTerminalEntity> | ColGroupDef<RailTerminalEntity>)[]),
  ];
}
