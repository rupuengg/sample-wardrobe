import { ColDef, ColGroupDef } from 'ag-grid-community';
import { DataAnalyzerResultDetailEntity, DataAnalyzerResultEntity, DataManagementEntity, DataResyncEntity } from 'entities';
import { ANAInfoModel } from 'module/Ana';
import { DataManagementConstants } from './DataManagementConstants';

export function getDataManagementColumnSetting(anaInfo?: ANAInfoModel): (ColDef<DataManagementEntity> | ColGroupDef<DataManagementEntity>)[] {
  return [
    {
      field: 'pipelineName',
      headerName: DataManagementConstants.LABEL.PROJECT,
      width: 300,
    },
    {
      field: 'domain',
      headerName: DataManagementConstants.LABEL.REPOSITORY,
      width: 160,
    },
    {
      field: 'createdAt',
      headerName: DataManagementConstants.LABEL.CREATED_AT,
      width: 170,
    },
    {
      field: 'createdByActor',
      headerName: DataManagementConstants.LABEL.CREATED_BY,
      width: 170,
    },
    {
      field: 'updatedAt',
      headerName: DataManagementConstants.LABEL.UPDATED_AT,
      width: 170,
    },
    {
      field: 'updatedByActor',
      headerName: DataManagementConstants.LABEL.UPDATED_BY,
      width: 170,
    },
  ];
}

export function getDashboardHistoryColumnSetting(anaInfo?: ANAInfoModel): (ColDef<DataResyncEntity> | ColGroupDef<DataResyncEntity>)[] {
  return [
    {
      field: 'apiKey',
      headerName: DataManagementConstants.LABEL.ENDPOINT,
      width: 170,
    },
    {
      field: 'dataResyncJobId',
      headerName: DataManagementConstants.LABEL.JOB_ID,
      width: 160,
    },
    {
      field: 'dataSyncInfo',
      headerName: DataManagementConstants.LABEL.SYNC_INFO,
      width: 170,
    },
    {
      field: 'status',
      headerName: DataManagementConstants.LABEL.STATUS,
      width: 170,
    },
    {
      field: 'firstTriggerBy',
      headerName: DataManagementConstants.LABEL.FIRST_TRIGGER_BY,
      width: 170,
    },
    {
      // field: 'firstTriggerAtText',
      headerName: DataManagementConstants.LABEL.FIRST_TRIGGER,
      width: 170,
    },
    {
      // field: 'lastUpdatedAtText',
      headerName: DataManagementConstants.LABEL.LAST_SYNC,
      width: 170,
    },
  ];
}

export function getDashboardDataAnalysisResultColumnSetting(anaInfo?: ANAInfoModel): (ColDef<DataAnalyzerResultEntity> | ColGroupDef<DataAnalyzerResultEntity>)[] {
  return [
    {
      field: 'dataAnalyzerId',
      headerName: DataManagementConstants.LABEL.DATA_ANALYZER_ID,
      width: 170,
    },
    {
      field: 'startDateTimeText',
      headerName: DataManagementConstants.LABEL.START_DATE_TIME,
      width: 160,
    },
    {
      field: 'endDateTimeText',
      headerName: DataManagementConstants.LABEL.END_DATE_TIME,
      width: 170,
    },
    {
      field: 'durationSecond',
      headerName: DataManagementConstants.LABEL.DURATION,
      width: 170,
    },
    {
      field: 'docCnt',
      headerName: DataManagementConstants.LABEL.DOC_COUNT,
      width: 170,
    },
    {
      field: 'syncRate',
      headerName: DataManagementConstants.LABEL.SYN_RATE,
      width: 170,
    },
  ];
}

export function getDashboardDataAnalysisResultSingleColumnSetting(anaInfo?: ANAInfoModel): (ColDef<DataAnalyzerResultDetailEntity> | ColGroupDef<DataAnalyzerResultDetailEntity>)[] {
  return [
    {
      field: 'key',
      headerName: DataManagementConstants.LABEL.KEY,
      width: 170,
    },
    {
      field: 'compAction',
      headerName: DataManagementConstants.LABEL.COMP_ACTION,
      width: 170,
    },
    {
      field: 'compActionSuccess',
      headerName: DataManagementConstants.LABEL.COMP_ACTION_SUCCESS,
      width: 160,
    },
    {
      field: 'keyDesc',
      headerName: DataManagementConstants.LABEL.KEY_DESCRIPTION,
      width: 170,
    },
    {
      field: 'problemDataDurationSecond',
      headerName: DataManagementConstants.LABEL.PROBLEM_DATA_DURATION_SECOND,
      width: 170,
    },
    {
      field: 'problemDataFaultToleranceSecond',
      headerName: DataManagementConstants.LABEL.PROBLEM_DATA_FAULT_SECOND,
      width: 170,
    },
    {
      field: 'situation',
      headerName: DataManagementConstants.LABEL.SITUATION,
      width: 170,
    },
  ];
}
