import { getCommonColumnSetting } from '../CommonColumnSetting';
import { ColDef, ColGroupDef } from 'ag-grid-community';
import { ContainerSizeEntity } from 'entities';
import { numberComparator } from 'utils';
import { ANAInfoModel } from 'module/Ana';

export function getContainerSizeColumnSetting(anaInfo?: ANAInfoModel): (ColDef<ContainerSizeEntity> | ColGroupDef<ContainerSizeEntity>)[] {
  return [
    {
      field: 'cntrSize',
      headerName: 'Container Size',
      pinned: 'left',
    },
    {
      field: 'containerSizeGroup',
      headerName: 'Container Size Group',
    },
    {
      field: 'encodedScheme',
      headerName: 'Encoded Scheme',
    },
    {
      field: 'description',
      headerName: 'Description',
    },
    {
      field: 'cntrLengthInFeet',
      headerName: 'Length (Feet)',
      comparator: numberComparator,
    },
    {
      field: 'cntrHeightInFeet',
      headerName: 'Height (Feet)',
      comparator: numberComparator,
    },
    {
      field: 'cntrWidthInFeet',
      headerName: 'Width (Feet)',
      comparator: numberComparator,
    },
    ...(getCommonColumnSetting(anaInfo) as (ColDef<ContainerSizeEntity> | ColGroupDef<ContainerSizeEntity>)[]),
  ];
}
