import { GroupRadioButtonProp } from 'veronica-ui-component/dist/component/core';

export const containerSizeRequiredFieldList: string[] = ['cntrSize', 'containerSizeGroup', 'encodedScheme', 'cntrLengthInFeet', 'cntrHeightInFeet', 'cntrWidthInFeet'];

export const encodedSchemeRadioOption: GroupRadioButtonProp[] = [
  {
    inputId: 1,
    key: 'ISTN',
    name: 'ISTN',
  },
  {
    inputId: 2,
    key: 'ISTO',
    name: 'ISTO',
  },
];
