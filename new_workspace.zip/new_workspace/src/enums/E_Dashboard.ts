export enum E_Dashboard_View {
  TILES = 'TILES',
  LIST = 'LIST',
  GRID = 'GRID',
}

export enum E_Pipeline_View {
  Pipeline = 'Pipeline',
  Line = 'Line',
}

export enum E_Side_Panel_Option {
  Summary = 'Summary',
  History = 'History',
  Analysis_Result = 'Analysis_Result',
}

export enum E_Data_Load_Status {
  NOT_YET_STARTED = 'notyetstarted',
  FULFULLED = 'fulfilled',
  PENDING = 'pending',
  REJECTED = 'rejected',
}

export enum E_Open_MFE_Status {
  NOT_INITIALIZED = 'NOT_INITIALIZED',
  INITIALIZED = 'INITIALIZED',
  LOADING = 'LOADING',
  LOADED = 'LOADED',
}
