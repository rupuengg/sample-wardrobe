export enum E_Criteria_Type {
  INCLUDE = 'INCLUDE',
  EXCLUDE = 'EXCLUDE',
}
