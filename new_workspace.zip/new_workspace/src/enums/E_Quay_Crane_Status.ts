export enum E_Quay_Crane_Status {
  suspend = 'S',
  active = 'A',
  idle = 'I',
  logoff = 'O',
  repair = 'R',
  maintenance = 'M',
}
