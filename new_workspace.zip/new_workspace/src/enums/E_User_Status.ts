export enum E_User_Status {
  OFFLINE = 'OFFLINE',
  ONLINE = 'ONLINE',
  AVAILABLE = 'AVAILABLE',
  AWAY = 'AWAY',
}
