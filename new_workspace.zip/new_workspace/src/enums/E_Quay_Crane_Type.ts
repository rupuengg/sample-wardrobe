export enum E_Quay_Crane_Type {
  quayCrane = 'Q',
  jeepCrane = 'J',
  dummy = 'D',
  selfSustain = 'S',
}
