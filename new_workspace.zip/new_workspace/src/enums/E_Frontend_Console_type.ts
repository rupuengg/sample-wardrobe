export enum E_Frontend_Console_type {
  LOG = 'LOG',
  WARN = 'WARN',
  ERROR = 'ERROR',
}
