export enum E_WebSock_Topic {
  TOPIC_LIVE_USER = '/topic/live-user',
  TOPIC_LIVE_USER_CHAT = '/topic/live-user-chat',
  TOPIC_LIVE_USER_CHAT_MESSAGE = '/topic/live-user-chat-message',
  TOPIC_ENTITY_CURRENT_SYNC_STATUS = '/topic/entity-current-sync-status',
  TOPIC_ANALYZER_ADD_EDIT_DELETE = '/topic/analyzer-add-edit-delete',
}

export enum E_WebSocketActions {
  CREATE = 'CREATE',
  UPDATE = 'UPDATE',
  DELETE = 'DELETE',
}
