export enum E_Message_Type {
  TEXT = 'TEXT',
  IMAGE = 'IMAGE',
  VIDEO = 'VIDEO',
  VOICE = 'VOICE',
  LOCATION = 'LOCATION',
  HTML = 'HTML',
}
