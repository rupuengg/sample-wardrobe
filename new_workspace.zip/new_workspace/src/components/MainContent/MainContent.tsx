import { useSelector } from 'react-redux';
import { Route, Routes } from 'react-router-dom';
import { E_Operation_Permission } from 'enums';
import { DomUtils } from 'helpers';
import { IApplicationState } from 'store';
import { AddEditViewForm, MicroFrontend } from 'components';
import { TableData } from './TableData';

export const MainContent = () => {
  const { path, entrypoint, sectionId } = useSelector((state: IApplicationState) => state.workspace);

  return (
    <>
      {/* {loader && <Loader Indicator='Stripe' size='Large' />} */}
      <div className='mfe-div-container' id={DomUtils.mfeContainer(entrypoint, sectionId)} style={{ width: '100%', height: '100%', overflow: 'auto' }}>
        <Routes>
          <Route index path={`berthMaintenance/:berthId/*`} element={<MicroFrontend path={path || ''} entrypoint={entrypoint || ''} />} />
          <Route index path={`BuildMap/*`} element={<MicroFrontend path={path || ''} entrypoint={entrypoint || ''} />} />
          <Route index path={`:entity/:other/add`} element={<AddEditViewForm type={E_Operation_Permission.ADD} />} />
          <Route index path={`:entity/:other/view/:dataId`} element={<AddEditViewForm type={E_Operation_Permission.VIEW} />} />
          <Route index path={`:entity/:other/edit/:dataId`} element={<AddEditViewForm type={E_Operation_Permission.EDIT} />} />
          <Route index path={`:entity/:other/*`} element={<TableData />} />
        </Routes>
      </div>
    </>
  );
};
