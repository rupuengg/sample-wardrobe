import { useSelector } from 'react-redux';
import { IApplicationState } from 'store';

export const BerthComponent = () => {
  const { defaultPageInformation } = useSelector((state: IApplicationState) => state.workspace);

  return <h1>{defaultPageInformation}</h1>;
};
