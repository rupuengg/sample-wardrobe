import { useRef } from 'react';
import { useSelector } from 'react-redux';
import { Core } from 'veronica-ui-component';
import { IApplicationState } from 'store';
import { Notification } from 'components';
import { MainContent } from 'components/MainContent/MainContent';

export const MainView = () => {
  const { path, entrypoint, showMainView, mfeTitle, expanded, mfeSupTitle, mainNavTitle, mfeFullscreen, mfeGraphic, notification, navigationBarPinned } = useSelector((state: IApplicationState) => state.workspace);
  // const dispatch: IUseDispatch = useAppDispatch();
  const resizableRef = useRef(null);
  // const { uriPath, uriEntrypoint, uriSectionId } = useEntrypoint();

  // useEffect(() => {
  //   if (uriPath && uriEntrypoint) {
  //     dispatch(WorkspaceActions.setEntryPoint({ path: uriPath, entrypoint: uriEntrypoint, sectionId: uriSectionId }));
  //   }
  // }, [uriPath, uriEntrypoint, uriSectionId]);
  //   const [workspaceState, setWorkspaceState] = useWorkspaceTracked();
  //   const { navigation } = { ...workspaceState.generatedMainMenu };
  //   const { userName } = useANAInfo();

  //   const mainViewVM = useMemo(() => MainViewVM({ dispatch: [setWorkspaceState] }), [setWorkspaceState]);
  //   const navigationMenuVM = useMemo(() => NavigationMenuVM({ dispatch: [setWorkspaceState] }), [setWorkspaceState]);

  //   const memoGoToMFE = useCallback(
  //     (e: any) => {
  //       const targetUniqueMenuObjectId = e.detail;
  //       const res: any =
  //         navigation &&
  //         [...navigation].filter(function f(o: any) {
  //           if (o.uniqueMenuObjectId && o.uniqueMenuObjectId.includes(targetUniqueMenuObjectId)) return true;

  //           if (o.submenu) {
  //             return o.submenu.filter(f).length;
  //           }
  //         });

  //       if (!e.submenu) {
  //         const getNavObj: any = (rs: any) => {
  //           if (Array.isArray(rs)) {
  //             const targetResult = rs.find((item: any) => item.uniqueMenuObjectId === targetUniqueMenuObjectId);
  //             const targetResultInSubMenu = rs?.find((item: any) => item.submenu && item.submenu.find((subItem: any) => subItem.uniqueMenuObjectId === targetUniqueMenuObjectId));
  //             const targetResultInSubMenuInsideSubMenu = rs.find(
  //               (item: any) => item.submenu && item.submenu.find((subItem: any) => subItem.submenu && subItem.submenu.find((subSubItem: any) => subSubItem.uniqueMenuObjectId === targetUniqueMenuObjectId))
  //             );
  //             if (targetResult) {
  //               return targetResult;
  //             } else if (targetResultInSubMenu) {
  //               return targetResultInSubMenu.submenu.find((subItem: any) => subItem.uniqueMenuObjectId === targetUniqueMenuObjectId);
  //             } else if (targetResultInSubMenuInsideSubMenu) {
  //               return targetResultInSubMenuInsideSubMenu.submenu
  //                 ?.find((subItem: any) => subItem.submenu?.find((subSubItem: any) => subSubItem.uniqueMenuObjectId === targetUniqueMenuObjectId))
  //                 .submenu?.find((subSubItem: any) => subSubItem.uniqueMenuObjectId === targetUniqueMenuObjectId);
  //             }
  //           }
  //         };
  //         navigationMenuVM.onOpenMFE(getNavObj(res));
  //       }
  //     },
  //     [navigation, navigationMenuVM]
  //   );

  //   const memoSetPageInformation = useCallback(
  //     (e: any) => {
  //       mainViewVM.setPageInformation(e.detail);
  //     },
  //     [mainViewVM]
  //   );

  //   const memoGetPageInformation = useCallback(
  //     (e: any) => {
  //       const getPageInformation = new CustomEvent('getPageInformation', {
  //         detail: {
  //           isMainMenu: workspaceState.isMainMenu,
  //           mfePageInformation: workspaceState.mfePageInformation,
  //           defaultPageInformation: workspaceState.defaultPageInformation,
  //           username: userName,
  //         },
  //       });
  //       document.dispatchEvent(getPageInformation);
  //     },
  //     [workspaceState.isMainMenu, workspaceState.mfePageInformation, workspaceState.defaultPageInformation, userName]
  //   );

  //   useEffect(() => {
  //     const openMfeConfirmed = () => {
  //       navigationMenuVM.onOpenMFE(undefined, true);
  //     };

  //     document.addEventListener('goToMFE', memoGoToMFE as EventListener);
  //     document.addEventListener('setPageInformation', memoSetPageInformation as EventListener);
  //     document.addEventListener('onPageLoad', memoGetPageInformation as EventListener);
  //     document.addEventListener('workspace-confirm-open-mfe', openMfeConfirmed);
  //     return () => {
  //       document.removeEventListener('goToMFE', memoGoToMFE as EventListener);
  //       document.removeEventListener('setPageInformation', memoSetPageInformation as EventListener);
  //       document.removeEventListener('onPageLoad', memoGetPageInformation as EventListener);
  //       document.removeEventListener('workspace-confirm-open-mfe', openMfeConfirmed);
  //     };
  //   }, [navigationMenuVM, memoGetPageInformation, memoSetPageInformation, memoGoToMFE]);

  const parentTitle = mainNavTitle?.length ? mainNavTitle : mfeSupTitle;
  return (
    <>
      {/* <DataManagementSection /> */}
      <div className={`main-container ${expanded ? 'expanded' : ''} ${mfeFullscreen ? (navigationBarPinned ? '' : 'overlay-active') : ''}`} ref={resizableRef} id='main'>
        <Core.Container borderRadius='roundAll' height='100%' onClick={() => {}} theme='theme4' width='100%' className={mfeGraphic ? 'mfe-graphicContainer' : 'mfe-container'} style={!showMainView ? { backgroundColor: 'transparent' } : {}}>
          {showMainView && (
            <>
              <div className='title-wrapper'>
                <div className='titleBar'>
                  <div className='title'>
                    {parentTitle?.map((item: any, i: number) => {
                      return (
                        <div key={i}>
                          <span className='title-text'>{item}</span>
                          <span>|</span>
                        </div>
                      );
                    })}
                    <em>{mfeTitle}</em>
                  </div>
                </div>
              </div>
              {entrypoint && path && <MainContent />}
            </>
          )}

          {!showMainView && <div className='brand-logo'></div>}

          {notification.isShowNotification && <Notification />}
        </Core.Container>
      </div>
    </>
  );
};
