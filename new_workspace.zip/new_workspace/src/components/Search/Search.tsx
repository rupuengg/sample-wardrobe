import { useCallback, useState } from 'react';
import { CommonField, FieldType, IFieldValue } from 'veronica-ui-component/dist/component/core';
import { DataManagementConstants } from 'constant';

export interface ISearch {
  searchText?: string;
  filterCount?: number;
  onSearch: (searchText: string) => void;
}

export const Search: React.FC<ISearch> = ({ searchText, filterCount, onSearch }: ISearch) => {
  const [text, setText] = useState<string>(searchText || '');

  const handleSearch = useCallback(
    (fieldKey: string, fieldValue: IFieldValue) => {
      if (typeof fieldValue === 'string') {
        setText(fieldValue);
        onSearch(fieldValue);
      }
    },
    [onSearch]
  );

  const handleClear = useCallback(
    (fieldValue: string) => {
      setText(fieldValue);
      onSearch(fieldValue);
    },
    [onSearch]
  );

  return (
    <div className='search_box'>
      <div className='filter'>
        <CommonField
          placeholder={DataManagementConstants.LABEL.SEARCH_PLACEHOLDER}
          errorMessages={{}}
          isShowOptional={false}
          isReadOnly={false}
          fieldLabel={''}
          maxLength={100}
          fieldValue={text}
          isSaveClicked={false}
          fieldType={FieldType.TEXT}
          fieldKey={'cellUpdateOnly'}
          requiredFieldList={[]}
          isShowCrossIcon={text !== ''}
          onFieldChange={handleSearch}
          onCrossClick={() => handleClear('')}
        />
      </div>
      <div className='filter_count'>
        {filterCount && <h3>{text !== '' ? DataManagementConstants.LABEL.SEARCH_COUNT.replace('{count}', filterCount.toString()) : DataManagementConstants.LABEL.TOTAL_SEARCH_COUNT.replace('{count}', filterCount.toString())}</h3>}
      </div>
    </div>
  );
};
