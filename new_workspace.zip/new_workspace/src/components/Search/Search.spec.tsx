import React from 'react';
import * as router from 'react-router';
import { configure, mount } from 'enzyme';
import Adapter from '@cfaester/enzyme-adapter-react-18';
import { ISearch, Search } from 'components';

React.useLayoutEffect = React.useEffect;

configure({ adapter: new Adapter() });

const componentProps: ISearch = {
  onSearch: jest.fn(),
};

describe('Search', () => {
  beforeEach(() => {
    jest.spyOn(router, 'useNavigate').mockImplementation(() => jest.fn());
  });

  const component = (props: ISearch) => mount(<Search {...props} />);

  it('Render <Search /> component', () => {
    const wrapper = component({ ...componentProps });
    expect(wrapper.find('.search_box').length).toBe(1);
  });

  it('Render <Search /> component when Count is greater then 0', () => {
    const wrapper = component({ ...componentProps, filterCount: 2, searchText: 't' });
    expect(wrapper.find('.search_box').length).toBe(1);
  });

  it('Render <Search /> component when onSearch', () => {
    const wrapper = component({ ...componentProps });
    wrapper.find('input[type="text"]').simulate('change');
    expect(wrapper.find('.search_box').length).toBe(1);
  });

  it('Render <Search /> component when onClear', () => {
    const wrapper = component({ ...componentProps, filterCount: 2, searchText: 't' });
    wrapper.find('#idIcon a.icon-cross').simulate('click');
    expect(wrapper.find('.search_box').length).toBe(1);
  });
});
