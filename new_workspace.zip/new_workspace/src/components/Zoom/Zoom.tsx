import { useCallback, useEffect, useState } from 'react';
import { WorkspaceUserPreferenceEntity } from 'entities';
import { useANAInfo } from 'hooks';
import { WorkspaceApi } from 'store/services';

export const Zoom = () => {
  const { email } = useANAInfo();
  const [hasRecord, setHasRecord] = useState<boolean>(false);
  const [showOption, setShowOption] = useState<boolean>(false);
  const [value, setValue] = useState<number>(100);

  const doOperation = useCallback(
    (value: number) => {
      const payload: WorkspaceUserPreferenceEntity = {
        name: 'zoom-level',
        type: 'zoom-level',
        userId: email || '',
        payload: [{ key: 'zoom', value }],
      };

      WorkspaceApi[`${hasRecord ? 'update' : 'create'}WorkspaceUserPreference`](payload).then(() => {
        setHasRecord(true);
        sessionStorage.removeItem('zoom-level');
      });
      setValue(value);
      changeLayoutZoom(value);
    },
    [hasRecord]
  );

  const changeLayout = (value: number): number => {
    let cls: string = document.querySelector('body')?.getAttribute('class') || '';
    cls = cls.replace(' zoom-change', '').replace('zoom-change', '');
    document.querySelector('body')?.setAttribute('class', cls);

    // If Zoom is less than 100, then apply the zoom-change class
    if (value < 100) {
      document.querySelector('body')?.setAttribute('class', cls + ' zoom-change');
    }

    return value;
  };

  const changeLayoutZoom = (value: number) => {
    // Menu
    document.querySelector('.wrapper .navigation-menu')?.setAttribute('style', `zoom: ${value / 100};`);

    // Main
    document.querySelector('.wrapper .main-container')?.setAttribute('style', `zoom: ${value / 100};`);

    // Dialogs
    document.querySelector('body.zoom-change .p-dialog-mask')?.setAttribute('style', `zoom: ${value / 100};`);

    // Toggle class to body element to handle layout while using zoom
    changeLayout(value);
  };

  const handleOperation = useCallback(
    (type: string) => {
      const newValue = type === '+' ? value + 7 : value - 7;
      if (newValue >= 50 && newValue <= 100) {
        doOperation(newValue);
      }
    },
    [doOperation, value]
  );

  const handleReset = useCallback(() => {
    const newValue = 100;
    doOperation(newValue);
  }, [doOperation]);

  useEffect(() => {
    WorkspaceApi.getWorkspaceUserPreference(email || '', 'zoom-level').then((res: WorkspaceUserPreferenceEntity[]) => {
      const record = res.filter(item => item.userId === email)[0];
      if (record) {
        setHasRecord(true);
        setValue(record.payload[0].value);
        changeLayoutZoom(record.payload[0].value);
      }
    });
  }, []);

  return (
    <div data-test='zoom' className={`inner-box zoom-site-box ${showOption ? 'active' : ''}`}>
      <div className='inner'>
        <span className='showoption plus' onClick={() => setShowOption(!showOption)}>
          Zoom
        </span>
        <span className='icon minus' onClick={() => handleOperation('-')}></span>
        <p className='value'>{value}%</p>
        <span className='icon plus' onClick={() => handleOperation('+')}></span>
        <span className='zoom-reset resset plus' onClick={() => handleReset()}>
          Reset
        </span>
      </div>
    </div>
  );
};
