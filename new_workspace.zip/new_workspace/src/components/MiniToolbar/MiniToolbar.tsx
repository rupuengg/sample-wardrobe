import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { DialogBox, DropdownOptions, HPHAvatar, HPHButton, HPHToggle, IconButton, InputDropdown as InputDropdown1 } from 'veronica-ui-component/dist/component/core';
import { useANAInfo } from 'hooks';
import { BU_LABEL_MAPPING, getANAHostName, isDevelopmentEnv, isIutEnv } from 'utils';
import { IApplicationState, IUseDispatch, WorkspaceActions, setDefaultBu, useAppDispatch } from 'store';

const InputDropdown: any = InputDropdown1;

export const MiniToolbar = () => {
  const { workspace } = useSelector((state: IApplicationState) => state);
  const dispatch: IUseDispatch = useAppDispatch();
  const { sectionId, showSyncStatus, showZoom, showRealTimeUser } = workspace;
  const [showDialog, setShowDialog] = useState(false);

  const [businessUnitDropdown, setBusinessUnitDropdown] = useState('');
  const { anaKeycloak, email, userName, currentBu, availableBuList, token } = useANAInfo();

  const onDefault = async (key: string) => {
    setShowDialog(false);
    dispatch(setDefaultBu({ bu: key, email: email }));
  };

  const handleProfile = useCallback(() => {
    setShowDialog(false);
    dispatch(WorkspaceActions.showProfile());
  }, []);

  useEffect(() => {
    dispatch(WorkspaceActions.showOptions());
  }, []);

  const handleChange = useCallback((type: 'showSyncStatus' | 'showRealTimeUser' | 'showZoom', value: boolean) => {
    const status = !value;
    localStorage.setItem(type, status.toString());
    dispatch(WorkspaceActions.showOptionByKey({ key: type, value: !value }));
  }, []);

  const handleActivity = useCallback(() => {
    setShowDialog(false);
    dispatch(WorkspaceActions.showUserActivity());
  }, []);

  useEffect(() => {
    const title = document.querySelector('head title');
    if (title) {
      const currentBuLabel = BU_LABEL_MAPPING[currentBu] ?? currentBu;
      title.innerHTML = `Veronica - ${currentBuLabel}`;
    }
  }, [currentBu]);

  const ref = useRef<HTMLFormElement>(null);

  const switchBuUrl = useMemo(() => {
    const domainWithOutBuPrefix = getANAHostName();
    return `https://${domainWithOutBuPrefix}/alessia/api/switchingBU`;
  }, []);

  useEffect(() => {
    setBusinessUnitDropdown(currentBu);
  }, [currentBu]);
  return (
    <>
      <div className='miniToolBar'>
        <div className='toolbar-container'>
          <div className='action-buttons' style={{ display: 'flex' }}>
            <IconButton fileName='Icon-tech-info' size='medium' toolTipArrow={true} toolTipPlacement='right' toolTipText='Version Information' onClick={() => dispatch(WorkspaceActions.showVersionInformation())} />
            <div className='seprator'>
              <span></span>
            </div>
          </div>

          <div className='user-profile'>
            <div className='user-dropdown-wrapper'>
              <div
                className={`user-icon ${showDialog ? 'user-icon-open' : ''}`}
                onClick={() => {
                  setShowDialog(true);
                }}
              >
                <HPHAvatar size='medium' name={userName} />
              </div>
              {showDialog && (
                <div className='dialogBox-container' onMouseLeave={() => setShowDialog(false)}>
                  <DialogBox boxPosition='right' maxWidth='initial' minWidth='300px' height='auto' className='user--dropdown'>
                    <div className='dropdown-inner'>
                      <div className='user-info'>
                        <HPHAvatar size='large' name={userName} />
                        {/* <div className="user__name">{userName}</div> */}
                        <div className='user__email'>{email}</div>
                      </div>
                      <div className='form-control'>
                        <InputDropdown
                          errorMessage=''
                          field='dropdownLabel'
                          inputType='freeText'
                          label='Business Unit'
                          mode='single'
                          placeholder=''
                          value={businessUnitDropdown}
                          options={availableBuList?.map((bu: string) => ({
                            dropdownLabel: BU_LABEL_MAPPING[bu] ?? bu,
                            value: bu,
                            tagLabel: bu,
                          }))}
                          onChange={(e: DropdownOptions) => {
                            setBusinessUnitDropdown(e.value ?? '');
                            setTimeout(() => ref.current?.submit()); //wait for dropdown update first, and then use updated value to submit form
                          }}
                          virtualScrollerOptions={{
                            delay: 0,
                            lazy: false,
                            showLoader: true,
                          }}
                          width='100%'
                        />
                        <IconButton fileName='Icon-home' size='medium' toolTipArrow={false} toolTipPlacement='right' toolTipText='Set as default' onClick={() => onDefault(businessUnitDropdown)} />
                      </div>
                      <div className='form-control'>
                        <ul className='action-button'>
                          {(isIutEnv || isDevelopmentEnv) && (
                            <>
                              <li className='user-other-option'>
                                <HPHToggle label={'Show Sync Status'} value={workspace['showSyncStatus']} check={showSyncStatus} options={[]} onChange={() => handleChange('showSyncStatus', showSyncStatus || false)} />
                                <b>Show Analyzer Status</b>
                              </li>
                              <li className='user-other-option'>
                                <HPHToggle label={'Show Zoom'} value={showRealTimeUser} check={showRealTimeUser} options={[]} onChange={() => handleChange('showRealTimeUser', showRealTimeUser || false)} />
                                <b>Show Live Users</b>
                              </li>
                              <li className='user-other-option'>
                                <HPHToggle label={'Show Zoom'} value={showZoom} check={showZoom} options={[]} onChange={() => handleChange('showZoom', showZoom || false)} />
                                <b>Show Zoom</b>
                              </li>
                            </>
                          )}
                          <li>
                            <div className={`link ${sectionId === 'profile' && 'active'}`} onClick={handleProfile}>
                              Accessibility
                            </div>
                          </li>
                          <li>
                            <div className={`link ${sectionId === 'activity' && 'active'}`} onClick={handleActivity}>
                              History
                            </div>
                          </li>
                        </ul>
                      </div>
                      <div className='form-control' style={{ marginTop: '0px' }}>
                        <HPHButton id='logoutButton' icon='Icon-logout' label='Logout' showIcon={true} size='Standard' theme='Secondary' onClick={() => anaKeycloak?.logout()} />
                      </div>
                    </div>
                  </DialogBox>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <form ref={ref} action={switchBuUrl} method='POST' target='switch-bu-iframe'>
        <input type='hidden' value={businessUnitDropdown} name='targetBu' />
        <input type='hidden' value={token} name='token' />
      </form>
    </>
  );
};
