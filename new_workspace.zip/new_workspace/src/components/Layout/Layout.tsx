import { defaultEntityStatusDataEntity } from 'mock-values';
import { useEffect, useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { Navigate, Route, Routes } from 'react-router-dom';
import { WorkspaceConstant } from 'constant';
import { IEntityStatusDataEntity } from 'entities';
import { E_Data_Load_Status } from 'enums';
import { useANAInfo, useLoginTracking } from 'hooks';
import { IApplicationState, IUseDispatch, loadEnvironmentVariable, loadWorkspaceMenu, useAppDispatch } from 'store';
import { DataManagementContentSectionBind, LiveUser, MainView, ModalMainView, NavigationMenu, SwitchBuIframe, VersionInformation, Zoom } from 'components';

export const Layout = () => {
  const { identifier, showSyncStatus, showZoom, showRealTimeUser } = useSelector((state: IApplicationState) => state.workspace);
  const dispatch: IUseDispatch = useAppDispatch();
  const { token } = useANAInfo();
  const startRef = useRef<IEntityStatusDataEntity>(defaultEntityStatusDataEntity);
  const [showDMContentSection, setShowDMContentSection] = useState<boolean>(false);

  useLoginTracking(identifier);
  // useFrontendConsoleTracking(identifier);
  // useANAInfoRequestReceiver();

  useEffect(() => {
    dispatch(loadEnvironmentVariable());
  }, []);

  useEffect(() => {
    if (!token) return;
    if (startRef.current.workspaceMenu === E_Data_Load_Status.NOT_YET_STARTED) {
      startRef.current = { ...startRef.current, workspaceMenu: E_Data_Load_Status.PENDING };
      dispatch(loadWorkspaceMenu('workspace-main-menu'));
    }
  }, [token, dispatch]);

  useEffect(() => {
    setTimeout(() => {
      setShowDMContentSection(true);
    }, 0);
  }, []);

  return (
    <div className='work-space'>
      <main>
        <div className='wrapper' style={{ height: '100vh' }}>
          <NavigationMenu />
          <ModalMainView />
          <SwitchBuIframe />
          <VersionInformation />

          <Routes>
            <Route path='/'>
              <Route index element={<Navigate to={`${WorkspaceConstant.API_MAIN_ROUTE}`} replace />} />
              <Route path={`${WorkspaceConstant.API_MAIN_ROUTE}/*`} element={<MainView />} />
            </Route>
          </Routes>

          <div className={`dm-line-box-show-hide analyzer-results-entity-status1 ${showSyncStatus ? 'show' : 'hide'}`} id='analyzer-results-entity-status-section' />
          <div className={`dm-line-box-show-hide real-time-user-section1 ${showRealTimeUser ? 'show' : 'hide'}`} id='real-time-user-section' />
          <div className={`dm-line-box-show-hide zoom-section1 ${showZoom ? 'show' : 'hide'}`} id='zoom-section' />
          {showDMContentSection && (
            <>
              {/* <DataManagementContentSectionBind divId='analyzer-results-entity-status-section' component={<AnalyzerResultsMain />} /> */}
              <DataManagementContentSectionBind divId='real-time-user-chat-section' component={<LiveUser />} />
              <DataManagementContentSectionBind divId='zoom-section' component={<Zoom />} />
            </>
          )}
        </div>
      </main>
    </div>
  );
};
