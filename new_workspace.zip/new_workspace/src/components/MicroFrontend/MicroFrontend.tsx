import { useEffect, useMemo, useState } from 'react';
import { useSelector } from 'react-redux';
import { Loader } from 'veronica-ui-component/dist/component/core';
import { E_Custom_Dispatch_Event, E_Type_Of_Event, customDispatchEvent } from 'helpers';
import { DomUtils } from 'helpers/DomUtils';
import { usePageActive } from 'hooks';
import { IApplicationState } from 'store';
import { NotAccess } from 'components';

export interface IMicroFrontend {
  path: string;
  entrypoint: string;
  isModelOpen?: boolean;
  sectionId?: string;
  containerId?: string;
  jsonData?: string;
}

export const MicroFrontend = (props: IMicroFrontend) => {
  const { workspace } = useSelector((state: IApplicationState) => state);
  const { path, entrypoint, isModelOpen, sectionId = '', containerId, jsonData } = props;
  const [loader, setLoader] = useState(true);
  const [isShowUnderConstruction, setIsShowUnderConstruction] = useState(false);
  usePageActive(entrypoint, workspace.identifier);

  const memoDefaultPageInformation = useMemo(() => {
    return isModelOpen ? '' : workspace.defaultPageInformation;
  }, [workspace.defaultPageInformation, isModelOpen]);

  const refreshTimeStamp = workspace.refreshTimestamp[`${path}-${entrypoint}`];
  useEffect(() => {
    const className: string = DomUtils.getMfeClassName(entrypoint, sectionId);
    setLoader(true);

    const abortController = new AbortController();
    const signal = abortController.signal;

    fetch(`${path}/asset-manifest.json`, { cache: 'no-cache', signal: signal })
      .then(res => res.json())
      .then(manifest => {
        setTimeout(() => {
          customDispatchEvent(E_Type_Of_Event.DATA_MANAGEMENT_EVENT, E_Custom_Dispatch_Event.DM_OPEN_NEW_MFE, { path, entrypoint, sectionId, isModelOpen: isModelOpen || false });
        }, 1000);
        DomUtils.bindEntryPoints(manifest.otherEntrypoints, className, path, entrypoint, sectionId, jsonData);
        setLoader(false);
        setIsShowUnderConstruction(false);
      })
      .catch(e => {
        if (e.name === 'AbortError') {
          /* empty */
        } else {
          setLoader(false);
          setIsShowUnderConstruction(true);
        }
      });

    return () => {
      customDispatchEvent(E_Type_Of_Event.DATA_MANAGEMENT_EVENT, E_Custom_Dispatch_Event.DM_CLOSE_NEW_MFE, { path, entrypoint, sectionId, isModelOpen: isModelOpen || false });
      abortController.abort();
      DomUtils.unMountHtml(className);
    };
  }, [entrypoint, path, sectionId, memoDefaultPageInformation, jsonData, refreshTimeStamp, isModelOpen]);

  if (isShowUnderConstruction) return <NotAccess text={'Our system is currently unavailable. Please try again later.'} />;

  return (
    <>
      {loader && <Loader Indicator='Stripe' size='Large' />}
      <div className='mfe-div-container' id={containerId ? containerId : DomUtils.mfeContainer(entrypoint, sectionId)} style={{ width: '100%', height: '100%', overflow: 'auto' }} />
    </>
  );
};
