import { useEffect } from 'react';
import { useANAInfo } from 'hooks';

export const SwitchBuIframe = () => {
  const { anaKeycloak } = useANAInfo();

  useEffect(() => {
    const switchBu = (e: any) => {
      const data = e.data;
      if (data.switchingBu === true) {
        if (data.targetUrl) {
          window.location = data.targetUrl; // Target BU’s URL
        } else {
          anaKeycloak?.login();
        }
      }
    };
    window.addEventListener('message', switchBu);
    return () => {
      window.removeEventListener('message', switchBu);
    };
  }, [anaKeycloak]);

  return (
    <iframe
      id='switch-bu-iframe'
      name='switch-bu-iframe'
      src=''
      title='switch-bu-iframe'
      style={{
        position: 'absolute',
        backgroundColor: 'white',
        top: '0px',
        left: '0px',
        zIndex: '9999',
        width: '0px',
        height: '0px',
      }}
    />
  );
};
