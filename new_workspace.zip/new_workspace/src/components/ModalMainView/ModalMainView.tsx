import VersionSvg from '../../assets/images/VERONICA_logo.svg';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSelector } from 'react-redux';
import { E_Notification_Type } from 'enums';
import { E_Custom_Dispatch_Event, E_Type_Of_Event, customEventListener } from 'helpers';
import { useANAInfo } from 'hooks';
import { BU_LABEL_MAPPING } from 'utils';
import { IApplicationState, IUseDispatch, IVersionInformation, WorkspaceActions, useAppDispatch } from 'store';
import { IModal, Modal } from 'components';

export const ModalMainView: React.FC = () => {
  const { workspace } = useSelector((state: IApplicationState) => state);
  const dispatch: IUseDispatch = useAppDispatch();

  const [customModal, setCustomModal] = useState<{ [x: string]: IModal }>({});
  const { currentBu } = useANAInfo();
  const { showCodeLibrary, showInventorySearch, showMovementSearch, showPARASearch, showModalForVersionInformation, showModalForVersionIcon, environmentVariable } = workspace;

  const handleModalClose = useCallback((obj: { [x: string]: boolean }) => {
    const keys = Object.keys(obj);
    if (keys.length > 0) dispatch(WorkspaceActions.showModalCloseByKey({ key: keys[0], value: obj[keys[0]] }));
  }, []);

  const versionModalContent: JSX.Element = useMemo(() => {
    if (!environmentVariable.version) return <></>;

    return (
      <>
        <div className='version-logo'>
          <img alt='Version Information' src={VersionSvg} />
        </div>
        <div className='version-title'>{BU_LABEL_MAPPING[currentBu] ?? currentBu}</div>
        <div className='version-box'>
          {environmentVariable.version.map((version: IVersionInformation) => (
            <label key={version.appName}>
              <span>{version.appName}</span>
              <span>{version.version}</span>
            </label>
          ))}
        </div>
      </>
    );
  }, [environmentVariable]);

  const modalData: { [x: string]: IModal } = useMemo(() => {
    const data: { [x: string]: IModal } = {
      // Code Library
      'code-library': {
        isVisible: showCodeLibrary,
        showExistingHeader: true,
        modalTitle: 'CODE LIBRARY',
        dailogClass: 'code-library',
        modalHeight: '507px',
        enteryPointData: workspace.generatedMainMenu.codeLibrary ? workspace.generatedMainMenu.codeLibrary[0] : {},
        onClose: () => handleModalClose({ showCodeLibrary: false }),
      },
      // Container Search
      'inventory-search-modal': {
        isVisible: showInventorySearch,
        showExistingHeader: false,
        modalTitle: 'CONTAINER SEARCH',
        dailogClass: 'inventory-search-modal im-only-search-modal',
        enteryPointData: workspace.generatedMainMenu.inventorySearch ? workspace.generatedMainMenu?.inventorySearch[0] : {},
        onClose: () => handleModalClose({ showInventorySearch: false }),
      },
      // Movement Search
      'movement-search-modal': {
        isVisible: showMovementSearch,
        showExistingHeader: false,
        modalTitle: 'MOVEMENT SEARCH',
        dailogClass: 'movement-search-modal am-only-search-modal',
        enteryPointData: workspace.generatedMainMenu.movementSearch ? workspace.generatedMainMenu.movementSearch[0] : {},
        onClose: () => handleModalClose({ showMovementSearch: false }),
      },
      // PA/RA Search
      'para-search-modal': {
        isVisible: showPARASearch,
        showExistingHeader: false,
        modalTitle: 'PA/RA SEARCH',
        dailogClass: 'para-search-modal ym-only-search-modal',
        enteryPointData: workspace.generatedMainMenu.PARASearch ? workspace.generatedMainMenu.PARASearch[0] : {},
        onClose: () => handleModalClose({ showPARASearch: false }),
      },
      'version-information-modal': {
        isVisible: showModalForVersionInformation,
        showExistingHeader: true,
        modalTitle: (
          <span className='md-header-title' style={{ flexGrow: '1' }}>
            <span className='template-list'></span>
          </span>
        ),
        dailogClass: 'version-information-modal',
        maskClass: 'version-information-modal-mask',
        enteryPointData: undefined,
        resizable: false,
        modalContent: versionModalContent,
        showMinimiseButton: false,
        onClose: () => handleModalClose({ showModalForVersionInformation: false }),
        onMinimiseCallbackOnly: () => dispatch(WorkspaceActions.showVersionModalMinimise()),
      },
      ...(Object.keys(customModal).length > 0 ? { ...customModal } : {}),
    };

    return data;
  }, [showCodeLibrary, showInventorySearch, showMovementSearch, showModalForVersionInformation, showModalForVersionIcon, customModal, showPARASearch]);

  const closeCustomModal = (modalKey: string) => {
    setCustomModal(p => {
      const n = { ...p };
      delete n[modalKey];
      return { ...n };
    });
  };

  const oepnNewModal = (data: any) => {
    setCustomModal(p => ({
      ...p,
      [data.modalKey]: {
        isVisible: true,
        showExistingHeader: data.showExistingHeader,
        modalTitle: 'Hello World' + data.enteryPoint,
        dailogClass: '',
        maskClass: data.maskClass,
        modalHeight: modalData.modalHeight, // Height should be in pixel or percent
        enteryPointData: { path: data.path, entrypoint: data.enteryPoint },
        resizable: data.resizable || true,
        draggable: data.resizable || true,
        modalContent: data.modalContent,
        showMaximiseButton: data.showMaximiseButton,
        showMinimiseButton: data.showMinimiseButton,
        onClose: () => closeCustomModal(data.modalKey),
        onMinimise: () => data.onMinimise,
        onMinimiseCallbackOnly: () => data.onMinimiseCallbackOnly,
      },
    }));
  };

  const onModalEventChange = (e: any) => {
    switch (e.detail.action) {
      case E_Custom_Dispatch_Event.MODAL_OPEN:
        oepnNewModal(e.detail.data);
        break;
      case E_Custom_Dispatch_Event.MODAL_CLOSE:
        handleModalClose(e.detail.data);
        break;
      case E_Custom_Dispatch_Event.MODAL_FULL_SCREEN_MODE: {
        const ele: Element | null = document.querySelector(`body.modal > .p-dialog-mask .${e.detail.data.className}`);
        if (!ele) return;

        if (e.detail.data.isFullScreen) {
          ele?.setAttribute('class', ele?.getAttribute('class')?.toString().replaceAll('minimise', 'enlarge') || '');

          switch (e.detail.data.className) {
            case 'inventory-search-modal':
            case 'movement-search-modal':
            case 'para-search-modal':
              ele?.classList.add('enlarge-px-minus-70');
              break;
          }
        } else {
          ele?.classList.remove('enlarge-px-minus-70');
          ele?.setAttribute('class', ele?.getAttribute('class')?.toString().replaceAll('enlarge', 'minimise') || '');
        }
        break;
      }
    }
  };

  const onInventorySearchChange = () => {
    // switch (
    //   e.detail.action
    //   // case E_Custom_Dispatch_Event.INVENTORY_MODAL_CLOSE:
    //   //   break;
    // ) {
    // }
  };

  const onMovementSearchChange = () => {
    // switch (
    //   e.detail.action
    //   // case E_Custom_Dispatch_Event.MOVEMENT_MODAL_CLOSE:
    //   //   break;
    // ) {
    // }
  };

  const onNotificationMessageChange = (e: any) => {
    switch (e.detail.action) {
      case E_Custom_Dispatch_Event.NOTIFICATION_MESSAGE_SHOW:
        dispatch(WorkspaceActions.showNotification({ notificationType: e.detail.data.isSuccess ? E_Notification_Type.SUCCESS : E_Notification_Type.ALERT, notificationMessage: e.detail.data.message }));
        break;
    }
  };

  const onWorkspaceMenuChange = (e: any) => {
    switch (e.detail.action) {
      case E_Custom_Dispatch_Event.WORKSPACE_MENU_CHANGE:
        dispatch(WorkspaceActions.openMFEFromDataManagement(e.detail.data.menuName));
        break;
    }
  };

  const onDataManagementChange = (e: any) => {
    switch (e.detail.action) {
      case E_Custom_Dispatch_Event.DM_LIVE_USER_UNREAD_MESSAGE_COUNT: {
        const count = Number(e.detail.data.unreadCount) !== 0 ? e.detail.data.unreadCount : '';
        dispatch(WorkspaceActions.updateUnreadMessageCount(count));
        break;
      }
    }
  };

  useEffect(() => {
    customEventListener(E_Type_Of_Event.MODAL_EVENT, onModalEventChange);
    customEventListener(E_Type_Of_Event.INVENTORY_SEARCH_EVENT, onInventorySearchChange);
    customEventListener(E_Type_Of_Event.MOVEMENT_SEARCH_EVENT, onMovementSearchChange);
    customEventListener(E_Type_Of_Event.NOTIFICATION_MESSAGE_EVENT, onNotificationMessageChange);
    customEventListener(E_Type_Of_Event.WORLSPACE_MENU_EVENT, onWorkspaceMenuChange);
    customEventListener(E_Type_Of_Event.DATA_MANAGEMENT_EVENT, onDataManagementChange);
  }, []);

  return (
    <>
      {Object.keys(modalData).map((modalKey: string) => (
        <Modal key={modalKey} {...modalData[modalKey]} />
      ))}
    </>
  );
};
