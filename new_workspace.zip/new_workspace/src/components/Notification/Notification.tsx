import { useCallback, useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { NotificationBar } from 'veronica-ui-component/dist/component/core';
import { IApplicationState, IUseDispatch, WorkspaceActions, useAppDispatch } from 'store';

const NOTIFICATION_INITIAL_TIME = 20;

export const Notification: React.FC = () => {
  const { notification } = useSelector((state: IApplicationState) => state.workspace);
  const dispatch: IUseDispatch = useAppDispatch();

  const [time, setTime] = useState(NOTIFICATION_INITIAL_TIME);
  const { notificationMessage, notificationType } = notification;

  const handleClearNotification = useCallback((interval?: any) => {
    dispatch(WorkspaceActions.clearNotification());
    interval && clearInterval(interval);
  }, []);

  useEffect(() => setTime(NOTIFICATION_INITIAL_TIME), [notificationMessage, notificationType]);

  useEffect(() => {
    const countdown = setInterval(() => {
      if (time > 0) {
        setTime(prevState => prevState - 1);
      } else {
        handleClearNotification(countdown);
      }
    }, 1000);

    return () => clearInterval(countdown);
  }, [time]);

  return <NotificationBar className={`notification-bar ${notificationType}`} width={'100%'} height={'50px'} time={time} onClick={handleClearNotification} text={notificationMessage} />;
};
