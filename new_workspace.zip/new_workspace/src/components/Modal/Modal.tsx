import { useCallback } from 'react';
import { IModalNavigationEntity } from 'entities';
import { DialogUtils } from 'helpers';
import { DomUtils } from 'helpers/DomUtils';
import { MicroFrontend } from 'components/MicroFrontend';
import { SingleModal } from './SingleModal';

export function convertTemplateId(templateId: string) {
  return templateId.toString().toLowerCase().trim().replaceAll("'", '').replaceAll('&', '').replaceAll(' ', '-').replaceAll('(', '-').replaceAll(')', '-').replaceAll('+', '-');
}

export interface IModal {
  isVisible?: boolean;
  showExistingHeader?: boolean;
  modalTitle: string | JSX.Element;
  dailogClass: string;
  maskClass?: string;
  modalHeight?: string; // Height should be in pixel or percent
  enteryPointData: IModalNavigationEntity | undefined;
  resizable?: boolean;
  draggable?: boolean;
  modalContent?: JSX.Element;
  showMaximiseButton?: boolean;
  showMinimiseButton?: boolean;
  focusModalId?: string;
  onClose?: () => void;
  onMinimise?: (e: React.MouseEvent<HTMLAnchorElement>) => void;
  onMinimiseCallbackOnly?: (e: React.MouseEvent<HTMLAnchorElement>) => void;
}

export interface IFullScreen {
  templateId: string | undefined;
  isFullScreen: boolean;
}

export const Modal: React.FC<IModal> = ({
  isVisible = false,
  showExistingHeader = true,
  modalTitle,
  dailogClass,
  modalHeight,
  enteryPointData,
  resizable = true,
  draggable = true,
  modalContent = undefined,
  showMaximiseButton = false,
  showMinimiseButton = false,
  maskClass = '',
  onClose,
  onMinimiseCallbackOnly,
}: IModal) => {
  const getMfe = useCallback((path?: string, entrypoint?: string, sectionId?: string, jsonData?: string): JSX.Element => {
    if (path && entrypoint) return <MicroFrontend path={path} entrypoint={entrypoint} sectionId={sectionId} jsonData={jsonData} isModelOpen={true} />;
    return <></>;
  }, []);

  return (
    <SingleModal
      modalId={DomUtils.mfeContainer(enteryPointData?.entrypoint, enteryPointData?.sectionId)}
      visible={isVisible}
      headerHtml={showExistingHeader ? typeof modalTitle !== 'string' ? modalTitle : <>{modalTitle}</> : null}
      contentHtml={modalContent ? modalContent : getMfe(enteryPointData?.path, enteryPointData?.entrypoint, enteryPointData?.sectionId)}
      draggable={draggable}
      resizable={resizable}
      modalClass={`${dailogClass} ${DomUtils.mfeContainer(enteryPointData?.entrypoint, enteryPointData?.sectionId)}`}
      maskClassName={`p-dailog-focus p-dailog-active${maskClass !== '' ? ' ' + maskClass : ''}`}
      showMaximiseButton={showMaximiseButton}
      showMinimiseButton={showMinimiseButton}
      width={''}
      style={{ ...(modalHeight ? { height: modalHeight } : { height: '100%' }) }}
      onClose={() => onClose && onClose()}
      onMinimiseCallbackOnly={onMinimiseCallbackOnly}
      maskStyle={{ zIndex: `${DialogUtils.getStyleForMask()}` }}
      baseZIndex={DialogUtils.getStyleForMask()}
    />
  );
};
