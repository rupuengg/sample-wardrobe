import { makeLiveUserEntry } from 'mock-values';
import React, { useCallback, useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Core } from 'veronica-ui-component';
import { IconButtonWithBadge } from 'veronica-ui-component/dist/component/core';
import { INavigationEntity } from 'entities';
import { useANAInfo, useEntrypoint } from 'hooks';
import { UrlUtils, encryption, isDevelopmentEnv, isIutEnv, recursionPropertyInsertion } from 'utils';
import { IApplicationState, IUseDispatch, LiveUserActions, WorkspaceActions, updateLiveUserActivePage, useAppDispatch } from 'store';
import { MiniToolbar, OverflowingMenu } from 'components';

const { Container, IconButton, RightClickMenu } = Core;
const Nav: any = Core.NavigationMenu;

interface NavigationMenuProps {
  [x: string]: any;
}

export const NavigationMenu: React.FC<NavigationMenuProps> = (): any => {
  const {
    // path,
    // entrypoint,
    // sectionId,
    expanded,
    mfeFullscreen,
    showNavigation,
    currentUniqueMenuObjectId,
    mfeTitle,
    showCodeLibrary,
    showInventorySearch,
    showMovementSearch,
    showPARASearch,
    navigationBarPinned,
    unReadMessageCount,
    generatedMainMenu,
    showLiveChat,
  } = useSelector((state: IApplicationState) => state.workspace);
  const dispatch: IUseDispatch = useAppDispatch();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { navigation, subNavigation, codeLibrary, inventorySearch, movementSearch } = { ...generatedMainMenu };
  const [openMenu, setOpenMenu] = useState(false);
  const [showNav, setShowNav] = useState(false);
  const menuRef: any = React.createRef();
  const { email } = useANAInfo();

  const { uriPath, uriEntrypoint, uriSectionId, uriDefaultPageInformation, uriIsMainMenu } = useEntrypoint();

  const whenMfeOpen = useCallback((mfe: INavigationEntity) => {
    dispatch(LiveUserActions.setCurrentEntrypoint(mfe.entrypoint || ''));
    dispatch(updateLiveUserActivePage({ ...makeLiveUserEntry({ path: mfe.path, entrypoint: mfe.entrypoint }), key: email || '', module: mfe.path || '' }));
    dispatch(WorkspaceActions.onOpenMFE({ mfeData: { ...mfe } }));
  }, []);

  useEffect(() => {
    if (generatedMainMenu && uriPath && uriEntrypoint) {
      const isExists = (nav: INavigationEntity) => {
        return nav.path === uriPath && nav.entrypoint === uriEntrypoint && nav.sectionId === uriSectionId;
      };

      const searchMenu = (navigation: INavigationEntity[]): INavigationEntity | undefined => {
        for (const nav of navigation) {
          if (nav.type === 'Group' || nav.separator) continue;
          if (isExists(nav)) return nav;

          if (nav.submenu && nav.submenu.length > 0) {
            const result = searchMenu(nav.submenu);
            if (result) return result;
          }
        }
      };

      const result = searchMenu(generatedMainMenu.navigation || []);
      if (result) whenMfeOpen({ ...result, defaultPageInformation: uriDefaultPageInformation, isMainMenu: uriIsMainMenu });
    }
  }, [generatedMainMenu.navigation, uriPath, uriEntrypoint, uriSectionId, uriDefaultPageInformation, uriIsMainMenu]);

  const command = useCallback((e: INavigationEntity): void => {
    if (!e.submenu) {
      searchParams.delete('defaultPageInformation');
      navigate({
        pathname: UrlUtils.makeRouteWidthoutSearch(e.entrypoint, encryption(e.path + ' ' + e.entrypoint + ' ' + e.defaultPageInformation + ' ' + e.sectionId + ' ' + e.isMainMenu)),
        search: `?${searchParams.toString()}`,
      });
    }
  }, []);

  const subModuleCommand = (e: any): void => {
    if (!e.submenu) {
      e.isMainMenu = false;
      searchParams.delete('defaultPageInformation');
      navigate({
        pathname: UrlUtils.makeRouteWidthoutSearch(e.item.entrypoint, encryption(e.item.path + ' ' + e.item.entrypoint + ' ' + e.item.defaultPageInformation + ' ' + e.item.sectionId + ' ' + e.isMainMenu)),
        search: `?${searchParams.toString()}`,
      });
    }
  };

  const modifiedNav = recursionPropertyInsertion(navigation, { command });
  const subModuleNav = recursionPropertyInsertion(subNavigation, { command: subModuleCommand });

  const dispatchCallback = (e: any, key: string) => {
    if (e) {
      const event = new CustomEvent(key, {});
      document.dispatchEvent(event);
    }
  };

  const libraryHandler = (e: any) => {
    dispatch(WorkspaceActions.showCodeLibrary(!showCodeLibrary));
    dispatchCallback(e, 'showCodeLibrary');
  };

  const inventorySearchHandler = (e: any) => {
    dispatch(WorkspaceActions.showInventorySearch(!showInventorySearch));
    dispatchCallback(e, 'showInventorySearch');
  };

  const movementSearchHandler = (e: any) => {
    dispatch(WorkspaceActions.showMovementSearch(!showMovementSearch));
    dispatchCallback(e, 'showMovementSearch');
  };

  const PARASearchHandler = (e: any) => {
    dispatch(WorkspaceActions.showPARASearch(!showPARASearch));
    dispatchCallback(e, 'showPARASearch');
  };

  const clickMenuItems = {
    forPin: [
      {
        label: 'Pin',
        command: () => dispatch(WorkspaceActions.showPARASearch(true)),
      },
    ],
    forUnpin: [
      {
        label: 'Unpin',
        command: () => dispatch(WorkspaceActions.showPARASearch(false)),
      },
    ],
  };

  const handleToggle = useCallback((isOpen: boolean) => {
    if (isOpen) dispatch(WorkspaceActions.hideLiveChat(false));
    setOpenMenu(isOpen);
  }, []);

  const handleLiveUser = useCallback(() => {
    dispatch(WorkspaceActions.showLiveChat(!showLiveChat));
  }, [showLiveChat]);

  const cntrSearchBtnComp = <IconButton fileName='Icon-cntr-search' toolTipArrow={false} toolTipText='Container Search' toolTipPlacement='right' onClick={(e: any) => inventorySearchHandler(e)} />;
  const movementSearchBtnComp = <IconButton fileName='Icon-movement-search' toolTipArrow={false} toolTipText='Movement Search' toolTipPlacement='right' onClick={(e: any) => movementSearchHandler(e)} />;
  const PARASearchBtnComp = <IconButton fileName='Icon-RA_PA_search' toolTipArrow={false} toolTipText='PA/RA Search' toolTipPlacement='right' onClick={(e: any) => PARASearchHandler(e)} />;
  return (
    <>
      <div className={`navigation-menu ${expanded ? 'expanded' : ''}${openMenu || showLiveChat ? ' open' : ''} ${mfeFullscreen ? (!showNav ? (!navigationBarPinned ? 'overlay-active' : '') : '') : ''}`}>
        <Container borderRadius='roundAll' height='100%' theme='theme3' width='100%' style={{ overflow: 'visible' }}>
          {/* Brand Icon */}
          <div className='brand-icon-wrapper'>
            <span className='brand-icon'></span>
          </div>

          {/* Horizontal seprator between hamburger and Brand Icon */}
          <div className='horizontal-seprator'>
            <span></span>
          </div>

          {/* Hamburger Menu List */}
          <Nav menuItems={modifiedNav} onSubMenuExpend={true} toggleMenu={handleToggle} onSubMenuLeave={(e: boolean) => setShowNav(e)} />

          {/* Horizontal seprator between hamburger and sub navigation */}
          <div className='horizontal-seprator'>
            <span></span>
          </div>

          {/* Sub navigation based on menu selection */}
          <div id='ws-menu-icons' className='menu-icons'>
            {showNavigation &&
              subModuleNav
                ?.filter((item: any) => item.uniqueMenuObjectId === currentUniqueMenuObjectId)
                .filter((item: any, index: number, self: any) => self.findIndex((obj: any) => obj.uniqueMenuObjectId === item.uniqueMenuObjectId && obj.entrypoint === item.entrypoint && obj.path === item.path && obj.title === item.title) === index)
                ?.map((item: any, i: number) => {
                  return item.separator ? (
                    <div key={i} className='horizontal-seprator'>
                      <span></span>
                    </div>
                  ) : (
                    <div key={i} className={`icon-wrapper icon-wrapper-${item.entrypoint}`}>
                      {item.navigationList ? (
                        <OverflowingMenu menuItem={item} />
                      ) : (
                        <IconButton fileName={item.icon ?? 'Icon-doc'} toolTipArrow={false} toolTipPlacement='right' toolTipText={item.title} enabled={item.title === mfeTitle} onClick={() => command(item)} />
                      )}
                    </div>
                  );
                })}

            <div id='ws-menu-icons-portal'></div>

            {/* Show common icon buttons */}
            <div className='general-menu-icon'>
              {showNavigation && subModuleNav?.filter((item: any) => item.uniqueMenuObjectId === currentUniqueMenuObjectId).length !== 0 && (
                <div className='horizontal-seprator'>
                  <span></span>
                </div>
              )}

              {inventorySearch && inventorySearch[0] && cntrSearchBtnComp}

              {movementSearch && movementSearch[0] && (isDevelopmentEnv || isIutEnv) ? movementSearchBtnComp : null}

              {PARASearchBtnComp}

              {codeLibrary && codeLibrary[0] && <IconButton fileName='Icon-book' toolTipArrow={false} toolTipText='Code Library' toolTipPlacement='right' onClick={(e: any) => libraryHandler(e)} />}
            </div>
          </div>
          <div style={{ height: '100%' }} onContextMenu={e => menuRef.current.show(e)}></div>

          <div className='horizontal-seprator'>
            <span></span>
          </div>

          {(isDevelopmentEnv || isIutEnv) && (
            <div className='action-buttons' style={{ display: 'flex', justifyContent: 'center' }}>
              <IconButtonWithBadge value={unReadMessageCount?.toString()} fileName='Icon-alarm' size='medium' toolTipArrow={true} toolTipPlacement='right' toolTipText='Live Users' onClick={handleLiveUser} />
              <div id='real-time-user-chat-section' style={{ display: !openMenu && showLiveChat ? 'block' : 'none' }} />
              <div className='seprator'>
                <span></span>
              </div>
            </div>
          )}

          {/* User profile and setting menu */}
          <MiniToolbar />
        </Container>
      </div>
      <RightClickMenu className='pin-toolbar-menu' element={menuRef} items={navigationBarPinned ? clickMenuItems.forUnpin : clickMenuItems.forPin} onMouseLeave={e => menuRef.current.hide(e)} />
    </>
  );
};
