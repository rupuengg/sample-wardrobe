import classNames from 'classnames';
import React, { useEffect, useRef } from 'react';
import ReactDOM from 'react-dom';

const CLASSNAME = 'inner-child';

interface IDataManagementContentSectionBind {
  divId: string;
  component: React.JSX.Element;
  className?: string;
}

export const DataManagementContentSectionBind: React.FC<IDataManagementContentSectionBind> = ({ divId, component, className }) => {
  const portalRootRef = useRef(document.getElementById(divId));
  const portalDivRef = useRef(document.createElement('div'));

  useEffect(() => {
    if (portalRootRef.current) {
      const oldAbramIconMenuEle = portalRootRef.current.getElementsByClassName(CLASSNAME).item(0);
      if (oldAbramIconMenuEle !== null) portalRootRef.current.removeChild(oldAbramIconMenuEle);

      if (portalDivRef.current.parentElement !== portalRootRef.current) {
        portalDivRef.current.className = classNames(CLASSNAME, className);
        portalRootRef.current.innerHTML = '';
        portalRootRef.current.append(portalDivRef.current);
      }

      return () => oldAbramIconMenuEle?.remove();
    }
  }, []);

  return ReactDOM.createPortal(component, portalDivRef.current);
};
