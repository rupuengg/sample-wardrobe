import { configure, mount } from 'enzyme';
import Adapter from '@cfaester/enzyme-adapter-react-18';
import { SendMessage } from 'components';

configure({ adapter: new Adapter() });

describe('SendMessage', () => {
  it('Render <SendMessage /> component', () => {
    const wrapper = mount(<SendMessage onChange={jest.fn()} onSend={() => {}} />);
    expect(wrapper.find('.chat-input').length).toBe(1);
  });

  it('Render <SendMessage /> component when text change', () => {
    const mockOnChange = jest.fn();
    const wrapper = mount(<SendMessage onChange={mockOnChange} onSend={() => {}} />);
    wrapper.find('input[type="text"]').simulate('change', { target: { value: 'Hi' } });
    expect(wrapper.find('.chat-input').length).toBe(1);
    expect(mockOnChange).toBeCalled();
  });

  it('Render <SendMessage /> component when text enter key press', () => {
    const mockOnEnter = jest.fn();
    const wrapper = mount(<SendMessage onChange={jest.fn()} onSend={mockOnEnter} />);
    wrapper.find('input[type="text"]').simulate('keyup', { target: { value: 'Hi' }, key: 'Enter' });
    expect(wrapper.find('.chat-input').length).toBe(1);
    expect(mockOnEnter).toBeCalled();
  });

  it('Render <SendMessage /> component when Image select', () => {
    const mockOnEnter = jest.fn();
    const wrapper = mount(<SendMessage onChange={jest.fn()} onSend={mockOnEnter} />);
    wrapper.find('.chat-input a.icon-link').simulate('click', { target: { value: 'Hi' } });
    // wrapper.find('input[type="file"]').simulate('changeCapture', { target: { files: [new Blob()] } });
    expect(wrapper.find('.chat-input').length).toBe(1);
    // expect(mockOnEnter).toBeCalled();
  });

  it('Render <SendMessage /> component when text and click on button', () => {
    const mockOnChange = jest.fn();
    const wrapper = mount(<SendMessage onChange={mockOnChange} onSend={() => {}} />);
    wrapper.find('input[type="text"]').simulate('change', { target: { value: 'Hi' } });
    wrapper.find('a.icon-send').simulate('click');
    expect(wrapper.find('.chat-input').length).toBe(1);
    expect(mockOnChange).toBeCalled();
  });
});
