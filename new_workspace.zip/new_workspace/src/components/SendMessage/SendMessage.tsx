import { useCallback, useMemo, useRef, useState } from 'react';
import { PhotoProvider, PhotoView } from 'react-photo-view';
import { Core } from 'veronica-ui-component';
import { E_Message_Type } from 'enums';
import { AudioRecorder, useAudioRecorder } from 'module/AudioRecoder';

export interface ISendMessage {
  onChange: (e: string) => void;
  onSend: (type: E_Message_Type, message: string) => void;
}

export const SendMessage: React.FC<ISendMessage> = props => {
  const { onChange, onSend } = props;
  const recorderControls = useAudioRecorder({ noiseSuppression: true, echoCancellation: true });
  const [value, setValue] = useState<string>('');
  const [clipboardImageData, setClipboardImageData] = useState<string>('');

  const imagePreview = useMemo(
    () =>
      clipboardImageData && (
        <div className='chat-image-preview'>
          <PhotoProvider>
            <PhotoView src={clipboardImageData}>
              <img src={clipboardImageData} alt='' />
            </PhotoView>
          </PhotoProvider>
          <Core.IconButton
            fileName='Icon-cross'
            className='cross-image-preview'
            size='small'
            tooltipDisable={true}
            onClick={() => {
              setClipboardImageData('');
            }}
          />
        </div>
      ),
    [clipboardImageData]
  );

  const inputFileRef = useRef<HTMLInputElement | null>(null);

  const handleChange = useCallback((e: any) => {
    setValue(e.target.value);
    onChange(e.target.value.toString());
  }, []);

  const chatEnter = useCallback(
    (e: any) => {
      if (e.key === 'Enter') {
        if (clipboardImageData) {
          onSend(E_Message_Type.IMAGE, clipboardImageData);
          setClipboardImageData('');
        } else {
          if (e.target.value.toString() !== '') {
            onSend(E_Message_Type.TEXT, value);
            setValue('');
          }
        }
      }
    },
    [value, clipboardImageData]
  );

  const onFileChangeCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const file = e.target.files[0];
      const imageBase64 = (await blobToBase64(file)) as string;
      onSend(E_Message_Type.IMAGE, imageBase64);
    }
  };

  const blobToBase64 = (blob: Blob | File) => {
    return new Promise(resolve => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.readAsDataURL(blob);
    });
  };

  const onRecordingComplete = async (blob: Blob) => {
    const audioBase64 = (await blobToBase64(blob)) as string;
    onSend(E_Message_Type.VOICE, audioBase64);
  };

  const buttonClickHandler = () => {
    if (clipboardImageData) {
      onSend(E_Message_Type.IMAGE, clipboardImageData);
      setClipboardImageData('');
    } else {
      onSend(E_Message_Type.TEXT, value);
      setValue('');
    }
  };

  const pasteHandler = async (e: any) => {
    const imageFile = (await blobToBase64(e.clipboardData.files[0])) as string;
    setClipboardImageData(imageFile);
  };

  return (
    <div className='chat-input'>
      {imagePreview}
      <div className='chat-input-tools'>
        {!recorderControls.isRecording && (
          <>
            <input type='file' ref={inputFileRef} className='file-choose' style={{ display: 'none' }} onChangeCapture={onFileChangeCapture} accept='image/png, image/gif, image/jpeg, image/webp' />
            <Core.IconButton fileName='Icon-link' className='chat-buttons' tooltipDisable={true} onClick={() => inputFileRef.current?.click()} />
            <input type='text' value={value} placeholder='Type here...' contentEditable={true} onChange={handleChange} onKeyUp={e => chatEnter(e)} onPaste={pasteHandler} />
            <Core.IconButton fileName='Icon-send' className='chat-buttons' tooltipDisable={true} onClick={buttonClickHandler} />
          </>
        )}
        <AudioRecorder onRecordingComplete={onRecordingComplete} recorderControls={recorderControls} showVisualizer={true} />
      </div>
    </div>
  );
};
