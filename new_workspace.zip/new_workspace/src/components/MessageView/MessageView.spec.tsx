import { defaultLiveUserChatMessage } from 'mock-values';
import { configure, mount } from 'enzyme';
import Adapter from '@cfaester/enzyme-adapter-react-18';
import { LiveUserChatMessage } from 'entities';
import { E_Message_Type } from 'enums';
import { MessageView } from 'components';

configure({ adapter: new Adapter() });

const defaultProps: LiveUserChatMessage = { ...defaultLiveUserChatMessage };

describe('MessageView', () => {
  it('Render <MessageView /> component for TEXT', () => {
    const wrapper = mount(<MessageView chat={{ ...defaultProps, message: 'Hello', messageType: E_Message_Type.TEXT }} />);
    expect(wrapper.find('.message-container').length).toBe(1);
    expect(wrapper.find('.message-container .chat-text').length).toBe(1);
    expect(wrapper.find('.message-container .chat-text').text()).toBe('Hello');
  });

  it('Render <MessageView /> component for Voice', () => {
    const wrapper = mount(<MessageView chat={{ ...defaultProps, message: 'Voice', messageType: E_Message_Type.VOICE }} />);
    expect(wrapper.find('.message-container').length).toBe(1);
    expect(wrapper.find('.message-container .chat-audio').length).toBe(1);
  });

  it('Render <MessageView /> component for Image', () => {
    const wrapper = mount(<MessageView chat={{ ...defaultProps, message: 'Image', messageType: E_Message_Type.IMAGE }} />);
    expect(wrapper.find('.message-container').length).toBe(1);
    expect(wrapper.find('.message-container .chat-image').length).toBe(1);
  });
});
