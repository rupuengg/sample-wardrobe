import moment from 'moment';
import { useMemo } from 'react';
import { PhotoProvider, PhotoView } from 'react-photo-view';
import { LiveUserChatMessage } from 'entities';
import { E_Message_Type } from 'enums';

export interface IMessageView {
  chat: LiveUserChatMessage;
}

export const MessageView: React.FC<IMessageView> = ({ chat }) => {
  const singleMessageElement = useMemo(() => {
    switch (chat.messageType) {
      case E_Message_Type.VOICE:
        return <audio className='chat-audio' controls src={chat.message} />;
      case E_Message_Type.TEXT:
        return <span className='chat-text'>{chat.message}</span>;
      case E_Message_Type.IMAGE:
        return (
          <PhotoProvider>
            <PhotoView src={chat.message}>
              <img className='chat-image' src={chat.message} height={100} alt='image' />
            </PhotoView>
          </PhotoProvider>
        );
    }
  }, [chat.message, chat.messageType]);

  const messageDateTime = useMemo(() => chat.chatOn && <div className='chat-date'>{moment(Number(chat.chatOn)).calendar(null, { sameElse: 'DD/MM/YYYY HH:MM A' })}</div>, [chat.chatOn]);

  return (
    <div className='message-container'>
      {messageDateTime}
      {singleMessageElement}
    </div>
  );
};
