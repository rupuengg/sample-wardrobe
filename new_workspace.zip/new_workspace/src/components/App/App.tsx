import { usePreventZoom } from 'usePreventZoom';
import { Provider } from 'react-redux';
import { HashRouter } from 'react-router-dom';
import { store } from 'store';
import { Layout } from 'components';

export const App = () => {
  usePreventZoom();

  return (
    <Provider store={store}>
      <HashRouter basename='/' future={{ v7_startTransition: true }}>
        <Layout />
      </HashRouter>
    </Provider>
  );
};
