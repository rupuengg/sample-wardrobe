export interface INotAccess {
  text?: string;
}

export const NotAccess: React.FC<INotAccess> = ({ text }: INotAccess) => {
  return (
    <div className='under-construction'>
      <div className='inner-wrapper'>
        <i className='icon-alert-circle-fill'></i>
        <p>{text}</p>
      </div>
    </div>
  );
};
