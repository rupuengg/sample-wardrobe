import { defaultEntityStatusDataEntity, makeLiveUserEntry } from 'mock-values';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import 'react-photo-view/dist/react-photo-view.css';
import { useSelector } from 'react-redux';
import { IEntityStatusDataEntity, LiveUserEntity } from 'entities';
import { E_Data_Load_Status, E_Message_Type, E_User_Status, E_WebSock_Topic, E_WebSocketActions } from 'enums';
import { E_Custom_Dispatch_Event, E_Type_Of_Event, customDispatchEvent, customEventListener } from 'helpers';
import { useANAInfo, useWSLiveUser, useWSLiveUserChat } from 'hooks';
import { IApplicationState, IUseDispatch, LiveUserActions, WebSocketService, closeLiveUserChat, getLiveUsersByBU, sendLiveUserChat, tokenReference, updateLiveUserActivePage, useAppDispatch } from 'store';
import { ChatBox, DataManagementContentSectionBind, LiveUserSingleChat, Search } from 'components';

export const LiveUser = () => {
  const { users, activeUserId, typing, totalUnreadCount } = useSelector((state: IApplicationState) => state.liveUser);
  const dispatch: IUseDispatch = useAppDispatch();
  const startRef = useRef<IEntityStatusDataEntity>(defaultEntityStatusDataEntity);
  const { email, currentBu } = useANAInfo();
  const [chatBoxFromTop, setChatBoxFromTop] = useState<number>(0);

  const [txt, setTxt] = useState<string>('');

  const activeUsers = useMemo(() => Object.values(users).filter(u => u.key !== email && u.status === E_User_Status.ONLINE), [users]);
  const inactiveUsers = useMemo(() => Object.values(users).filter(u => u.key !== email && u.status !== E_User_Status.ONLINE), [users]);
  const activeUser = useMemo(() => (activeUserId && users[activeUserId] ? users[activeUserId] : undefined), [users, activeUserId]);

  const wsInstance = useMemo(() => {
    let ws = WebSocketService.getInstance();
    if (!ws.connecting && !ws.connected) {
      ws = WebSocketService.getInstance();
      ws.email = email;
      ws.token = tokenReference.token;

      ws.connect();
    }

    return ws;
  }, [email]);

  // Live user WS
  useWSLiveUser(email ?? '', dispatch, users);

  // Live user WS
  useWSLiveUserChat(email ?? '', dispatch);

  // Load Live Users
  useEffect(() => {
    if (startRef.current.setCurrentBU === E_Data_Load_Status.NOT_YET_STARTED) {
      startRef.current = { ...startRef.current, setCurrentBU: E_Data_Load_Status.PENDING };
      dispatch(LiveUserActions.setCurrentBU(currentBu));
    }
  }, [currentBu]);

  // Load Live Users
  useEffect(() => {
    if (startRef.current.list === E_Data_Load_Status.NOT_YET_STARTED && email) {
      startRef.current = { ...startRef.current, list: E_Data_Load_Status.PENDING };
      dispatch(getLiveUsersByBU({ bu: currentBu, email }));
    }
  }, [currentBu, email]);

  const handleChange = useCallback(
    (e: string) => {
      if (activeUser && email && wsInstance.stompClient) {
        wsInstance.stompClient.publish({
          destination: E_WebSock_Topic.TOPIC_LIVE_USER_CHAT_MESSAGE,
          body: JSON.stringify({ action: E_WebSocketActions.CREATE, itemAsString: JSON.stringify({ fromUser: email, toUser: activeUser.key, message: 'Typing...' }) }),
        });
        setTxt(e);
      }
    },
    [activeUser, email, wsInstance.stompClient]
  );

  const chatEnter = useCallback(
    (messageType: E_Message_Type, message: string) => {
      if (message && activeUser && email) {
        dispatch(sendLiveUserChat({ fromUser: email, toUser: activeUser.key, messageType, message }));
        setTxt('');
      }
    },
    [activeUser, dispatch, email]
  );

  const handleAddChatUser = useCallback(
    (e: any, user: LiveUserEntity) => {
      e.preventDefault();
      if (activeUser && activeUser.email !== activeUserId) handleCloseChatUser(activeUser);
      dispatch(LiveUserActions.setActiveUserId(user.email));

      setTimeout(() => {
        const chatBox = document.querySelector('.main-box .chat-box .live-chat-box');
        const totalHeight = document.querySelector('.main-box .chat-box')?.clientHeight;
        const positionFromTop = document.querySelector('.main-box .chat-box .inline-chat.open')?.getBoundingClientRect().top;
        const height = chatBox?.getBoundingClientRect().height;
        if (totalHeight && positionFromTop && height) {
          if (totalHeight - positionFromTop > height) setChatBoxFromTop(positionFromTop - 6);
          else setChatBoxFromTop(positionFromTop - 400 + 30 - 2);
        }
      }, 0);
    },
    [dispatch, activeUser, email]
  );

  const handleRemoveActiveUser = useCallback(
    (user: LiveUserEntity) => {
      dispatch(LiveUserActions.removeActiveUserId());
      handleCloseChatUser(user);
    },
    [dispatch]
  );

  const handleCloseChatUser = useCallback(
    (user: LiveUserEntity) => {
      dispatch(closeLiveUserChat({ fromUser: email || '', toUser: user.key, messageType: E_Message_Type.TEXT, message: txt }));
    },
    [dispatch, email]
  );

  const handleSearch = useCallback(
    (searchText: string) => {
      dispatch(LiveUserActions.filterLiveUser(searchText));
    },
    [dispatch, email]
  );

  useEffect(() => {
    return () => {
      if (activeUser) handleCloseChatUser(activeUser);
    };
  }, []);

  useEffect(() => {
    customDispatchEvent(E_Type_Of_Event.DATA_MANAGEMENT_EVENT, E_Custom_Dispatch_Event.DM_LIVE_USER_UNREAD_MESSAGE_COUNT, { unreadCount: totalUnreadCount });
  }, [totalUnreadCount]);

  useEffect(() => {
    customEventListener(E_Type_Of_Event.DATA_MANAGEMENT_EVENT, (e: any) => {
      e.stopImmediatePropagation();
      const data = e.detail.data;
      switch (e.detail.action) {
        case E_Custom_Dispatch_Event.DM_OPEN_NEW_MFE:
          dispatch(LiveUserActions.setCurrentEntrypoint(data.entrypoint));
          dispatch(updateLiveUserActivePage({ ...makeLiveUserEntry({ path: data.path, entrypoint: data.entrypoint }), key: email || '', module: data.path }));
          break;
        // case E_Custom_Dispatch_Event.DM_CLOSE_NEW_MFE:
        //     dispatch(LiveUserActions.setCurrentEntrypoint(''));
        //     dispatch(clearLiveUserActivePage({ ...makeLiveUserEntry({ path: data.path, entrypoint: data.entrypoint }), key: email || '', module: data.path }));
        //     break;
        default:
          break;
      }
    });
  }, []);

  const liveUserBox = useCallback(
    (tmpUsers: LiveUserEntity[]) =>
      tmpUsers
        .sort((userA, userB) => (userA.fullName > userB.fullName ? 1 : userA.fullName < userB.fullName ? -1 : 0))
        .map(user => (
          <li key={user.key} className={`inline-chat ${activeUser && activeUser.email === user.email ? 'open' : ''}`}>
            <a className='user-name' href='' onClick={e => handleAddChatUser(e, user)}>
              {user.fullName}
              {user.unReadCount && user.unReadCount > 0 ? <sup>{user.unReadCount}</sup> : null}
            </a>
          </li>
        )),
    [activeUser, email, txt, typing]
  );

  return (
    <div className='main-box'>
      <div className='chat-box' style={{ width: '200px' }}>
        <div className='live-users'>
          <div className='live-users-search'>
            <Search onSearch={handleSearch} />
          </div>

          <span className='group-title'>Active Users</span>
          <ul className='user-list'>{liveUserBox(activeUsers)}</ul>

          <span className='group-title'>Inactive Users</span>
          <ul className='user-list'>{liveUserBox(inactiveUsers)}</ul>

          <ChatBox top={chatBoxFromTop} onTyping={handleChange} onSend={chatEnter} onClose={handleRemoveActiveUser} />
        </div>
      </div>
      <DataManagementContentSectionBind divId='real-time-user-section' component={<LiveUserSingleChat />} />
    </div>
  );
};
