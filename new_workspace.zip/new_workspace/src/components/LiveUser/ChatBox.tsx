import { useMemo } from 'react';
import { useSelector } from 'react-redux';
import { LiveUserEntity } from 'entities';
import { E_Message_Type } from 'enums';
import { IApplicationState } from 'store';
import { MessageList, SendMessage } from 'components';

export interface IChatBox {
  top: number;
  onClose: (user: LiveUserEntity) => void;
  onTyping: (txt: string) => void;
  onSend: (messageType: E_Message_Type, message: string) => void;
}

export const ChatBox: React.FC<IChatBox> = ({ top, onClose, onTyping, onSend }) => {
  const { users, activeUserId } = useSelector((state: IApplicationState) => state.liveUser);
  const activeUser = useMemo(() => (activeUserId && users[activeUserId] ? users[activeUserId] : undefined), [users, activeUserId]);

  if (!activeUser) return null;

  return (
    <div className='live-chat-box' style={{ top: top + 'px' }}>
      <div className={`inner-child-box`}>
        <div className='group-title close'>
          {activeUser.fullName}
          <span onClick={() => onClose(activeUser)}></span>
        </div>
        <MessageList key={activeUser.email} />
        <SendMessage onChange={onTyping} onSend={onSend} />
      </div>
    </div>
  );
};
