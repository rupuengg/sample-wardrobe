import { defaultEntityStatusDataEntity } from 'mock-values';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { IEntityStatusDataEntity } from 'entities';
import { E_Data_Load_Status } from 'enums';
import { useANAInfo } from 'hooks';
import { IApplicationState, IUseDispatch, getAllByUserMessages, useAppDispatch } from 'store';
import { MessageView } from 'components';

export const MessageList: React.FC = () => {
  const { users, activeUserId, typing } = useSelector((state: IApplicationState) => state.liveUser);
  const dispatch: IUseDispatch = useAppDispatch();
  const startRef = useRef<IEntityStatusDataEntity>(defaultEntityStatusDataEntity);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageLimit] = useState<number>(50);
  const [lastScroll, setLastScroll] = useState<number>(0);
  const divRef: any = useRef(null);
  const { email } = useANAInfo();

  const activeUser = useMemo(() => (activeUserId && users[activeUserId] ? users[activeUserId] : undefined), [users, activeUserId]);

  const getMessages = useCallback((activeUserEmail: string, page: number, limit: number) => {
    if (startRef.current.getLiveUserChatSatus === E_Data_Load_Status.NOT_YET_STARTED && currentPage !== (activeUser?.liveUserChat?.chatPage || 0)) {
      startRef.current = { ...startRef.current, getLiveUserChatSatus: E_Data_Load_Status.PENDING };
      dispatch(getAllByUserMessages({ fromUser: email || '', toUser: activeUserEmail, page, limit }));
    }
  }, []);

  useEffect(() => {
    if (activeUserId) getMessages(activeUserId, currentPage, pageLimit);
  }, [activeUserId]);

  // Scroll Effect
  useEffect(() => {
    const cbScroll = (e: any) => {
      if (activeUser && activeUser?.liveUserChat && activeUser?.liveUserChat?.chatPage && activeUser?.liveUserChat?.chatLastPage && activeUser?.liveUserChat?.chatPage <= activeUser?.liveUserChat?.chatLastPage && e.currentTarget.scrollTop === 0) {
        if (e.currentTarget.scrollTop === 0) {
          setLastScroll(e.currentTarget.querySelector('li.last').offsetTop + 319);
        }

        if (activeUserId && activeUser) {
          startRef.current = { ...startRef.current, getLiveUserChatSatus: E_Data_Load_Status.NOT_YET_STARTED };
        }

        const newPage = activeUser?.liveUserChat?.chatPage + 1;
        setCurrentPage(newPage);
        if (activeUserId) getMessages(activeUserId, newPage, 50);
      }
    };

    if (divRef.current) {
      divRef.current.addEventListener('scroll', cbScroll);
    }

    return () => {
      if (divRef.current) {
        divRef.current.removeEventListener('scroll', cbScroll);
      }
    };
  }, [activeUser]);

  useEffect(() => {
    if (divRef.current && lastScroll !== 0) {
      divRef.current.scrollTop = lastScroll;
    } else if (divRef.current && lastScroll === 0) {
      divRef.current.scrollTop = divRef.current.scrollHeight;
    }
  }, [activeUser?.liveUserChat?.chat, lastScroll, divRef]);

  if (!activeUser) return null;

  return (
    <ul ref={divRef} className='chat-list'>
      {activeUser.liveUserChat && activeUser.liveUserChat?.chatLastPage && activeUser.liveUserChat?.chatPage && activeUser.liveUserChat?.chatPage < activeUser.liveUserChat?.chatLastPage && <li style={{ textAlign: 'center' }}>Loading More...</li>}
      {activeUser.liveUserChat?.chat &&
        activeUser.liveUserChat?.chat?.map((u, index) => (
          <li key={u.chatOn} className={`${u.fromUser === email ? 'right' : 'left'}${index === pageLimit - 1 ? ' last' : ''}`}>
            <MessageView chat={u} />
          </li>
        ))}
      {typing && typing.fromUser === activeUser.key && (
        <li key='typing' className='typing left'>
          {typing.message}
        </li>
      )}
    </ul>
  );
};
