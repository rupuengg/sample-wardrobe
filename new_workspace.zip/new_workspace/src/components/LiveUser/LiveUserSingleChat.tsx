import { useCallback, useMemo } from 'react';
import { useSelector } from 'react-redux';
import { LiveUserEntity } from 'entities';
import { E_Message_Type, E_WebSock_Topic, E_WebSocketActions } from 'enums';
import { useANAInfo } from 'hooks';
import { IApplicationState, IUseDispatch, LiveUserActions, WebSocketService, sendLiveUserChat, tokenReference, useAppDispatch } from 'store';
import { MessageList, SendMessage } from 'components';

export const LiveUserSingleChat = () => {
  const { activeUserId, users, currentEntrypoint } = useSelector((state: IApplicationState) => state.liveUser);
  const dispatch: IUseDispatch = useAppDispatch();
  const { email } = useANAInfo();

  const tmpUsers = useMemo(() => (currentEntrypoint !== '' ? Object.values(users).filter(user => user.key !== email && user.entrypoint === currentEntrypoint) : []), [currentEntrypoint, email, users]);

  const wsInstance = useMemo(() => {
    let ws = WebSocketService.getInstance();
    if (!ws.connecting && !ws.connected) {
      ws = WebSocketService.getInstance();
      ws.email = email;
      ws.token = tokenReference.token;

      ws.connect();
    }

    return ws;
  }, [email]);

  const chatUser = useCallback(
    (user: LiveUserEntity) => {
      if (activeUserId) dispatch(LiveUserActions.removeActiveUserId());
      else dispatch(LiveUserActions.setActiveUserId(user.email));
    },
    [email, activeUserId]
  );

  const handleChange = useCallback(
    (e: string, user: LiveUserEntity) => {
      if (user && email) {
        wsInstance.stompClient?.publish({
          destination: E_WebSock_Topic.TOPIC_LIVE_USER_CHAT_MESSAGE,
          body: JSON.stringify({ action: E_WebSocketActions.CREATE, itemAsString: JSON.stringify({ fromUser: email, toUser: user.key, message: 'Typing...' }) }),
        });
      }
    },
    [email, wsInstance.stompClient]
  );

  const chatEnter = useCallback(
    (messageType: E_Message_Type, message: string, user: LiveUserEntity) => {
      if (message && email) {
        dispatch(sendLiveUserChat({ fromUser: email, toUser: user.key, messageType, message }));
      }
    },
    [email]
  );

  if (!tmpUsers || (tmpUsers && tmpUsers.length === 0)) return null;

  return (
    <div className='inner-box main-box'>
      <ul className='live-user-lists'>
        {tmpUsers.map((user, index) => (
          <li key={user.key}>
            <span className={`info ${user.email === activeUserId ? 'active' : ''}`} color={(index + 1).toString()}>
              <b className='first'>{user.shortName}</b>
              <b className='full-name' onClick={() => chatUser(user)}>
                {user.fullName}
              </b>
              {user.email === activeUserId && (
                <div className='chat_list'>
                  <div className={'open'}>
                    <MessageList />
                    <SendMessage onChange={e => handleChange(e, user)} onSend={(messageType: E_Message_Type, message: string) => chatEnter(messageType, message, user)} />
                  </div>
                </div>
              )}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
};
