import { IBaseEntity } from 'entities';

export interface EquipmentCodeEntity extends IBaseEntity {
  equipmentCode: string;
  description: string;
  nature: string;
  isSystemDefined: boolean;
  toBeDelete: boolean;
}
