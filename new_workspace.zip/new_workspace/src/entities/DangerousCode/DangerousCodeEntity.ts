import { IBaseEntity } from 'entities';
import { IncompatibleImdgEntity } from './IncompatibleImdgEntity';

export interface DangerousCodeEntity extends IBaseEntity {
  imdgCode: string;
  imdgGoodsName?: string;
  compatibleImdg?: string[];
  incompatibleImdg?: IncompatibleImdgEntity[];
  toBeDelete: boolean;
}
