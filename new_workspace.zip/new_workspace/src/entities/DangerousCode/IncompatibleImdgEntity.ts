import { IBaseEntity } from 'entities';

export interface IncompatibleImdgEntity extends IBaseEntity {
  imdgCode: string;
  minSegregationDistanceStack: number;
  minSegregationDistanceMeter: number;
  flag_edit?: boolean;
}
