import { IBaseEntity } from 'entities';

export interface CountryEntity extends IBaseEntity {
  countryCode: string;
  countryName: string;
  countryNameLocalized?: string;
}
