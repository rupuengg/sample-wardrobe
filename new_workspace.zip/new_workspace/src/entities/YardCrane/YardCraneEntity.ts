import { IBaseEntity } from 'entities';

export interface YardCraneEntity extends IBaseEntity {
  yardCraneNo: string;
  yardCraneType: string;
  yardCraneSubType: string;
  heightLimitInFeet?: number;
  stackableHeightInFeet?: number;
  operationMode: string;
  isVgmCertified: boolean;
  isTieDown: boolean;
  enableMaintenance: boolean;
  maintenance?: string;
  specialHandling?: string[];
  servingArea: string;
  workloadLimit?: number;
  containerWidthLimitInFeet?: number;
}
