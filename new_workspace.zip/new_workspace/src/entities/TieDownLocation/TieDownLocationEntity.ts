import { IBaseEntity } from 'entities';

export interface TieDownLocationEntity extends IBaseEntity {
  id: string;
  tmlId: string;
  locType: string;
  blockId: string;
  stack: string;
  lane: string;
  tier: string;
  locShortName: string;
  desc: string;
}
