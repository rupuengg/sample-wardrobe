export * from './TieDownLocationEntity';
