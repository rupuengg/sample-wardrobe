import { IBaseEntity } from 'entities';

export interface ReasonCodeEntity extends IBaseEntity {
  type: string;
  code: string;
  category?: string;
  description?: string;
  applyTo?: string[];
  kiosk?: string;

  typeString?: string;
  categoryString?: string;
  applyToString?: string;
}
