import { DataResyncEntity, IAnalyzerMapper, IBaseEntity, IMainApiMapper } from 'entities';

export interface IPipelineSource {
  project?: string;
  label?: string;
  name: string;
  icon?: string;
  dbName?: string;
  tableName?: string;
  count: number;
  nodeId: string;
  parentNodeId?: string;
  sourceEntityName?: string;
  currentStatus?: DataResyncEntity;
  history: DataResyncEntity[];
  parentClassName?: string;
}

export interface IPipelineData {
  sourceName: string;
  mergingSource?: string[];
  mergedSource?: string[];
  sources?: IPipelineSource[];
}

export interface DataManagementEntity extends IBaseEntity {
  pipelineName: string;
  tree?: IPipelineData[];
  domain: string;
  pipelineApi?: IMainApiMapper;
  analyzerDetail?: IAnalyzerMapper;

  createdByProspector: string;
  createdDateTime: string;
  createdByActor: string;
  createdByOprUnit: string;
  updatedByProspector: string;
  updatedDatetime: string;
  updatedByActor: string;
  updatedByOprUnit: string;

  isFirstTimeLoad: boolean;
}
