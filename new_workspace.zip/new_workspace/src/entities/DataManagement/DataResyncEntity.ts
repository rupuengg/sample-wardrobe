import { E_Sync_Status } from 'enums';

export interface DataResyncEntity {
  key: string;
  dataResyncJobId: string;
  apiKey: string;
  firstTriggerBy: string;
  firstTriggerDT: string;
  dataSyncInfo?: string;
  status: E_Sync_Status;
  lastStatusUpdateDT?: string;
  totalCount: string;
  isAPIReady: boolean;
}
