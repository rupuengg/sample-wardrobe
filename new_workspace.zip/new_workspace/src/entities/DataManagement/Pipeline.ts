import { DataManagementEntity } from 'entities';

export interface IApiMapper {
  sync: string;
  recordCount: string;
  status: string;
  abort: string;
}

export interface IMainApiMapper {
  acl: { [x: string]: IApiMapper };
  backend: { [x: string]: IApiMapper };
  downstream: { [x: string]: IApiMapper };
}

export interface ISourceMapping {
  sourceNames: string[];
  destinationNames: string[];
}

export interface IWorkspaceMenuDetail {
  title?: string;
  entrypoint?: string;
  path?: string;
  sectionId?: string;
  defaultPageInformation?: string;
  dataAnalyzerId?: string;
}

export interface IAnalyzerDetail {
  fromSource: string;
  fromEntityName: string;
  toSource: string;
  toEntityName: string;
  dataAnalyzerId: string;
  autoRun?: boolean;
  workspaceMenuDetail: IWorkspaceMenuDetail[];
}

export interface IAnalyzerMapper {
  ods?: IAnalyzerDetail;
  acl?: IAnalyzerDetail;
  backend?: IAnalyzerDetail;
  downstream?: IAnalyzerDetail;
}

export interface IPipelineForm {
  pipeline: string;
  pipelineTitle: string;
  odsSource: string[];
  odsAclSourceMapping: ISourceMapping[];
  aclBackendSourceMapping: ISourceMapping[];
  backendDownStreamMapping: ISourceMapping[];
  domain: string;
  pipelineApi?: IMainApiMapper;
  analyzerDetail?: IAnalyzerMapper;

  versionIdentifier: {
    version?: string;
  };
}

export interface IPipelineJSONError {
  message: string;
  stack: string;
}

export interface IPipeline {
  pipelineForm: IPipelineForm;
  pipelineJSONError?: IPipelineJSONError;
  convertedPipeline?: DataManagementEntity;
  isExists: boolean;
  isCreated: boolean;
  isDeleted: boolean;
  list: IPipelineForm[];
  deletePipeline?: IPipelineForm;
  isPipelineinEditMode: boolean;
}
