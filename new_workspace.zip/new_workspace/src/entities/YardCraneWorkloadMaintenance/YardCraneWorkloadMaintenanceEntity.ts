import { IBaseEntity } from 'entities';

export interface YardCraneMergeBlockEntity extends IBaseEntity {
  blockId: string;
  fromStackNo: string;
  systemCtrlAttributeList: string;
  toStackNo: string;
  ycId: string;
  zoneMode: string;
}

export interface YardCraneWorkloadMaintenanceEntity extends IBaseEntity {
  ycType: string;
  startupTimeMinute: number;
  startupTimeSecond: number;
  focusingTimeMinute: number;
  focusingTimeSecond: number;
  gantryTimeMinute: number;
  gantryTimeSecond: number;
  shuffleLiftingTimeMinute: number;
  shuffleLiftingTimeSecond: number;
  productionLiftingTimeMinute: number;
  productionLiftingTimeSecond: number;
  ycNo: string;
  ycGroup: string;
  maxWorkloadTimeMinute: number;
  maxWorkloadTimeSecond: number;
  currentWorkloadTimeMinute: number;
  currentWorkloadTimeSecond: number;
  minimumSafetyDistance: number;
  currentLocationBlock: string;
  currentLocationStack: string;
  currentLocationLane: string;
  currentLocationTier: string;
  ycZoneFromBlock?: string;
  ycZoneFromStack?: string;
  ycZoneToBlock?: string;
  ycZoneToStack?: string;
  ycCount?: number;
  lastServedLocationBlock?: string;
  lastServedLocationStack?: string;
  yardCraneMergedBlockList: YardCraneMergeBlockEntity[];

  ycTypeString?: string;
  ycSubTypeString?: string;
}

export interface ILoadYardCrane {
  yardCraneId?: string | null | undefined;
  isOpenYcZone?: boolean;
}

export interface YCZoneEntity {
  ycFromBlock?: string;
  ycFromStack?: string;
  ycToBlock?: string;
  ycToStack?: string;
}
