import { IBaseEntity } from 'entities';

export interface PolicyCodeEntity extends IBaseEntity {
  code: string;
  codeScheme: string;
  description: string;
}
