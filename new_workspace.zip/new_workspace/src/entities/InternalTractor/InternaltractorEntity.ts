import { IBaseEntity } from 'entities';

export interface InternalTractorEntity extends IBaseEntity {
  tractorNo: string;
  lastUISetPoolId: string;
  loadingCapacity: number | null;
  pagerNo: string;
  chassisType: string;
  tractorProvidingOprUnit: string;
  itSuspendIndr: string;
  itSuspendFromDatetime: string;
  itSuspendByStaffId: string;
  itSuspendReasonCode: string;
  lastChkptLsTerminalId: string;
  lastChkptLsLocationType: string;
  lastChkptLsLevel1: string;
  lastChkptLsLevel2: string;
  lastChkptLsLevel3: string;
  lastChkptLsLevel4: string;
  itSuspendRemark: string;
  itOperatingStaffId: string;
  internalTractorRemark: string;
  itAssetGroupNo: string;
  itParkingByNo: string;
  outOfServiceIndrSrcList: string;
  securityUserDescription: string;
  lastUIPoolItDeploymentMd: string;
  itChassisNo: string;
  itSuspendActionCode: string;
  itAutomationMode: string;
  itWeightWithoutChassis: number | null;
}
