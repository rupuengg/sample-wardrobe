import { IBaseEntity } from 'entities';

export interface QcMoveLogEntity extends IBaseEntity {
  quayCraneId: string;
  qcMoveInstructionDatetime: string;
  qcMoveInstructionOprSource: string;
  operatingStaffId: string;
  qcMoveOperationalStatus: string;
  qcConfirmedDatetime: string;
  cntrId: string;
  cntrStatus: string;
  movementCntrInterchangeMode: string;
  tractorNo: string;
  companyCode: string;
  vesselCode: string;
  voyageCode: string;
  cntrCountPerSpreaderLift: string;
  berthId: string;
  cwpNo: string;
  bayNo: string;
  deckHold: string;
  rowNo: string;
  tierNo: string;
  terminalId: string;
  locationType: string;
  lsLevel1: string;
  lsLevel2: string;
  lsLevel3: string;
  lsLevel4: string;
  dcProgramNo: string;
  dcSequence: string;
  dcLiftType: string;
  dcOperationExecutedSeq: string;
}
