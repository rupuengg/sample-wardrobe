import { IBaseEntity } from 'entities';

export interface ContainerTypeEntity extends IBaseEntity {
  cntrType: string;
  encodedScheme: string;
  description?: string;
  toBeDelete: boolean;
}
