import { IBaseEntity } from 'entities';

export interface INavigationEntity {
  label?: string;
  title?: string;
  customTitle?: string;
  mainNavTitle?: string[];
  icon?: string;
  url?: string;
  command?: () => any;
  submenu?: INavigationEntity[];
  entrypoint?: string;
  fullscreen?: boolean;
  graphical?: boolean;
  path?: string;
  sectionId?: string | null;
  separator?: boolean;
  type?: string;
  defaultPageInformation?: any;
  subMenuMap?: string;

  uniqueMenuObjectId?: string;
  isNeedSwitchConfirmation?: boolean;
  isMainMenu?: boolean;
}

export interface ISubNavigationEntity {
  title?: string;
  icon?: string;
  customTitle?: string;
  menuName?: string;
  navigationList?: INavigationEntity[];
  onIconClick?: () => any;
  path?: string;
  entrypoint?: string;
  separator?: boolean;
  fullscreen?: boolean;
  graphical?: boolean;

  uniqueMenuObjectId?: string;
}

export interface IModalNavigationEntity {
  path?: string;
  entrypoint?: string;
  sectionId?: string;
}

export interface INavigationAllEntity {
  navigation?: INavigationEntity[];
  subNavigation?: ISubNavigationEntity[];
  codeLibrary?: IModalNavigationEntity[];
  inventorySearch?: IModalNavigationEntity[];
  movementSearch?: IModalNavigationEntity[];
  PARASearch?: IModalNavigationEntity[];
}

export interface IRecursionInterface extends INavigationEntity, ISubNavigationEntity {
  isMainMenu?: boolean;
}

export interface IMenuEntity extends IBaseEntity, INavigationAllEntity {
  menuId: string;
}

export interface PayloadItem {
  key: string;
  value: any;
}

export interface WorkspaceUserPreferenceEntity {
  key?: string;
  userId: string;
  type: string;
  name: string;
  payload: PayloadItem[];
}
