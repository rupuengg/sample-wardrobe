export * from './QcDeploymentEntity';
