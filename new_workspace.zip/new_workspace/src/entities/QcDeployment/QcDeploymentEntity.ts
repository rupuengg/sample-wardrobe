import { AvailablePoolEntity } from '../MsshDeployment/MsshDeploymentEntity';
import { IBaseEntity } from 'entities/BaseEntity';
import { E_Quay_Crane_Status, E_Quay_Crane_Type } from 'enums';

export interface QcDeploymentEntity extends IBaseEntity {
  id: string;
  qcId: string;
  berthId: string;
  berthingTml: string;
  posBittNo: number;
  status: E_Quay_Crane_Status;
  isSpeedUp: boolean;
  isTieDown: boolean;
  isTwinLifting: boolean;
  isTandem: boolean;
  tractor: string[];
  projectedCompletionTime?: string;
  currentQCRate?: string;
  noMovementServiced?: string;
  isBoomUp?: boolean;
  left?: number;
  outreach?: number;
  width?: number;
  heightLmt?: number;
  singleLift?: number;
  twinLift?: number;
  tandemLift?: number;
  qcType?: E_Quay_Crane_Type;
}

export interface QcPoolResponse extends AvailablePoolEntity {
  key: string;
  qcNo: string;
  qcPoolAssignment: QcPoolAssignmentEntity[];
}

export interface AvailableQcEntity {
  id: string;
  qcNo: string;
  twinMove: boolean;
}

export interface QcPoolAssignmentEntity {
  key?: number;
  qcNo: string;
  dual: string;
  status: string;
  minIt: string;
  maxIt: string;
  coVslVoy: string;
  chassisType: string;
  twinMove: string;
  twinMoveRf: string;
  twinMoveProhibitIT: string;
  speedUp: string;
  inUseIT: string;
}
