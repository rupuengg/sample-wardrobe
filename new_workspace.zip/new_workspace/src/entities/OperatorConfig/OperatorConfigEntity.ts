import { IBaseEntity } from 'entities';

export interface OperatorConfigEntity extends IBaseEntity {
  id: number;
  portId: number;
  code: string;
  description: string;
}
