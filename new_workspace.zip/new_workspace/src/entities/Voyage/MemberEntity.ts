import { IBaseEntity } from 'entities';

export interface MemberEntity extends IBaseEntity {
  memberSlotBuyer: string;
  memberRegion?: string;
  slotProvider?: string;
  slotProviderRegion?: string;
}
