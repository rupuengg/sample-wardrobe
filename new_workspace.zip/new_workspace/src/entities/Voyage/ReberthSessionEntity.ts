import { IBaseEntity } from 'entities';

export interface ReberthSessionEntity extends IBaseEntity {
  id: string;
  arrivalDate: string;
  berthDate: string;
  departureDate: string;
  berthingTerminal: string;
  berthingBridge: string;
  startBitt?: number;
  endBitt?: number;
  quayCrane?: string;
}
