import { IBaseEntity } from 'entities';

export interface GroundingCategoryEntity extends IBaseEntity {
  consolidatedCategory: string;
  containerCategory: string;
  containerStatus?: string[];
  containerAttributes?: string;
}
