import { IBaseEntity } from 'entities';

export interface TerminalOperationSettingEntity extends IBaseEntity {
  settingName: string;
  settingValues: string[];
}
