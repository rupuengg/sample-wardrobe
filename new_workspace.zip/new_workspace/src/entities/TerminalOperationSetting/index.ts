export * from './TerminalOperationSettingEntity';
