import { IBaseEntity } from 'entities';
import { E_COMP_ACTION, E_SITUATION } from 'enums';

export interface DataAnalyzerJobConfigEntity {
  key: string;

  dataAnalyzerId: string;
  autoRun: boolean;
  problemDataFaultToleranceSecond: number;
}

export interface DataAnalyzerResultDetailEntity {
  key: string;
  keyDesc: string;
  situation: E_SITUATION;
  problemDataDurationSecond: number;
  problemDataFaultToleranceSecond: number;
  compAction: E_COMP_ACTION;
  compActionSuccess: boolean;
}

export interface DataAnalyzerResultEntity extends IBaseEntity {
  uid: string;
  dataAnalyzerId: string;
  startDateTime: string;
  endDateTime: string;
  durationSecond: number;
  docCnt: number;
  pCnt: number;
  syncRate: number;
  resultDetails: DataAnalyzerResultDetailEntity[];

  docCntAr?: number[];
  pCntAr?: number[];
  syncRateAr?: number[];
}
