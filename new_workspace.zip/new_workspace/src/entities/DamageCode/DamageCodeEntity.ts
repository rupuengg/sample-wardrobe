import { IBaseEntity } from 'entities';

export interface DamageCodeEntity extends IBaseEntity {
  code: string;
  type: string;
  description?: string;
  toBeDelete: boolean;
}
