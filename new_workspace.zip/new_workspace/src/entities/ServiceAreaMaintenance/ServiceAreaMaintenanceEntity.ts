import { IBaseEntity } from 'entities';

export interface ServiceAreaBlockEntity extends IBaseEntity {
  serviceAreaId: string;
  blockId: string;
  maxPickMove: string;
  maxGroundMove: string;
  maxTotalMove: string;
  currentPickMove: string;
  currentGroundMove: string;
  currentTotalMove: string;
}

export interface ServiceAreaMaintenanceEntity extends IBaseEntity {
  serviceAreaId: string;
  serviceAreaBlockType: string;
  seqAccSaMvtCntrIntChgMode: string;
  parentTrtTfcServiceAreaId: string;
  maxHotMoveTractorCount: string;
  currHotMoveTractorCount: string;
  equipmentExist?: boolean;
  fromDateTime?: string;
  toDateTime?: string;
  effectiveTimeMaxTractor?: string;
  effective: boolean;
  virtualLocation: string[];
  serviceAreaBlock: ServiceAreaBlockEntity[] | null;
}
