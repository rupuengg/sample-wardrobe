export interface ProformaServiceEntity {
  proformaServiceId: string;
  buId: string;
  lineCode: string;
  serviceCode: string;
  listEtaWeekDay: string;
  listEtaTimeDayHr: string;
  listEtaTimeDayMin: string;
  listEtbWeekDay: string;
  listEtbTimeDayHr: string;
  listEtbTimeDayMin: string;
  listEtdWeekDay: string;
  listEtdTimeDayHr: string;
  listEtdTimeDayMin: string;
  pilotOnBoardLocation: string;
  frequencyInDays: string;
  berthSide: string;
  berthingTmlId: string;
  berthId: string;
  startBitt: string;
  endBitt: string;
  maxLoa: string;
  historicalLoaRangeLow: string;
  historicalLoaRangeHigh: string;
  maxOutreach: string;
  historicalOutreachRangeLow: string;
  historicalOutreachRangeHigh: string;
  maxVslCapacityTEU: string;
  historicalVslCapacityTEURangeLow: string;
  historicalVslCapacityTEURangeHigh: string;
  suggestQC: string;
  estQCRate: string;
  estimateIB: string;
  estimateOB: string;
  previousPort: string;
  nextPort: string;
  pendulumFirstSecondCall: string;
  fixedDiversion: string;
  joinVentureList: [
    {
      terminal: string;
      line: string;
      service: string;
    },
  ];
  specialArrangementList: string[];
  remarks: string;
  version: number;
  dummy: boolean;
}
