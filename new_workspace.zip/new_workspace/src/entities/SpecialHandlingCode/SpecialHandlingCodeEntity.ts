import { IBaseEntity } from 'entities';

export interface SpecialHandlingCodeEntity extends IBaseEntity {
  specialHandleCode: string;
  description: string;
  isSystemDefined: boolean;
  toBeDelete: boolean;
}
