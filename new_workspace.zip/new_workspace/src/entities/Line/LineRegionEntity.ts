import { IBaseEntity } from 'entities';

export interface LineRegionEntity extends IBaseEntity {
  regionCode: string;
  regionDescription: string;
  billCode: string;
  flag_edit?: boolean;
}
