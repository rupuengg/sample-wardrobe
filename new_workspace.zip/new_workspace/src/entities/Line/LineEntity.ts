import { IBaseEntity } from 'entities';
import { LineRegionEntity } from './LineRegionEntity';

export interface LineEntity extends IBaseEntity {
  lineCode: string;
  lineCompanyName: string;
  agentName?: string;
  lineCategory: string;
  contractOperationUnit?: string;
  emailAddress: string;
  phoneNo: string;
  address: string;
  remark?: string;
  toBeDelete: boolean;
  lineRegions?: LineRegionEntity[];
  color: string;
  contractual: boolean;
  localName?: string;
}
