import { IBaseEntity } from 'entities';

export interface PortEntity extends IBaseEntity {
  portCode: string;
  portName: string;
  portNameLocalized?: string;
  countryCode: string;
  provinceCode?: string;
  toBeDelete: boolean;
  portConditions?: string[] | null;
  color: string;
}
