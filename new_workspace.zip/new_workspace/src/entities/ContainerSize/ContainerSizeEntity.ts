import { IBaseEntity } from 'entities';

export interface ContainerSizeEntity extends IBaseEntity {
  cntrSize: string;
  containerSizeGroup: string;
  encodedScheme: string;
  description?: string;
  cntrLengthInFeet?: number;
  cntrHeightInFeet?: number;
  cntrWidthInFeet?: number;
  toBeDelete: boolean;
}
