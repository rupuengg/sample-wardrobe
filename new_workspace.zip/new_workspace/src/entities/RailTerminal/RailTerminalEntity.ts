import { IBaseEntity } from 'entities';

export interface RailTerminalEntity extends IBaseEntity {
  id: number;
  portId: number;
  code: string;
  description: string;
  defaultPortDrawingOrder: string;
}
