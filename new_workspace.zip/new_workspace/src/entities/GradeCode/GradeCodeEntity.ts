import { IBaseEntity } from 'entities';

export interface GradeCodeEntity extends IBaseEntity {
  code: string;
  description?: string;
  toBeDelete?: boolean;
}
