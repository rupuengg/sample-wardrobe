import { LocationTypeEntity } from '../LocationType/LocationTypeEntity';
import { VirtualLocationEntity } from '../VirtualLocation/VirtualLocationEntity';
import { IBaseEntity } from 'entities';
import { E_Criteria_Type } from 'enums';

export interface LocationGroupEntity extends IBaseEntity {
  groupName: string;
  criteriaType: E_Criteria_Type;
  locationTypes: string[];
  virtualLocations: string[];
}

export interface LocationGroupDropdownOptionEntity {
  locationTypes: LocationTypeEntity[];
  virtualLocations: VirtualLocationEntity[];
}
