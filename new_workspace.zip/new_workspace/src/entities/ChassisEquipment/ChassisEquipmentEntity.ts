import { IBaseEntity } from 'entities';

export interface ChassisEquipmentEntity extends IBaseEntity {
  chassisType: string;
  chassisWeightWithoutCargo: number | null;
  maximumCargoWeight: number | null;
  containerLengthListModifier: string;
  containerTypeGroupListModifier: string;
  equipmentCodeListModifier: string;
  specialHandleCodeListModifier: string;
  chassisTypeDescription: string;
  containerLengthList: string;
  listDelimiter: string;
  containerTypeGroupList: string;
  equipmentCodeList: string;
  specialHandleCodeList: string;
  containerTypeGpCarryingCfgList: string;
}
