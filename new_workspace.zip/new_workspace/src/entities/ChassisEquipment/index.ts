export * from './ChassisEquipmentEntity';
