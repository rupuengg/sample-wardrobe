import { IBaseEntity } from 'entities';

export interface HoldCodeEntity extends IBaseEntity {
  holdConditionCode: string;
  description: string;
  isSystemDefined: boolean;
  toBeDelete: boolean;
}
