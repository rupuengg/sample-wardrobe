import { IBaseEntity } from 'entities';

export interface LineServiceVesselEntity extends IBaseEntity {
  frequencyInDays?: string;
  berthSide?: string;
  maxOutreach?: string;
  maxVslCapacityTEU?: string;
  suggestQC?: number;
  estQCRate?: string;
  estimateIB?: string;
  estimateOB?: string;
  estimateTTL?: string;
}
