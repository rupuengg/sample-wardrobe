import { IBaseEntity, PortOfCallSIBlockEntity } from 'entities';

export interface PortOfCallSIEntity extends IBaseEntity {
  portCallSISequence: number;
  portCallSI: string;
  blockInstruction?: PortOfCallSIBlockEntity[];
}
