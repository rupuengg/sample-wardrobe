import { IBaseEntity } from 'entities';

export interface LineServiceMemberEntity extends IBaseEntity {
  serviceMemberLine: string;
  serviceMemberLineRegion: string;
  voyageMemberUponSoaList?: string[];
  obGenCntrClsWeekDay: string;
  obGenCntrClsTimeDayHr?: string;
  obGenCntrClsTimeDayMin?: string;
  obRfrCntrClsWeekDay: string;
  obRfrCntrClsTimeDayHr?: string;
  obRfrCntrClsTimeDayMin?: string;
  obDgCntrClsWeekDay: string;
  obDgCntrClsTimeDayHr?: string;
  obDgCntrClsTimeDayMin?: string;
  memberLdDsOperationMode?: string;
  joinDate?: string;
  serviceMemberRemark?: string;
  flag_edit?: boolean;
  memberServiceCode: string;
  soa: boolean;
}
