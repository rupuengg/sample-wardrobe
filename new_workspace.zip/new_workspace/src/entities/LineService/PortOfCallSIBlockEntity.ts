import { IBaseEntity } from 'entities';
import { PortOfCallSIBlockMemberRegionEntity } from './PortOfCallSIBlockMemberRegionEntity';

export interface PortOfCallSIBlockEntity extends IBaseEntity {
  portCallSIBlockSequence: number;
  portCallSIBlock: string;
  memberRegion?: PortOfCallSIBlockMemberRegionEntity[];
}
