export interface JoinVentureListEntity {
  terminal: string;
  line: string;
  service: string;
}
