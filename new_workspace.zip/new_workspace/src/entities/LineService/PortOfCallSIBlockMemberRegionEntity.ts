import { IBaseEntity } from 'entities';

export interface PortOfCallSIBlockMemberRegionEntity extends IBaseEntity {
  memberLine: string;
  memberLineRegion: string;
  isSelected: boolean;
}
