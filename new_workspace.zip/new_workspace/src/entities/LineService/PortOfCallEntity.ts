import { IBaseEntity } from 'entities';
import { PortOfCallSIEntity } from './PortOfCallSIEntity';

export interface PortOfCallEntity extends IBaseEntity {
  portCallSequence: number;
  portCall: string;
  stowageInstruction?: PortOfCallSIEntity[];
  isPOD: boolean;
}
