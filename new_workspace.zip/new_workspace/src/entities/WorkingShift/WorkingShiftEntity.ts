import { IBaseEntity } from 'entities';

export interface WorkingShiftEntity extends IBaseEntity {
  shiftCode: string;
  startTime: string;
  endTime: string;
  symbol: string;
}
