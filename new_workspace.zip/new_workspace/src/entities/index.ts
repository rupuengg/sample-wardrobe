import { BerthEntity } from './Berth';
import { ChassisEquipmentEntity } from './ChassisEquipment';
import { ContainerHandlingVehicleEntity } from './ContainerHandlingVehicle';
import { ContainerSizeEntity } from './ContainerSize';
import { ContainerTypeEntity } from './ContainerType';
import { ContainerTypeGroupEntity } from './ContainerTypeGroup';
import { CountryEntity } from './Country';
import { DamageCodeEntity } from './DamageCode';
import { DangerousCodeEntity } from './DangerousCode';
import { EquipmentCodeEntity } from './EquipmentCode';
import { GateQueueEntity } from './GateQueueMaintenance';
import { GradeCodeEntity } from './GradeCode';
import { GroundingCategoryEntity } from './GroundingCategory';
import { HoldCodeEntity } from './HoldCode';
import { ITPagerEntity } from './ITPager';
import { InternalTractorEntity } from './InternalTractor';
import { LineEntity } from './Line';
import { LineServiceEntity } from './LineService';
import { LocationGroupEntity } from './LocationGroup';
import { LocationTypeEntity } from './LocationType';
import { MsshPoolAssignmentEntity } from './MsshDeployment';
import { OperatorConfigEntity } from './OperatorConfig';
import { PilotOnBoardEntity } from './PilotOnBoard';
import { PolicyCodeEntity } from './PolicyCode';
import { PortEntity } from './Port';
import { ProvinceEntity } from './Province';
import { QcDeploymentEntity } from './QcDeployment';
import { QcMoveLogEntity } from './QcMoveLog';
import { QuayCraneEntity } from './QuayCrane';
import { RailTerminalEntity } from './RailTerminal';
import { ReasonCodeEntity } from './ReasonCode';
import { ServiceAreaBlockEntity } from './ServiceAreaMaintenance';
import { SpecialArrangementCodeEntity } from './SpecialArrangementCode';
import { SpecialHandlingCodeEntity } from './SpecialHandlingCode';
import { TerminalOperationSettingEntity } from './TerminalOperationSetting';
import { TieDownLocationEntity } from './TieDownLocation';
import { TractorDeploymentEntity } from './TractorDeployment';
import { TractorPairingEntity } from './TractorPairing';
import { UserActivityTrackingEntity } from './UserTracking';
import { VesselEntity } from './Vessel';
import { VirtualLocationEntity } from './VirtualLocation';
import { VoyageEntity } from './Voyage';
import { WorkingShiftEntity } from './WorkingShift';
import { YardBlockEntity } from './YardBlock';
import { YardCraneEntity } from './YardCrane';
import { YardCraneMergeBlockEntity, YardCraneWorkloadMaintenanceEntity } from './YardCraneWorkloadMaintenance';
import { YardZoneEntity } from './YardZone';

export * from './BaseEntity';
export * from './Berth';
export * from './ChassisEquipment';
export * from './Common';
export * from './ContainerHandlingVehicle';
export * from './ContainerSize';
export * from './ContainerType';
export * from './ContainerTypeGroup';
export * from './Country';
export * from './DamageCode';
export * from './DangerousCode';
export * from './DataAnalyzerJobConfig';
export * from './DataManagement';
export * from './EntityStatusData';
export * from './EquipmentCode';
export * from './GateQueueMaintenance';
export * from './GradeCode';
export * from './GroundingCategory';
export * from './HoldCode';
export * from './ITPager';
export * from './InternalTractor';
export * from './Line';
export * from './LineService';
export * from './LiveUser';
export * from './LocationGroup';
export * from './LocationType';
export * from './MsshDeployment';
export * from './PilotOnBoard';
export * from './PolicyCode';
export * from './Port';
export * from './ProformaService';
export * from './Province';
export * from './OperatorConfig';
export * from './QcDeployment';
export * from './QcMoveLog';
export * from './QuayCrane';
export * from './RailTerminal';
export * from './ReasonCode';
export * from './ServiceAreaMaintenance';
export * from './SpecialArrangementCode';
export * from './SpecialHandlingCode';
export * from './TerminalOperationSetting';
export * from './TieDownLocation';
export * from './TractorDeployment';
export * from './TractorPairing';
export * from './UserTracking';
export * from './Vessel';
export * from './VirtualLocation';
export * from './Voyage';
export * from './WorkingShift';
export * from './Workspace';
export * from './WebSocketEntity';
export * from './YardBlock';
export * from './YardCrane';
export * from './YardCraneWorkloadMaintenance';
export * from './YardZone';

export type CommonEntity =
  | BerthEntity
  | ChassisEquipmentEntity
  | ContainerHandlingVehicleEntity
  | ContainerSizeEntity
  | ContainerTypeEntity
  | ContainerTypeGroupEntity
  | CountryEntity
  | DamageCodeEntity
  | DangerousCodeEntity
  | EquipmentCodeEntity
  | GateQueueEntity
  | GradeCodeEntity
  | GroundingCategoryEntity
  | HoldCodeEntity
  | ITPagerEntity
  | InternalTractorEntity
  | LineEntity
  | LineServiceEntity
  | LocationGroupEntity
  | LocationTypeEntity
  | MsshPoolAssignmentEntity
  | PilotOnBoardEntity
  | PolicyCodeEntity
  | PortEntity
  | ProvinceEntity
  | OperatorConfigEntity
  | QcDeploymentEntity
  | QcMoveLogEntity
  | QuayCraneEntity
  | RailTerminalEntity
  | ReasonCodeEntity
  | ServiceAreaBlockEntity
  | SpecialArrangementCodeEntity
  | SpecialHandlingCodeEntity
  | TerminalOperationSettingEntity
  | TieDownLocationEntity
  | TractorDeploymentEntity
  | TractorPairingEntity
  | UserActivityTrackingEntity
  | VesselEntity
  | VirtualLocationEntity
  | VoyageEntity
  | WorkingShiftEntity
  | YardBlockEntity
  | YardCraneEntity
  | YardCraneMergeBlockEntity
  | YardCraneWorkloadMaintenanceEntity
  | YardZoneEntity;
