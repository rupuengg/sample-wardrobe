import { IBaseEntity } from 'entities';

export interface SpecialArrangementCodeEntity extends IBaseEntity {
  specialArrangementId: string;
  buId: string;
  name: string;
  serviceLevel: string;
  contentDisplayType: string;
  textDescription: string;
  color: string;
  symbol: string;
  symbolImport: string;
}
