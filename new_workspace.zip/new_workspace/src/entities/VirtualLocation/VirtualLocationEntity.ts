import { IBaseEntity } from 'entities';

export interface VirtualLocationEntity extends IBaseEntity {
  zcode: string;
  shortName: string;
  description: string;
}
