import { IBaseEntity } from 'entities';

export interface PortConditionCodeEntity extends IBaseEntity {
  portConditionCodeId: string;
  buId: string;
  name: string;
  contentDisplayType: string;
  textDescription: string;
  color: string;
  symbol: string;
  symbolImport: string;
  version: number;
}
