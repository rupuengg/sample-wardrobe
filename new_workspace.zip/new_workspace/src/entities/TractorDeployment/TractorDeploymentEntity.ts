import { IBaseEntity } from 'entities';

export interface AssignmentPoolEntity {
  key: string;
  poolNo: string;
  tractorInPool: string;
  inUsedIT: string;
  itProvider: string;
  operationMode: string;
  versionIdentifier?: {
    version: string;
  };
}

export interface AvailableItEntity {
  id?: string;
  itNo: string;
  pagerNo: string;
  chassisType: string;
  nextPool: string;
  nextPoolEffectiveDateTime: string;
  loadingCapacity: string;
  driverId: string;
  driverName: string;
  assetGroup: string;
  pagerType: string;
}

export interface TractorDeploymentEntity extends IBaseEntity {
  inUse: string;
  itNo: string;
  terminalXYard: string;
  suspend: string;
  suspendStaffId: string;
  chassisType: string;
  mark: string;
  removeEffectiveDateTime: string;
  nextPool: string;
  nextPoolEffectiveDateTime: string;
  suspensionStartTime: string;
  suspensionReason: string;
  pagerNo: string;
  pagerLanguage: string;
  terminalXtml: string;
  lastPoolNo: string;
  lastPoolType: string;
  loadingCapacity: string;
  driverId: string;
  driverName: string;
  assetGroup: string;
  pagerType: string;
}

export interface itPoolAssignmentEntity {
  inUseQCMSSH: string;
  itNo: string;
  tmlXYard: string;
  suspendInd: string;
  suspendStaffId: string;
  chassisType: string;
  mark: string;
  removeEffectiveDateTime: string;
  nextPool: string;
  nextPoolEffectiveDateTime: string;
  suspensionStartTime: string;
  suspensionReason: string;
  pagerNo: string;
  pagerLanguage: string;
  tmlXtml: string;
  lastPoolNo: string;
  lastPoolType: string;
  loadingCapacity: string;
  driverId: string;
  assetGroup: string;
  pagerType: string;
}

export interface ItPoolEntity extends IBaseEntity {
  color?: string;
  poolNo: string;
  itNo: string;
  tractorInPool: string;
  inUsedIT: string;
  itProvider: string;
  operationMode: string;
  itPoolAssignment: itPoolAssignmentEntity[];
}
