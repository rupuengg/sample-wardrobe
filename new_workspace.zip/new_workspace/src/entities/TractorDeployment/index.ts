export * from './TractorDeploymentEntity';
