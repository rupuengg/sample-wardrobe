import { IBaseEntity } from 'entities';

export interface ProvinceEntity extends IBaseEntity {
  provinceCode: string;
  provinceName: string;
  provinceNameLocalized?: string;
  countryCode: string;
}
