export * from './ProvinceEntity';
