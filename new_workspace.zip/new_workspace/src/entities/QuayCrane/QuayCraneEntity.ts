import { IBaseEntity } from 'entities';

export interface QuayCraneEntity extends IBaseEntity {
  berthingTml: string;
  quayCraneNo: string;
  type: string;
  berth: string;
  subBerth?: string;
  workableBerth?: string[];
  inDeploymentSinceDateTime?: string;
  tieDownIndr: boolean;
  sequentialOrder?: number;
  tieDownBollard?: number;
  maintenanceIndr: boolean;
  maintenance?: string;
  cablePit?: number;
  operationStartBollard?: number;
  operationEndBollard?: number;
  outreachLengthByMeter?: number;
  outreachLengthByBoxes?: number;
  width?: number;
  liftingHeightLimit?: number;
  liftingSingleTonnage?: number;
  liftingTwinTonnage?: number;
  favariance?: number;
  liftingTanDemTonnage?: number;
  color: string;
}
