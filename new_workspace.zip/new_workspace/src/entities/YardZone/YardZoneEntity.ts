import { IBaseEntity } from 'entities/BaseEntity';
import { RangeEntity } from './RangeEntity';

export interface YardZoneEntity extends IBaseEntity {
  zoneId: string;
  description: string | null;
  category: string | null;
  range: RangeEntity[];
}
