export interface RangeEntity {
  rangeId: string;
  fromBlockId: string;
  fromStackId: string;
  toBlockId: string;
  toStackId: string;
}
