import { IBaseEntity, IHistory } from 'entities';

export interface ZoneAmendHistory extends IBaseEntity, IHistory {}
