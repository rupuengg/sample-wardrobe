export interface MergeBlockListEntity {
  mergeBlockSequence: number;
  blockId: string;
}

export interface MergedBlockEntity {
  blockId: string;
  mergeBlockList: MergeBlockListEntity[];
  mergedBlock: boolean;
  extendedBlock: boolean;
  parentBlock: string;
}
