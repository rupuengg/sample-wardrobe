import { IBaseEntity } from 'entities/BaseEntity';
import { LaneContainerRestrictionEntity } from './LaneContainerRestrictionEntity';

export interface LaneEntity extends IBaseEntity {
  laneID: string;
  laneFrom?: number;
  laneTo?: number;
  stackableHeight: number | null;
  useExtendedHeight: number | null;
  laneType: string | null;
  void: boolean | null;
  densityCheck: boolean | null;
  laneContainerRestriction: LaneContainerRestrictionEntity;
  remark: string | null;
}
