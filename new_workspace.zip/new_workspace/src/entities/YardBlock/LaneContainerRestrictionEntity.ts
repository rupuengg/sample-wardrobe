export interface LaneContainerRestrictionEntity {
  noGrounding: boolean | null;
  noShuffleGrounding: boolean | null;
  noPickup: boolean | null;
  noMarshallingPickup: boolean | null;
  noGateGeneralEMPickup: boolean | null;
  noGateNominatePickup: boolean | null;
  noIMPickup: boolean | null;
  noEMLoading: boolean | null;
}
