export interface TractorRunwayEntity {
  runwayID: string | null;
  position: string | null;
  trafficDirection: string | null;
  type: string;
}
