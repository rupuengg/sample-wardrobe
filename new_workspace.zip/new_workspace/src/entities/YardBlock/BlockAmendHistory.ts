import { IBaseEntity } from 'entities/BaseEntity';

export interface IHistory {
  key: string;
  updatedTime: string;
  amendItem: string;
  staffId: string;
  previousValue: string;
  updatedValue: string;
}

export interface BlockAmendHistory extends IBaseEntity, IHistory {}
