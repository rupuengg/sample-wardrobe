export interface DamageCodeAllowedEntity {
  content: string;
  position: string;
  prohibit: boolean | null;
}

export interface StackContainerRestrictionEntity {
  containerSizeAllowed: string[] | null;
  isStackContainerSizeAllowedAny: boolean | null;
  nextContainerSize: string | null;
  isNextContainerSizeAllowedAny: boolean | null;
  currentContainerSize: string | null;
  containerTypeGroupAllowed: string[];
  containerHeightAllowed: string[];
  grossWeightLimitAllowed: string | null;
  reeferVoltageAllowed: string[];
  tradeModeAllowed: string | null;
  dgGroundingStrategy: string | null;
  imdgAllowed: string[];
  isImdgProhibited: boolean | null;
  undgAllowed: string[];
  isUndgProhibited: boolean | null;
  equipmentCodeAllowed: string[];
  isEquipmentCodeProhibited: boolean | null;
  holdCodeAllowed: string[];
  isHoldCodeProhibited: boolean | null;
  specialHandleCodeAllowed: string[];
  isSpecialHandleCodeProhibited: boolean | null;
  damageCodeAllowed: DamageCodeAllowedEntity[];
  isDamageCodeProhibited: boolean | null;
}
