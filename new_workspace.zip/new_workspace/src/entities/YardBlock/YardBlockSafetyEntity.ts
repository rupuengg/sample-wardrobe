export interface YardBlockSafetyEntity {
  checkStackableHeightvsYCLimit: string | null;
}
