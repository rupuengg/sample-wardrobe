import { IBaseEntity } from 'entities/BaseEntity';
import { LaneEntity } from './LaneEntity';
import { StackContainerRestrictionEntity } from './StackContainerRestrictionEntity';
import { StackSafetyEntity } from './StackSafetyEntity';

export interface StackEntity extends IBaseEntity {
  blockId: string;
  stackId: string;
  stackRangeFrom: string | null;
  stackRangeTo: string | null;
  noOfLanes: number | null;
  maxContainerAllowed: number | null;
  plannedStackableHeight: number | null;
  safetyStackableHeight: number | null;
  maxExtendedHeight: number | null;
  doorDirection: string | null;
  stackContainerRestriction: StackContainerRestrictionEntity;
  stackSafetyInfo: StackSafetyEntity;
  stackLanes: LaneEntity[];
}
