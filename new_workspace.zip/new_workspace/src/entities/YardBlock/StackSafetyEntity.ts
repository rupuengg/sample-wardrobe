export interface StackSafetyEntity {
  checkIsolatedLane: string | null;
  isolatedLaneHeightLimitInFeet: string | null;
}
