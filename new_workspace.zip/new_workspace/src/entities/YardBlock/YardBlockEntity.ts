import { IBaseEntity } from 'entities/BaseEntity';
import { StackEntity } from './StackEntity';
import { TractorRunwayEntity } from './TractorRunwayEntity';
import { YardBlockSafetyEntity } from './YardBlockSafetyEntity';

export interface YardBlockEntity extends IBaseEntity {
  blockId: string;
  terminal: string | null;
  blockRangeFrom: string | null;
  blockRangeTo: string | null;
  yardAreaID: string | null;
  railStationCode: string | null;
  blockUsage: string | null;
  equipmentType: string | null;
  tractorRunways: TractorRunwayEntity[];
  yardBlockSafety: YardBlockSafetyEntity;
  blockStacks: StackEntity[];
  safety: string;
  remark: string | null;
}
