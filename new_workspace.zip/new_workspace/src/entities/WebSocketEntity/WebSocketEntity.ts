import { E_WebSocketActions } from 'enums';

export interface WebSocketEntity {
  action: E_WebSocketActions;
  itemAsString: string;
}
