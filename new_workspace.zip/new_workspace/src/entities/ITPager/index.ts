export * from './ITPagerEntity';
