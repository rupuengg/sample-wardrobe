import { IBaseEntity } from 'entities';

export interface ITPagerEntity extends IBaseEntity {
  pagerNo: string;
  physicalAddr: string;
  xmlAddr: string;
  pagingChannelId: string;
  // pagerType: string;
  suspendIndr: string;
  suspendReason: string;
  pagerApplicationCategory: string;
  listDelimiter: string;
  pagerDisplayLanguageList: string;
}
