import { IBaseEntity } from 'entities';

export interface LocationTypeEntity extends IBaseEntity {
  code: string;
  description: string;
}
