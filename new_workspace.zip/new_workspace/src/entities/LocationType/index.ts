export * from './LocationTypeEntity';
