import { IBaseEntity } from 'entities';

export interface VesselEntity extends IBaseEntity {
  vesselCode: string;
  vesselType: string;
  vesselModelName: string;
  vesselName: string;
  vesselNameLocalized?: string;
  nationality: string;
  placeOfRegister: string;
  callSign: string;
  lloydsCode: string;
  loa?: number;
  vesselWidth?: number;
  teuCapacity?: number;
  vesselDerrickHeightMeter?: number;
  foreBridgeLength?: number;
  breadth?: number;
  grossWeightInMetricTon?: number;
  netWeightInMetricTon?: number;
  deadWeightInMetricTon?: number;
  remarks?: string;
  soa: string;
  soaVesselCode: string;
  enablePreferBerthSide: boolean;
  berthSide?: string;
  hideBridgeMark: boolean;
  varyWtPerDeckCell?: number;
  varyWtPerHoldCell?: number;
  constantWt?: number;
  constantWtLcg?: number;
  constantWtTcg?: number;
  constantWtVcg?: number;
  lightWt?: number;
  lightWtLcg?: number;
  lightWtTcg?: number;
  lightWtVcg?: number;
  otherWt?: number;
  otherWtLcg?: number;
  otherWtTcg?: number;
  otherWtVcg?: number;
  otherWtFsMoment?: number;
  toBeDelete: boolean;

  vesselModelId: string;
}
