export interface UserActivityLoginTrackingEntity {
  userEmail: string;
  identifier: string;
  accessDate: Date;
  latitude: string;
  longitude: string;
  token: string;
  isLogin: boolean;
}
