import { E_Frontend_Console_type } from 'enums';

export interface FrontendConsoleTrackingEntity {
  userEmail: string;
  identifier: string;
  logDate: Date;
  type: E_Frontend_Console_type;
  message: string;
  stacktrace: string;
}
