export interface UserActivityMFEAccessEntity {
  entrypoint: string;
  timeSpent: number;
  userEmail: string;
  identifier: string;
  accessDateFrom: Date;
  accessDateTo: Date;
}
