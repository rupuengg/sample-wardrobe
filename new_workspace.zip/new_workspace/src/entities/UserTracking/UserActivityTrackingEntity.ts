import { IBaseEntity } from 'entities/BaseEntity';

export interface UserActivityTrackingEntity extends IBaseEntity {
  page: string;
  event: string;
  logDateTime: Date;
  userEmail: string;
}
