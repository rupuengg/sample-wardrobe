import { IBaseEntity } from 'entities';

export interface ContainerTypeGroupEntity extends IBaseEntity {
  cntrTypeGroup: string;
  description?: string;
  cntrTypeSpecs?: string[];
}

export interface ContainerType {
  cntrType: string;
  encodedScheme: string;
}
