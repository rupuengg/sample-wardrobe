export interface QCSequentialOrderEntity {
  quayCraneNo: string;
  position: number;
}
