import { IBaseEntity } from 'entities';
import { BollardEntity } from './BollardEntity';
import { QCParkingBollardEntity } from './QCParkingBollardEntity';
import { QCSequentialOrderEntity } from './QCSequentialOrderEntity';

export interface BerthEntity extends IBaseEntity {
  berthId: string;
  berthLabel: string;
  terminalId: string;
  adjacentBerth: string;
  straightBerth: string;
  straightLengthMeter?: number;
  actualDepthMeter?: number;
  seaSide: string;
  startPosition: string;
  endPosition: string;
  preferredBerthSide: string;
  subBerth1Pos: string;
  subBerth1BollardFrom?: number;
  subBerth1BollardTo?: number;
  subBerth2Pos: string;
  subBerth2BollardFrom?: number;
  subBerth2BollardTo?: number;
  subBerth3Pos: string;
  subBerth3BollardFrom?: number;
  subBerth3BollardTo?: number;
  clearanceBerthStartNormal?: number;
  clearanceBerthEndNormal?: number;
  clearanceBerthStartCritical?: number;
  clearanceBerthEndCritical?: number;
  commonZoneBerthStartBollardRangeFrom?: number;
  commonZoneBerthStartBollardRangeTo?: number;
  commonZoneBerthEndBollardRangeFrom?: number;
  commonZoneBerthEndBollardRangeTo?: number;
  qcParkingBollard?: QCParkingBollardEntity[];
  bollards?: BollardEntity[];
  qcSequentialOrder?: QCSequentialOrderEntity[];
  oldQcSequentialOrder?: QCSequentialOrderEntity[];
}
