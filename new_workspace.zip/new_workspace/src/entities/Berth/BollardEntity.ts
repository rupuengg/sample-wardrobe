import { IBaseEntity } from 'entities';

export interface BollardEntity extends IBaseEntity {
  bollardNumber?: number;
  bollardIsVoided: boolean;
  bollardSupportTonnage?: number;
  bollardDistance?: number;
  flag_edit?: boolean;
}
