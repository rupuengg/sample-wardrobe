import { IBaseEntity } from 'entities';

export interface QCParkingBollardEntity extends IBaseEntity {
  qcId: string;
  bollard?: number;
  flag_edit?: boolean;
}
