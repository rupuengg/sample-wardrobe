import { IBaseEntity } from 'entities';

export interface ContainerHandlingVehicleEntity extends IBaseEntity {
  containerHandlingVehicleNo: string;
  type: string;
  containerTypeHandling?: string;
  heightLimitMeter?: number;
  liftingWeightLimitTon?: number;
  maintenance?: string;
  specialHandling?: string[];

  enableMaintenance: boolean;
}
