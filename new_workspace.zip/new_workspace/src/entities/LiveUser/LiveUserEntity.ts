import { E_Message_Type, E_User_Status } from 'enums';

export interface LiveUserEntity {
  key: string;

  givenName: string;
  shortName?: string;
  aud: string;
  fullName: string;
  familyName: string;
  buList: Array<string>;
  email: string;
  buUrl: string;
  bu: string;
  status: E_User_Status;
  loggedOn?: string;

  module: string;
  detail: string;
  entrypoint?: string;

  liveUserChat: LiveUserChatEntity;
  unReadCount?: number;

  versionIdentifier: {
    version?: string;
  };
}

export interface LiveUserChatMessage {
  fromUser: string;
  toUser: string;
  messageType: E_Message_Type;
  message: string;
  chatOn?: string;
}

export interface LiveUserChatEntity {
  key: string;

  userOne?: string;
  userTwo?: string;
  isUserOneChatActive: boolean;
  isUserTwoChatActive: boolean;
  userOneUnreadCount: number;
  userTwoUnreadCount: number;

  chat: LiveUserChatMessage[];
  chatPage?: number;
  chatTotalPage?: number;
  chatLastPage?: number;
}

export interface AllLiveUserChats {
  [x: string]: LiveUserChatEntity;
}
