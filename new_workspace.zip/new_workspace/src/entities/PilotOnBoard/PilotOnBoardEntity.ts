import { IBaseEntity } from 'entities';

export interface PilotOnBoardEntity extends IBaseEntity {
  pilotOnBoard: string;
  description?: string;
  timeToBerthHr?: number;
  isDefault: boolean;
  toBeDelete: boolean;
}
