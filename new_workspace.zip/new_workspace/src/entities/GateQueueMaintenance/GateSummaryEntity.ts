export interface IGateSubSummary {
  tractor: string | number;
  container: number;
}

export interface GateSummaryEntity {
  gateIn: IGateSubSummary;
  gateQueue: IGateSubSummary;
  pending: IGateSubSummary;
  active: IGateSubSummary;
  hot: IGateSubSummary;
  yardComplete: IGateSubSummary;
  total: IGateSubSummary;
}
