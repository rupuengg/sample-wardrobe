import { IBaseEntity } from 'entities';

export interface GateQueueEntity extends IBaseEntity {
  terminal: string; // OK
  yardZone: string;
  cmsNo: string; // OK
  groundType: string; // OK
  tractorNo: string; // OK
  tractorZone: string; // OK

  gateInTime: string;
  gateInWait: string;

  gateQueueTime: string;
  gateQueueWait: string;

  pendingTime: string;
  pendingWait: string;

  activeTime: string;
  activeWait: string;

  hotTime: string;
  hotWait: string;

  yardCompleteTime: string;
  yardCompleteWait: string;

  totalWaiting: string;

  location: string;
}

//Tml, Yard Zone, CMS No., Ground Type, Tractor No., Tractor Zone, Gate In (min), Gate Queue (min), Pending (min), Active (min), Hot (min), Yard Complete, Total Waiting, Location (location display A1/20)
