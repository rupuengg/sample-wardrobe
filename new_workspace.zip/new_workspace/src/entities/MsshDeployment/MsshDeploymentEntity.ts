import { IBaseEntity } from 'entities/BaseEntity';

export interface AvailablePoolEntity {
  poolNo: string;
  tractorInPool: string;
  inUsedIT: string;
  itProvider: string;
  operationMode: string;
}

export interface AvailableMsshEntity {
  msshCategory: string;
  preItProvider: string;
  twinMove: boolean;
}

export interface MsshPoolAssignmentEntity extends IBaseEntity {
  activeorHotMove: string;
  msshType: string;
  msshCat: string;
  suspendInd: string;
  suspendStaffId: string;
  speedUp: string;
  minIt: string;
  maxIt: string;
  chassisType: string;
  twinMove: string;
  twinMoveRf: string;
  twinMoveProhibitIT: string;
  inUseIT: string;
}

export interface MsshPoolResponse extends AvailablePoolEntity {
  key: string;
  msshCat: string;
  msshPoolAssignment: MsshPoolAssignmentEntity[];
}
