export interface IBaseEntity extends IOtherEntity {
  key: string;
  versionIdentifier: {
    version?: string;
  };
}

export interface IOtherEntity {
  [key: string]: string | number | boolean | null | object | undefined;
}
