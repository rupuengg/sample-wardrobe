import '@testing-library/jest-dom';
import { TextDecoder, TextEncoder } from 'util';

const { ReadableStream, TransformStream } = require('node:stream/web');

Object.defineProperties(global, {
  TextDecoder: { value: TextDecoder },
  TextEncoder: { value: TextEncoder },
  ReadableStream: { value: ReadableStream },
  TransformStream: { value: TransformStream },
});
