const { createProxyMiddleware } = require('http-proxy-middleware');
const fs = require('fs');

const workingMfe = () => {
  const mfe = process.env.REACT_APP_WORKING_MFE || '';
  if (mfe.trim() === '') return [];

  if (mfe.includes(',')) {
    return mfe.split(',');
  } else return [mfe];
};

const apps = {
  frontend: workingMfe(),
  backend: [
    { key: 'terminal-model-backend', value: 'TERMINAL_MODEL' },
    { key: 'vessel-planning-backend', value: 'VESSEL_PLANNING' },
    { key: 'control-tower-geomap-backend', value: 'GEOMAP' },
    { key: 'control-tower-backend', value: 'CONTROL_TOWER' },
    { key: 'support-backend', value: 'SUPPORT' },
    { key: 'yard-management-backend', value: 'YARD_MANAGEMENT' },
    { key: 'arpita-backend', value: 'ARPITA' },
    { key: 'inventory-management-backend', value: 'INVENTORY_MANAGEMENT' },
    { key: 'berth-planning-backend', value: 'BERTH_PLANNING', ws: true },
    { key: 'workspace-backend', value: 'WORKSPACE' },
    { key: 'data-management-backend', value: 'DATA_MANAGEMENT' },
  ],
};

function createProxy(protocol, host, port, secure, ws, ...rest) {
  const ret = {
    target: {
      protocol: protocol,
      host: host,
      port: port,
    },
    changeOrigin: true,
    secure,
    ws,
  };
  for (const o of rest) ret.target = { ...ret.target, ...o };
  return ret;
}

function useFrontend(app, appName, index) {
  app.use(`/${appName}`, createProxyMiddleware(createProxy('http:', 'localhost', 3000 + (index === 0 ? index : index + 1), false, false)));
}

function useBackend(app, appName) {
  const ws = appName.ws || false;
  app.use(
    `/konggwapi/${appName.key}/1.0.0/`,
    createProxyMiddleware(
      createProxy('https:', process.env[`REACT_APP_${appName.value}_HOST`], 443, true, ws, process.env.SSL_PFX_FILE && { pfx: fs.readFileSync(process.env.SSL_PFX_FILE) }, process.env.SSL_PFX_PASSWORD && { passphrase: process.env.SSL_PFX_PASSWORD })
    )
  );
  app.use(
    `/${appName.key}/api`,
    createProxyMiddleware(
      createProxy(
        process.env[`REACT_APP_${appName.value}_PROTOCOL`],
        process.env[`REACT_APP_${appName.value}_HOST`],
        process.env[`REACT_APP_${appName.value}_PORT`],
        false,
        ws,
        process.env.SSL_PFX_FILE && { pfx: fs.readFileSync(process.env.SSL_PFX_FILE) },
        process.env.SSL_PFX_PASSWORD && { passphrase: process.env.SSL_PFX_PASSWORD }
      )
    )
  );
}

module.exports = function (app) {
  apps.frontend && apps.frontend.forEach((item, index) => useFrontend(app, item, index));
  apps.backend && apps.backend.forEach(item => useBackend(app, item));
};
