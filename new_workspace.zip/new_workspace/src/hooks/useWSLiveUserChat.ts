import { IMessage } from '@stomp/stompjs';
import { useEffect, useRef } from 'react';
import { LiveUserChatEntity, LiveUserChatMessage, WebSocketEntity } from 'entities';
import { E_WebSock_Topic, E_WebSocketActions } from 'enums';
import { LiveUserUtils } from 'utils';
import { LiveUserActions, WebSocketService, tokenReference } from 'store';

let timer: NodeJS.Timeout;
export const useWSLiveUserChat = (userEmail: string, dispatch: any) => {
  const wsLiveUserChatCallback = useRef<(message: IMessage) => void>(() => {
    throw new Error('wsLiveUserChatCallback is not initialized');
  });

  const wsLiveUserChatMessagesCallback = useRef<(message: IMessage) => void>(() => {
    throw new Error('wsLiveUserChatMessagesCallback is not initialized');
  });

  useEffect(() => {
    let wsInstance = WebSocketService.getInstance();
    if (!wsInstance.connecting && !wsInstance.connected) {
      wsInstance = WebSocketService.getInstance();
      wsInstance.email = userEmail;
      wsInstance.token = tokenReference.token;

      wsInstance.connect();
    }

    wsInstance.addSubscription(
      E_WebSock_Topic.TOPIC_LIVE_USER_CHAT,
      (message: IMessage) => {
        wsLiveUserChatCallback.current(message);
      },
      true
    );

    wsInstance.addSubscription(
      E_WebSock_Topic.TOPIC_LIVE_USER_CHAT_MESSAGE,
      (message: IMessage) => {
        wsLiveUserChatMessagesCallback.current(message);
      },
      true
    );
  }, []);

  useEffect(() => {
    wsLiveUserChatCallback.current = (message: IMessage) => {
      const updatedItem: WebSocketEntity = JSON.parse(message.body);

      // Change type later
      const data: LiveUserChatEntity = JSON.parse(updatedItem.itemAsString);

      if (LiveUserUtils(undefined).isChatUser(data, userEmail)) {
        switch (updatedItem.action) {
          case E_WebSocketActions.CREATE:
          case E_WebSocketActions.UPDATE:
            dispatch(LiveUserActions.updateLiveUserChat({ liveUserChat: data, email: userEmail }));
            break;
          // case E_WebSocketActions.DELETE:
          //     dispatch(LiveUserActions.removeChat({ chat: data, email: userEmail }));
          //     break;
        }
      }
    };
    wsLiveUserChatMessagesCallback.current = (message: IMessage) => {
      const updatedItem: WebSocketEntity = JSON.parse(message.body);

      // Change type later
      const data: LiveUserChatMessage = JSON.parse(updatedItem.itemAsString);

      if (LiveUserUtils(undefined).isMessageUser(data, userEmail)) {
        if (data.message === 'Typing...') {
          if (timer) clearTimeout(timer);
          dispatch(LiveUserActions.typing(data));
          timer = setTimeout(() => {
            dispatch(LiveUserActions.stopTyping());
          }, 2000);
        } else {
          switch (updatedItem.action) {
            case E_WebSocketActions.CREATE:
            case E_WebSocketActions.UPDATE:
              dispatch(LiveUserActions.addOrUpdateChat({ chat: data, email: userEmail }));
              break;
            case E_WebSocketActions.DELETE:
              dispatch(LiveUserActions.removeChat({ chat: data, email: userEmail }));
              break;
          }
        }
      }
    };
  }, [dispatch]);
};
