import _ from 'lodash';
import { defaultLiveUserChatEntity, newUserActivityLoginTracking } from 'mock-values';
import { useEffect, useRef, useState } from 'react';
import { E_User_Status } from 'enums';
import { IUseDispatch, createNewLoginTracking, useAppDispatch } from 'store';
import { updateLiveUser } from 'store/thunk/liveUserThunk';
import { useANAInfo } from './useANAInfo';
import { usePrevious } from './usePrevious';

interface GeoLocation {
  latitude?: string;
  longitude?: string;
}

export const useLoginTracking = (identifier: string) => {
  const dispatch: IUseDispatch = useAppDispatch();
  const { anaKeycloak, token, email } = useANAInfo();
  const previousUsername = usePrevious(email);
  const [geoLocation, setGeoLocation] = useState<GeoLocation>({});
  const [geoPermissionAllowed, setGeoPermissionAllowed] = useState<boolean | undefined>(undefined);
  const lastProcessedToken = useRef(token);

  // Update Keycloak user tracking to use anaKeycloak
  useEffect(() => {
    if (anaKeycloak?.tokenParsed && lastProcessedToken.current !== token) {
      dispatch(
        updateLiveUser({
          key: anaKeycloak.tokenParsed.email || '',
          givenName: anaKeycloak.tokenParsed.given_name || '',
          aud: anaKeycloak.tokenParsed.aud || '',
          fullName: anaKeycloak.tokenParsed.name || '',
          familyName: anaKeycloak.tokenParsed.family_name || '',
          buList: (anaKeycloak.tokenParsed as any).bu_list || [],
          email: anaKeycloak.tokenParsed.email || '',
          buUrl: (anaKeycloak.tokenParsed as any).bu_url || '',
          bu: (anaKeycloak.tokenParsed as any).bu || '',
          status: E_User_Status.ONLINE,
          versionIdentifier: {},
          module: '',
          detail: '',
          liveUserChat: defaultLiveUserChatEntity,
        })
      );
      lastProcessedToken.current = token;
    }
  }, [anaKeycloak?.tokenParsed, token]);

  useEffect(() => {
    if (!_.isEmpty(email) && !_.isEmpty(token) && !_.isEmpty(geoLocation.latitude) && !_.isEmpty(geoLocation.longitude)) {
      dispatch(createNewLoginTracking(newUserActivityLoginTracking(email, identifier, geoLocation.latitude || '', geoLocation.longitude || '', token || '', true)));
    }
  }, [email, token, geoLocation, identifier]);

  useEffect(() => {
    if (geoPermissionAllowed) {
      const setPositionInfo: PositionCallback = (position: GeolocationPosition) => {
        setGeoLocation({
          latitude: position.coords.latitude.toString(),
          longitude: position.coords.longitude.toString(),
        });
      };
      navigator.geolocation.getCurrentPosition(setPositionInfo);
    } else if (geoPermissionAllowed === false) {
      setGeoLocation({ latitude: '0', longitude: '0' });
    }
  }, [geoPermissionAllowed]);

  useEffect(() => {
    /*
    this code is necessary...
    since callback inside getCurrentPosition will never be called without permission,
    we need to set geolocation to all 0 so that we can still log some user data.
    However, if we don't call any getCurrentPosition when permission is not granted. Browser will never ask user for permission so it will always be denied.
    */
    navigator.geolocation.getCurrentPosition(() => {});
    navigator.permissions.query({ name: 'geolocation' }).then(result => {
      if (result.state === 'granted') {
        setGeoPermissionAllowed(true);
      } else {
        setGeoPermissionAllowed(false);
      }
    });
  }, []);

  useEffect(() => {
    const cleanup = () => {
      dispatch(createNewLoginTracking(newUserActivityLoginTracking(_.isEmpty(email) ? (previousUsername ?? '') : email, identifier, geoLocation.latitude || '', geoLocation.longitude || '', token || '', false)));
    };
    window.addEventListener('beforeunload', cleanup, { once: true }); // It's for closing tab. Not duplicate
    return () => {
      window.removeEventListener('beforeunload', cleanup);
      // Your code here.
    };
  }, [previousUsername, email, token, geoLocation, identifier]);
};
