import { IMessage } from '@stomp/stompjs';
import { useEffect, useRef } from 'react';
import { LiveUserEntity, WebSocketEntity } from 'entities';
import { E_WebSock_Topic, E_WebSocketActions } from 'enums';
import { LiveUserActions, WebSocketService, tokenReference } from 'store';

export const useWSLiveUser = (userEmail: string, dispatch: any, users: { [x: string]: LiveUserEntity }) => {
  const wsLiveUserCallback = useRef<(message: IMessage) => void>(() => {
    throw new Error('wsLiveUserCallback is not initialized');
  });

  useEffect(() => {
    let wsInstance = WebSocketService.getInstance();
    if (!wsInstance.connecting && !wsInstance.connected) {
      wsInstance = WebSocketService.getInstance();
      wsInstance.email = userEmail;
      wsInstance.token = tokenReference.token;

      wsInstance.connect();
    }

    wsInstance.addSubscription(
      E_WebSock_Topic.TOPIC_LIVE_USER,
      (message: IMessage) => {
        wsLiveUserCallback.current(message);
      },
      true
    );
  }, []);

  useEffect(() => {
    wsLiveUserCallback.current = (message: IMessage) => {
      const updatedItem: WebSocketEntity = JSON.parse(message.body);

      // Change type later
      const data: LiveUserEntity = JSON.parse(updatedItem.itemAsString);

      switch (updatedItem.action) {
        case E_WebSocketActions.CREATE:
        case E_WebSocketActions.UPDATE:
          dispatch(LiveUserActions.addOrUpdateLiveUser({ liveUser: data, email: userEmail }));
          break;
        case E_WebSocketActions.DELETE:
          dispatch(LiveUserActions.removeLiveUsers({ user: data, email: userEmail }));
          break;
      }
    };
  }, [users, dispatch, userEmail]);
};
