import { GradeCodeEntity } from 'entities';

export const defaultGradeCodeEntity: GradeCodeEntity = {
  key: '',
  versionIdentifier: {},
  code: '',
  description: '',
};
