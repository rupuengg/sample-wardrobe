import { EquipmentCodeEntity } from 'entities';

export const defaultEquipmentCodeEntity: EquipmentCodeEntity = {
  key: '',
  versionIdentifier: {},
  equipmentCode: '',
  description: '',
  nature: 'Permanent',
  isSystemDefined: false,
  toBeDelete: false,
};
