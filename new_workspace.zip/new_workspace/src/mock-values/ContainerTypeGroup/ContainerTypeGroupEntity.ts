import { ContainerTypeGroupEntity } from 'entities';

export const EMPTY_CNTR_TYPE_GROUP_ENTITY: ContainerTypeGroupEntity = {
  key: '',
  versionIdentifier: {},
  cntrTypeGroup: '',
};
