import { HoldCodeEntity } from 'entities';

export const defaultHoldCodeEntity: HoldCodeEntity = {
  key: '',
  versionIdentifier: {},
  holdConditionCode: '',
  description: '',
  isSystemDefined: false,
  toBeDelete: false,
};
