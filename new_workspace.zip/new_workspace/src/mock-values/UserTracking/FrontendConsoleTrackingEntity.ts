import { FrontendConsoleTrackingEntity } from 'entities';
import { E_Frontend_Console_type } from 'enums';

export const defaultFrontendConsoleTrackingEntity: FrontendConsoleTrackingEntity = {
  userEmail: '',
  identifier: '',
  logDate: new Date(),
  type: E_Frontend_Console_type.LOG,
  message: '',
  stacktrace: '',
};

export const newFrontendConsoleTracking = (userEmail: string, identifier: string, type: E_Frontend_Console_type, message: string, stacktrace: string): FrontendConsoleTrackingEntity => {
  return {
    ...defaultFrontendConsoleTrackingEntity,
    userEmail: userEmail,
    identifier: identifier,
    logDate: new Date(),
    type: type,
    message: message,
    stacktrace: stacktrace,
  };
};
