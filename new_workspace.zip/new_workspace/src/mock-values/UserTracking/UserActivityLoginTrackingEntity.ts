import { UserActivityLoginTrackingEntity } from 'entities';

export const defaultUserActivityLoginTrackingEntity: UserActivityLoginTrackingEntity = {
  userEmail: '',
  identifier: '',
  accessDate: new Date(),
  latitude: '',
  longitude: '',
  token: '',
  isLogin: true,
};

export const newUserActivityLoginTracking = (userEmail: string, identifier: string, latitude: string, longitude: string, token: string, isLogin: boolean): UserActivityLoginTrackingEntity => {
  return {
    ...defaultUserActivityLoginTrackingEntity,
    userEmail: userEmail,
    identifier: identifier,
    accessDate: new Date(),
    latitude: latitude,
    longitude: longitude,
    token: token,
    isLogin: isLogin,
  };
};
