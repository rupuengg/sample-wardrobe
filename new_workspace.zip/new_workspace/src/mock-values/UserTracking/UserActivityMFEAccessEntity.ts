import { UserActivityMFEAccessEntity } from 'entities';

export const defaultUserActivityMFEAccessEntity: UserActivityMFEAccessEntity = {
  entrypoint: '',
  timeSpent: 0,
  userEmail: '',
  identifier: '',
  accessDateFrom: new Date(),
  accessDateTo: new Date(),
};

export const newUserActivityMFEAccess = (entrypoint: string, timeSpent: number, userEmail: string, identifier: string, accessDateFrom: Date): UserActivityMFEAccessEntity => {
  return {
    ...defaultUserActivityMFEAccessEntity,
    entrypoint: entrypoint,
    timeSpent: timeSpent,
    userEmail: userEmail,
    identifier: identifier,
    accessDateFrom: accessDateFrom,
    accessDateTo: new Date(),
  };
};
