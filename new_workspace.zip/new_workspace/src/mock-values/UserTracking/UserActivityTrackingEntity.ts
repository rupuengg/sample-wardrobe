import { UserActivityTrackingEntity } from 'entities';

export const defaultUserActivityTrackingEntity: UserActivityTrackingEntity = {
  key: '',
  versionIdentifier: {},
  page: '',
  event: '',
  logDateTime: new Date(),
  userEmail: '',
};

export const newUserActivityTracking = (page: string, event: string, userEmail: string): UserActivityTrackingEntity => {
  return {
    ...defaultUserActivityTrackingEntity,
    page: page,
    event: event,
    userEmail: userEmail,
    logDateTime: new Date(),
  };
};
