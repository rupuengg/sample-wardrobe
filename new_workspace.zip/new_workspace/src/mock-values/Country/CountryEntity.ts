import { CountryEntity } from 'entities';

export const defaultCountryEntity: CountryEntity = {
  key: '',
  versionIdentifier: {},
  countryCode: '',
  countryName: '',
};
