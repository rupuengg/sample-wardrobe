import { ContainerTypeEntity } from 'entities';

export const defaultContainerTypeEntity: ContainerTypeEntity = {
  key: '',
  versionIdentifier: {},
  cntrType: '',
  encodedScheme: 'ISTN',
  toBeDelete: false,
};
