import { SpecialHandlingCodeEntity } from 'entities';

export const defaultSpecialHandlingCodeEntity: SpecialHandlingCodeEntity = {
  key: '',
  versionIdentifier: {},
  specialHandleCode: '',
  description: '',
  isSystemDefined: false,
  toBeDelete: false,
};
