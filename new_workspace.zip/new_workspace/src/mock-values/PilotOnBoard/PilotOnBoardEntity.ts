import { PilotOnBoardEntity } from 'entities';

export const defaultPilotOnBoardEntity: PilotOnBoardEntity = {
  key: '',
  versionIdentifier: {},
  pilotOnBoard: '',
  isDefault: false,
  toBeDelete: false,
};
