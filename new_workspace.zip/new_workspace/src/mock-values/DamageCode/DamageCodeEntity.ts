import { DamageCodeEntity } from 'entities';

export const defaultDamageCodeEntity: DamageCodeEntity = {
  key: '',
  versionIdentifier: {},
  code: '',
  type: 'Severity',
  toBeDelete: false,
};
