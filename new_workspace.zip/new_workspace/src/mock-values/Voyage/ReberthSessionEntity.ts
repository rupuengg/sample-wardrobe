import { ReberthSessionEntity } from 'entities';

export const defaultReberthSessionEntity: ReberthSessionEntity = {
  key: '',
  versionIdentifier: {},
  id: '',
  arrivalDate: '',
  berthDate: '',
  departureDate: '',
  berthingTerminal: '',
  berthingBridge: '',
};
