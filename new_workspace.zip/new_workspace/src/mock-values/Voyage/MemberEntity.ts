import { MemberEntity } from 'entities';

export const defaultMemberEntity: MemberEntity = {
  key: '',
  versionIdentifier: {},
  memberSlotBuyer: '',
};
