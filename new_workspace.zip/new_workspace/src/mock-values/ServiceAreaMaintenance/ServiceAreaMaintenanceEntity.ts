import { ServiceAreaBlockEntity, ServiceAreaMaintenanceEntity } from 'entities';

export const defaultServiceAreaBlockEntity: ServiceAreaBlockEntity = {
  key: '',
  versionIdentifier: {},
  serviceAreaId: '',
  blockId: '',
  maxPickMove: '',
  maxGroundMove: '',
  maxTotalMove: '',
  currentPickMove: '',
  currentGroundMove: '',
  currentTotalMove: '',
};

export const defaultServiceAreaMaintenanceEntity: ServiceAreaMaintenanceEntity = {
  serviceAreaId: '',
  serviceAreaBlockType: '',
  seqAccSaMvtCntrIntChgMode: 'B',
  parentTrtTfcServiceAreaId: '',
  maxHotMoveTractorCount: '',
  currHotMoveTractorCount: '',
  equipmentExist: true,
  fromDateTime: '',
  toDateTime: '',
  effective: false,
  effectiveTimeMaxTractor: '',
  virtualLocation: [''],
  serviceAreaBlock: null,
  key: '',
  versionIdentifier: {},
};
