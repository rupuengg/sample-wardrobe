import { DangerousCodeEntity } from 'entities';

export const defaultDangerousCodeEntity: DangerousCodeEntity = {
  key: '',
  versionIdentifier: {},
  imdgCode: '',
  toBeDelete: false,
};
