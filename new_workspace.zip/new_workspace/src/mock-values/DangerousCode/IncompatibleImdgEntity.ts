import { IncompatibleImdgEntity } from 'entities';

export const defaultIncompatibleImdgEntity: IncompatibleImdgEntity = {
  key: '',
  versionIdentifier: {},
  imdgCode: '',
  minSegregationDistanceStack: 0,
  minSegregationDistanceMeter: 0,
};
