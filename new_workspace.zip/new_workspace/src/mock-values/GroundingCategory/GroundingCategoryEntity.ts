import { GroundingCategoryEntity } from 'entities';

export const defaultGroundingCategoryEntity: GroundingCategoryEntity = {
  key: '',
  versionIdentifier: {},
  consolidatedCategory: '',
  containerCategory: '',
};
