import { WorkingShiftEntity } from 'entities';

export const defaultWorkingShiftEntity: WorkingShiftEntity = {
  key: '',
  versionIdentifier: {},
  shiftCode: '',
  startTime: '00:00',
  endTime: '00:00',
  symbol: 'Icon-sunset',
};
