import { QcPoolAssignmentEntity, QcPoolResponse } from 'entities';

export const defaultQcPoolAssignmentEntity: QcPoolAssignmentEntity = {
  qcNo: '',
  dual: '',
  coVslVoy: '',
  status: 'Idle',
  minIt: '',
  maxIt: '',
  chassisType: '',
  twinMove: '',
  speedUp: '',
  twinMoveRf: 'Y',
  twinMoveProhibitIT: '',
  inUseIT: '0',
};

export const defaultQcPoolResponse: QcPoolResponse = {
  poolNo: '',
  tractorInPool: '',
  inUsedIT: '',
  itProvider: '',
  operationMode: '',
  key: '',
  qcNo: '',
  qcPoolAssignment: [],
};
