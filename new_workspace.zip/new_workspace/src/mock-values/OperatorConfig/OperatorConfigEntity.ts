import { OperatorConfigEntity } from 'entities';

export const defaultOperatorConfigEntity: OperatorConfigEntity = {
  key: '',
  versionIdentifier: {},
  id: 0,
  portId: 0,
  code: '',
  description: '',
};
