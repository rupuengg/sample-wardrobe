import { PortEntity } from 'entities';

export const defaultPortEntity: PortEntity = {
  key: '',
  versionIdentifier: {},
  portCode: '',
  portName: '',
  countryCode: '',
  toBeDelete: false,
  portConditions: null,
  color: '807d7d',
};
