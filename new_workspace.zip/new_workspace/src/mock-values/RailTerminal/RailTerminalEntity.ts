import { RailTerminalEntity } from 'entities';

export const defaultRailTerminalEntity: RailTerminalEntity = {
  key: '',
  versionIdentifier: {},
  id: 0,
  portId: 0,
  code: '',
  description: '',
  defaultPortDrawingOrder: '',
};
