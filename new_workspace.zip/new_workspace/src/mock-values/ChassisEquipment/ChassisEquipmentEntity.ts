import { ChassisEquipmentEntity } from 'entities';

export const defaultChassisEquipmentEntity: ChassisEquipmentEntity = {
  key: '',
  versionIdentifier: {},
  chassisType: '',
  chassisWeightWithoutCargo: null,
  maximumCargoWeight: null,
  containerLengthListModifier: '',
  containerTypeGroupListModifier: '',
  equipmentCodeListModifier: '',
  specialHandleCodeListModifier: '',
  chassisTypeDescription: '',
  containerLengthList: '',
  listDelimiter: '',
  containerTypeGroupList: '',
  equipmentCodeList: '',
  specialHandleCodeList: '',
  containerTypeGpCarryingCfgList: '',
};
