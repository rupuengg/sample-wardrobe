import { LocationGroupEntity } from 'entities';
import { E_Criteria_Type } from 'enums';

export const defaultLocationGroupEntity: LocationGroupEntity = {
  key: '',
  versionIdentifier: {},
  groupName: '',
  criteriaType: E_Criteria_Type.INCLUDE,
  locationTypes: [],
  virtualLocations: [],
};
