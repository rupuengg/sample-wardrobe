import { LocationTypeEntity } from 'entities';

export const defaultLocationTypeEntity: LocationTypeEntity = {
  key: '',
  versionIdentifier: {},
  code: '',
  description: '',
};
