import { SpecialArrangementCodeEntity } from 'entities';

export const defaultSpecialArrangementCodeEntity: SpecialArrangementCodeEntity = {
  key: '',
  versionIdentifier: {},
  specialArrangementId: '',
  buId: '',
  name: '',
  serviceLevel: '',
  contentDisplayType: '',
  textDescription: '',
  color: '',
  symbol: '',
  symbolImport: '',
};
