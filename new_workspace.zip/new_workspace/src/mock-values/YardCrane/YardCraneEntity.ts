import { YardCraneEntity } from 'entities';

export const defaultYardCraneEntity: YardCraneEntity = {
  key: '',
  versionIdentifier: {},
  yardCraneNo: '',
  yardCraneType: 'Automatic Stacking Crane',
  yardCraneSubType: '',
  operationMode: 'PDS',
  isVgmCertified: false,
  isTieDown: false,
  enableMaintenance: false,
  servingArea: 'All',
};
