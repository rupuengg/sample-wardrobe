import { ZoneAmendHistory } from 'entities';

export const defaultZoneAmendHistory: ZoneAmendHistory = {
  key: '',
  versionIdentifier: {},

  updatedTime: '',
  amendItem: '',
  staffId: '',
  previousValue: '',
  updatedValue: '',
};
