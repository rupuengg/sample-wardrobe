import { RangeEntity } from 'entities';

export const defaultRangeEntity: RangeEntity = {
  rangeId: '',
  fromBlockId: '',
  fromStackId: '',
  toBlockId: '',
  toStackId: '',
};
