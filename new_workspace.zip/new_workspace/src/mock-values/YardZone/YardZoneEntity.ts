import { YardZoneEntity } from 'entities';

export const defaultYardZoneEntity: YardZoneEntity = {
  key: '',
  versionIdentifier: {},
  zoneId: '',
  description: '',
  category: '',
  range: [],
};
