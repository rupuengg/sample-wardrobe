import { IMenuEntity } from 'entities';

export const defaultMenuEntity: IMenuEntity = {
  key: '',
  versionIdentifier: {},
  menuId: '',
};
