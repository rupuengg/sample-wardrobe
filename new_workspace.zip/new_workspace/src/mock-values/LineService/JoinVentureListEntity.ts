import { JoinVentureListEntity } from 'entities';

export const defaultJoinVentureListEntity: JoinVentureListEntity[] = [
  { terminal: '', line: '', service: '' },
  { terminal: '', line: '', service: '' },
];
