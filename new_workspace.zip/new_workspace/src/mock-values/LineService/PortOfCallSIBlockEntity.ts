import { PortOfCallSIBlockEntity } from 'entities';

export const defaultPortOfCallSIBlockEntity: PortOfCallSIBlockEntity = {
  key: '',
  versionIdentifier: {},
  portCallSIBlockSequence: 0,
  portCallSIBlock: '',
};
