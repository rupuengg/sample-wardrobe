import { PortOfCallSIEntity } from 'entities';

export const defaultPortOfCallSIEntity: PortOfCallSIEntity = {
  key: '',
  versionIdentifier: {},
  portCallSISequence: 0,
  portCallSI: '',
};
