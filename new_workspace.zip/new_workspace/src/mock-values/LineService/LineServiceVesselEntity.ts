import { LineServiceVesselEntity } from 'entities';

export const defaultLineServiceVesselEntity: LineServiceVesselEntity = {
  key: '',
  versionIdentifier: {},
  berthSide: 'Port',
};
