import { PortOfCallSIBlockMemberRegionEntity } from 'entities';

export const defaultPortOfCallSIBlockMemberRegionEntity: PortOfCallSIBlockMemberRegionEntity = {
  key: '',
  versionIdentifier: {},
  memberLine: '',
  memberLineRegion: '',
  isSelected: true,
};
