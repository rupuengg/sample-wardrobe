import { LineServiceMemberEntity } from 'entities';

export const defaultLineServiceMemberEntity: LineServiceMemberEntity = {
  key: '',
  versionIdentifier: {},
  serviceMemberLine: '',
  serviceMemberLineRegion: '',
  obGenCntrClsWeekDay: 'Not Fixed',
  obRfrCntrClsWeekDay: 'Not Fixed',
  obDgCntrClsWeekDay: 'Not Fixed',
  memberServiceCode: '',
  soa: false,
};
