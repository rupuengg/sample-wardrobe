import { PortOfCallEntity } from 'entities';

export const defaultPortOfCallEntity: PortOfCallEntity = {
  key: '',
  versionIdentifier: {},
  portCallSequence: 0,
  portCall: '',
  isPOD: false,
};
