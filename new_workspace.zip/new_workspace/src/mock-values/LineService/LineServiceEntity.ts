import { LineServiceEntity } from 'entities';
import { defaultJoinVentureListEntity } from './JoinVentureListEntity';

export const defaultLineServiceEntity: LineServiceEntity = {
  key: '',
  versionIdentifier: {},
  lineCode: '',
  serviceCode: '',
  portGenerationMode: false,
  membershipGenerationMode: false,
  color: 'ff0000',
  listEtaWeekDay: 'Not Fixed',
  listEtdWeekDay: 'Not Fixed',
  toBeDelete: false,
  proformaColor: '',
  lineColorRadio: '',
  joinVentureList: defaultJoinVentureListEntity,
};
