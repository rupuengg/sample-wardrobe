import { QuayCraneEntity } from 'entities';

export const defaultQuayCraneEntity: QuayCraneEntity = {
  key: '',
  versionIdentifier: {},
  berthingTml: '',
  quayCraneNo: '',
  type: 'Q',
  berth: '',
  tieDownIndr: false,
  twinLiftingSpreader: false,
  tandemLiftingSpreader: false,
  maintenanceIndr: false,
  maintenance: 'Repair',
  color: '807d7d',
};
