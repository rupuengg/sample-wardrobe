import { TieDownLocationEntity } from 'entities';

export const defaultTieDownLocationEntity: TieDownLocationEntity = {
  key: '',
  versionIdentifier: {},
  id: '',
  tmlId: '',
  locType: '',
  blockId: '',
  stack: '',
  lane: '',
  tier: '',
  locShortName: '',
  desc: '',
};
