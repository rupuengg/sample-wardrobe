import { ContainerHandlingVehicleEntity } from 'entities';

export const defaultContainerHandlingVehicleEntity: ContainerHandlingVehicleEntity = {
  key: '',
  versionIdentifier: {},
  containerHandlingVehicleNo: '',
  type: 'Frontloader',
  containerTypeHandling: 'Empty',

  enableMaintenance: false,
};
