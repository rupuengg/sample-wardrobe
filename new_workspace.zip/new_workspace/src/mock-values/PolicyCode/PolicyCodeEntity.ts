import { PolicyCodeEntity } from 'entities';

export const defaultPolicyCodeEntity: PolicyCodeEntity = {
  key: '',
  versionIdentifier: {},
  code: '',
  codeScheme: '',
  description: '',
};
