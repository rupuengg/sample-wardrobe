import { VirtualLocationEntity } from 'entities';

export const defaultVirtualLocationEntity: VirtualLocationEntity = {
  key: '',
  versionIdentifier: {},
  zcode: '',
  shortName: '',
  description: '',
};
