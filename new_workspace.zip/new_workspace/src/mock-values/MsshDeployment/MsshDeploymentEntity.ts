import { MsshPoolAssignmentEntity, MsshPoolResponse } from 'entities';

export const defaultMsshPoolResponse: MsshPoolResponse = {
  poolNo: '',
  tractorInPool: '',
  inUsedIT: '',
  itProvider: '',
  operationMode: '',
  key: '',
  msshCat: '',
  msshPoolAssignment: [],
};

export const defaultMsshPoolAssignmentEntity: MsshPoolAssignmentEntity = {
  key: '',
  versionIdentifier: {},
  activeorHotMove: '',
  msshType: '',
  msshCat: '',
  suspendInd: '',
  suspendStaffId: '',
  speedUp: '',
  minIt: '',
  maxIt: '',
  chassisType: '',
  twinMove: '',
  twinMoveRf: 'Y',
  twinMoveProhibitIT: '',
  inUseIT: '',
};
