import { VesselEntity } from 'entities';

export const defaultVesselEntity: VesselEntity = {
  key: '',
  versionIdentifier: {},
  vesselCode: '',
  vesselType: '',
  vesselModelName: '',
  vesselName: '',
  nationality: '',
  placeOfRegister: '',
  callSign: '',
  lloydsCode: '',
  soa: '',
  soaVesselCode: '',
  enablePreferBerthSide: false,
  hideBridgeMark: false,
  toBeDelete: false,

  vesselModelId: '',
};
