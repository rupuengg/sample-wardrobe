import { ITPagerEntity } from 'entities';

export const defaultITPagerEntity: ITPagerEntity = {
  key: '',
  versionIdentifier: {},
  pagerNo: '',
  // pagerType: "",
  xmlAddr: '',
  physicalAddr: '',
  pagingChannelId: '',
  suspendIndr: '',
  suspendReason: '',
  pagerApplicationCategory: '',
  listDelimiter: '',
  pagerDisplayLanguageList: '',
};
