import { LineEntity } from 'entities';

export const defaultLineEntity: LineEntity = {
  key: '',
  versionIdentifier: {},
  lineCode: '',
  lineCompanyName: '',
  lineCategory: 'C',
  emailAddress: '',
  phoneNo: '',
  address: '',
  toBeDelete: false,
  color: '807d7d',
  contractual: false,
};
