import { LineRegionEntity } from 'entities';

export const defaultLineRegionEntity: LineRegionEntity = {
  key: '',
  versionIdentifier: {},
  regionCode: '',
  regionDescription: '',
  billCode: '',
};
