import { TerminalOperationSettingEntity } from 'entities';

export const defaultTerminalOperationSettingEntity: TerminalOperationSettingEntity = {
  key: '',
  versionIdentifier: {},
  settingName: '',
  settingValues: [],
};
