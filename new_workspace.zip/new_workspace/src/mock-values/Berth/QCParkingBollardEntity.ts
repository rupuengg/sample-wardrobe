import { QCParkingBollardEntity } from 'entities';

export const defaultQCParkingBollardEntity: QCParkingBollardEntity = {
  key: '',
  versionIdentifier: {},
  qcId: '',
};
