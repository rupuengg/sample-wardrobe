import { BerthEntity } from 'entities';

export const defaultBerthEntity: BerthEntity = {
  key: '',
  versionIdentifier: {},
  berthId: '',
  berthLabel: '',
  terminalId: '',
  adjacentBerth: '',
  straightBerth: '',
  seaSide: 'Left',
  startPosition: 'N',
  endPosition: 'N',
  preferredBerthSide: 'Port',
  subBerth1Pos: 'N',
  subBerth2Pos: 'N',
  subBerth3Pos: 'N',
  // Remove this value when field is added to DB
  qcSequentialOrder: [],
};
