import { BollardEntity } from 'entities';

export const defaultBollardEntity: BollardEntity = {
  key: '',
  versionIdentifier: {},
  bollardIsVoided: false,
};
