import { QCSequentialOrderEntity } from 'entities';

export const defaultQCSequentialOrderEntity: QCSequentialOrderEntity = {
  quayCraneNo: '',
  position: 0,
};
