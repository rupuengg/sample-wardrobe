import { GateSummaryEntity, IGateSubSummary } from 'entities';

export const defaultGateSubSumarry: IGateSubSummary = {
  tractor: 1,
  container: 0,
};

export const defaultGateSummaryEntity: GateSummaryEntity = {
  gateIn: { ...defaultGateSubSumarry, tractor: 3, container: 0 },
  gateQueue: { ...defaultGateSubSumarry, tractor: 2, container: 0 },
  pending: { ...defaultGateSubSumarry, tractor: 2, container: 2 },
  active: { ...defaultGateSubSumarry, tractor: 1, container: 3 },
  hot: { ...defaultGateSubSumarry, tractor: 14, container: 14 },
  yardComplete: { ...defaultGateSubSumarry, tractor: 3, container: 6 },
  total: defaultGateSubSumarry,
};
