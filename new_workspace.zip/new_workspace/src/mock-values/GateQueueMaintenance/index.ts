export * from './GateSummaryEntity';
