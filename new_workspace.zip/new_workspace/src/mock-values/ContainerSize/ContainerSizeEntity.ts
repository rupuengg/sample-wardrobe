import { ContainerSizeEntity } from 'entities';

export const defaultContainerSizeEntity: ContainerSizeEntity = {
  key: '',
  versionIdentifier: {},
  cntrSize: '',
  containerSizeGroup: '',
  encodedScheme: 'ISTN',
  toBeDelete: false,
};
