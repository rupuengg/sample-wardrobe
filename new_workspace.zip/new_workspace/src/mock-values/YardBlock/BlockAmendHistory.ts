import { BlockAmendHistory } from 'entities';

export const defaultBlockAmendHistory: BlockAmendHistory = {
  key: '',
  versionIdentifier: {},

  updatedTime: '',
  amendItem: '',
  staffId: '',
  previousValue: '',
  updatedValue: '',
};
