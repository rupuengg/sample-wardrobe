import { LaneEntity } from 'entities';
import { defaultLaneContainerRestrictionEntity } from './LaneContainerRestrictionEntity';

export const defaultLaneEntity: LaneEntity = {
  key: '',
  versionIdentifier: {},
  laneID: '',
  stackableHeight: null,
  useExtendedHeight: null,
  laneType: '',
  void: null,
  densityCheck: null,
  laneContainerRestriction: defaultLaneContainerRestrictionEntity,
  remark: '',
};
