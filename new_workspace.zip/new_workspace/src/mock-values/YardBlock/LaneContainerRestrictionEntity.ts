import { LaneContainerRestrictionEntity } from 'entities';

export const defaultLaneContainerRestrictionEntity: LaneContainerRestrictionEntity = {
  noGrounding: null,
  noShuffleGrounding: null,
  noPickup: null,
  noMarshallingPickup: null,
  noGateGeneralEMPickup: null,
  noGateNominatePickup: null,
  noIMPickup: null,
  noEMLoading: null,
};

export const disableLaneContainerRestrictionEntity: LaneContainerRestrictionEntity = {
  noGrounding: true,
  noShuffleGrounding: true,
  noPickup: true,
  noMarshallingPickup: true,
  noGateGeneralEMPickup: true,
  noGateNominatePickup: true,
  noIMPickup: true,
  noEMLoading: true,
};
