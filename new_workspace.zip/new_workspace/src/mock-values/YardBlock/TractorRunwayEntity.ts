import { TractorRunwayEntity } from 'entities';

export const defaultTractorRunwayEntity: TractorRunwayEntity = {
  runwayID: '',
  position: '',
  trafficDirection: '',
  type: '',
};
