import { StackEntity } from 'entities';
import { defaultStackContainerRestrictionEntity } from './StackContainerRestrictionEntity';
import { defaultStackSafetyEntity } from './StackSafetyEntity';

export const defaultStackEntity: StackEntity = {
  key: '',
  versionIdentifier: {},
  blockId: '',
  stackId: '',
  stackRangeFrom: '',
  stackRangeTo: '',
  noOfLanes: null,
  maxContainerAllowed: null,
  plannedStackableHeight: null,
  safetyStackableHeight: null,
  maxExtendedHeight: null,
  doorDirection: 'Larger Stack No.',
  stackContainerRestriction: defaultStackContainerRestrictionEntity,
  stackSafetyInfo: defaultStackSafetyEntity,
  stackLanes: [],
};
