import { YardBlockEntity } from 'entities';
import { defaultTractorRunwayEntity } from './TractorRunwayEntity';
import { defaultYardBlockSafetyEntity } from './YardBlockSafetyEntity';

export const defaultYardBlockEntity: YardBlockEntity = {
  key: '',
  versionIdentifier: {},
  blockId: '',
  terminal: 'TTY',
  blockRangeFrom: '',
  blockRangeTo: '',
  yardAreaID: 'DLY',
  railStationCode: '',
  blockUsage: 'General Stacking',
  equipmentType: 'T-RTGC',
  tractorRunways: [
    defaultTractorRunwayEntity,
    {
      runwayID: '',
      position: '',
      trafficDirection: '',
      type: '',
    },
  ],
  yardBlockSafety: defaultYardBlockSafetyEntity,
  blockStacks: [],
  safety: '',
  remark: '',
};
