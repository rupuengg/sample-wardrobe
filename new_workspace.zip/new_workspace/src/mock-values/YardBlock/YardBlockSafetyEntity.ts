import { YardBlockSafetyEntity } from 'entities';

export const defaultYardBlockSafetyEntity: YardBlockSafetyEntity = {
  checkStackableHeightvsYCLimit: '',
};
