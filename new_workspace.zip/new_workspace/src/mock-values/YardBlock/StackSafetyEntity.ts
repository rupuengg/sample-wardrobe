import { StackSafetyEntity } from 'entities';

export const defaultStackSafetyEntity: StackSafetyEntity = {
  checkIsolatedLane: '',
  isolatedLaneHeightLimitInFeet: '',
};
