import { DamageCodeAllowedEntity, StackContainerRestrictionEntity } from 'entities';

export const defaultDamageCodeAllowedEntity: DamageCodeAllowedEntity = {
  content: '',
  position: '',
  prohibit: false,
};

export const defaultStackContainerRestrictionEntity: StackContainerRestrictionEntity = {
  containerSizeAllowed: [],
  isStackContainerSizeAllowedAny: false,
  nextContainerSize: '',
  isNextContainerSizeAllowedAny: false,
  currentContainerSize: '',
  containerTypeGroupAllowed: [],
  containerHeightAllowed: [],
  grossWeightLimitAllowed: '',
  reeferVoltageAllowed: [],
  tradeModeAllowed: '',
  dgGroundingStrategy: '',
  imdgAllowed: [],
  isImdgProhibited: false,
  undgAllowed: [],
  isUndgProhibited: false,
  equipmentCodeAllowed: [],
  isEquipmentCodeProhibited: false,
  holdCodeAllowed: [],
  isHoldCodeProhibited: false,
  specialHandleCodeAllowed: [],
  isSpecialHandleCodeProhibited: false,
  damageCodeAllowed: [],
  isDamageCodeProhibited: false,
};
