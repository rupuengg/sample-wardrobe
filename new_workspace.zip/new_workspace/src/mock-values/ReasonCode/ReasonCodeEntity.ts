import { ReasonCodeEntity } from 'entities';

export const defaultReasonCodeEntity: ReasonCodeEntity = {
  key: '',
  versionIdentifier: {},
  type: 'terminalEquipmentGoSlowReason',
  code: '',
};
