import { ProvinceEntity } from 'entities';

export const defaultProvinceEntity: ProvinceEntity = {
  key: '',
  versionIdentifier: {},
  provinceCode: '',
  provinceName: '',
  countryCode: '',
};
