import { LiveUserChatEntity, LiveUserChatMessage, LiveUserEntity } from 'entities';
import { E_Message_Type, E_User_Status } from 'enums';

export const defaultLiveUserChatEntity: LiveUserChatEntity = {
  key: '',

  userOne: '',
  userTwo: '',
  isUserOneChatActive: false,
  isUserTwoChatActive: false,
  userOneUnreadCount: 0,
  userTwoUnreadCount: 0,
  chat: [],
};

export const defaultLiveUserEntity: LiveUserEntity = {
  key: '',

  givenName: '',
  aud: '',
  fullName: '',
  familyName: '',
  buList: [],
  email: '',
  buUrl: '',
  bu: '',
  status: E_User_Status.OFFLINE,
  module: '',
  detail: '',

  liveUserChat: defaultLiveUserChatEntity,

  versionIdentifier: {
    version: 'NEW',
  },
};

export const defaultLiveUserChatMessage: LiveUserChatMessage = {
  fromUser: '',
  toUser: '',
  messageType: E_Message_Type.TEXT,
  message: '',
  chatOn: '',
};

export const makeLiveUserEntry = (json: any): LiveUserEntity => ({ ...defaultLiveUserEntity, detail: JSON.stringify(json) });
