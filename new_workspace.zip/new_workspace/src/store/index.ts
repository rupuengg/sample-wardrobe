import { combineReducers, configureStore } from '@reduxjs/toolkit';
import { useDispatch } from 'react-redux';
import { workspaceReducer } from 'store';
import { entityDataReducer, liveUserReducer } from './slices';

export * from './constants';
export * from './services';
export * from './slices';
export * from './socket';
export * from './states';
export * from './thunk';

const rootReducer = combineReducers({
  // dataManagement: dataManagementReducer,
  // dataAnalyzer: dataAnalyzerReducer,
  liveUser: liveUserReducer,
  entityData: entityDataReducer,
  workspace: workspaceReducer,
});

export const store = configureStore({
  reducer: rootReducer,
  devTools: process.env.REACT_APP_ENVIRONMENT === 'development',
});

export type IApplicationState = ReturnType<typeof store.getState>;
export type IUseDispatch = any;
export const useAppDispatch = () => useDispatch<typeof store.dispatch>();
