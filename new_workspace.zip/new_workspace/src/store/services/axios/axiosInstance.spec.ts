import axiosMock from 'jest-mock-axios';
import { axiosWithIntercepter } from 'store';

const API_ENDPOINT = 'http://localhost:9000/some_route';
const TOKEN1 = 'test';
const TOKEN2 = 'token';

declare module 'axios' {
  export interface AxiosInterceptorManager<V> {
    use(onFulfilled?: (value: V) => V | Promise<V>, onRejected?: (error: any) => any): number;
    eject(id: number): void;
    handlers: any[];
  }
}

const mockGetItem = jest.fn();
const mockSetItem = jest.fn();
const mockRemoveItem = jest.fn();
Object.defineProperty(window, 'localStorage', {
  value: {
    getItem: (...args: string[]) => mockGetItem(...args),
    setItem: (...args: string[]) => mockSetItem(...args),
    removeItem: (...args: string[]) => mockRemoveItem(...args),
  },
});

describe('dataManagementAxiosInstance', () => {
  it('Initialize', async () => {
    axiosMock.get(API_ENDPOINT);
    jest.spyOn(global.localStorage, 'getItem').mockImplementation(() => TOKEN1);

    const axiosInstance = axiosWithIntercepter(API_ENDPOINT, true);
    const config = await axiosInstance.interceptors.request.handlers[0].fulfilled({
      url: API_ENDPOINT,
      headers: {
        Authorization: 'Bearer ' + TOKEN1,
      },
    });

    expect(config.headers).toEqual({ Authorization: 'Bearer ' + TOKEN1 });
  });

  it('Initialize - token', async () => {
    axiosMock.get(API_ENDPOINT);
    jest.spyOn(global.localStorage, 'getItem').mockImplementation(() => TOKEN2);

    const axiosInstance = axiosWithIntercepter(API_ENDPOINT, true);
    const config = await axiosInstance.interceptors.request.handlers[0].fulfilled({
      url: API_ENDPOINT,
      headers: {
        Authorization: 'Bearer ' + TOKEN2,
      },
    });

    expect(config.headers).toEqual({ Authorization: 'Bearer ' + TOKEN2 });
  });
});
