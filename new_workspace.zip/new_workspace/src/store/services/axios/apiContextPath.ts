import {
  isAlessiaUsingKong,
  isBerthPlanningUsingKong,
  isControlTowerGeoMapUsingKong,
  isControlTowerUsingKong,
  isDataManagementUsingKong,
  isInventoryManagementUsingKong,
  isRaasUsingKong,
  isSupportUsingKong,
  isTerminalModelUsingKong,
  isVesselPlanningUsingKong,
  isWorkspaceUsingKong,
  isYardManagementUsingKong,
} from 'utils';

export const TERMINAL_MODEL_API_CONTEXT_PATH = isTerminalModelUsingKong ? process.env.REACT_APP_KONG_GATEWAY_TERMINAL_MODEL_API_URI : process.env.REACT_APP_TERMINAL_MODEL_API_URI;
export const VESSEL_PLANNING_API_CONTEXT_PATH = isVesselPlanningUsingKong ? process.env.REACT_APP_KONG_GATEWAY_VESSEL_PLANNING_API_URI : process.env.REACT_APP_VESSEL_PLANNING_API_URI;
export const GEOMAP_API_CONTEXT_PATH = isControlTowerGeoMapUsingKong ? process.env.REACT_APP_KONG_GATEWAY_GEOMAP_API_URI : process.env.REACT_APP_GEOMAP_API_URI;
export const CONTROL_TOWER_API_CONTEXT_PATH = isControlTowerUsingKong ? process.env.REACT_APP_KONG_GATEWAY_CONTROL_TOWER_API_URI : process.env.REACT_APP_CONTROL_TOWER_API_URI;
export const SUPPORT_API_CONTEXT_PATH = isSupportUsingKong ? process.env.REACT_APP_KONG_GATEWAY_SUPPORT_API_URI : process.env.REACT_APP_SUPPORT_API_URI;
export const YARD_MANAGEMENT_API_CONTEXT_PATH = isYardManagementUsingKong ? process.env.REACT_APP_KONG_GATEWAY_YARD_MANAGEMENT_API_URI : process.env.REACT_APP_YARD_MANAGEMENT_API_URI;
export const WORKSPACE_API_CONTEXT_PATH = isWorkspaceUsingKong ? process.env.REACT_APP_KONG_GATEWAY_WORKSPACE_API_URI : process.env.REACT_APP_WORKSPACE_API_URI;
export const INVENTORY_MANAGEMENT_API_CONTEXT_PATH = isInventoryManagementUsingKong ? process.env.REACT_APP_KONG_GATEWAY_INVENTORY_MANAGEMENT_API_URI : process.env.REACT_APP_INVENTORY_MANAGEMENT_API_URI;
export const BERTH_PLANNING_API_CONTEXT_PATH = isBerthPlanningUsingKong ? process.env.REACT_APP_KONG_GATEWAY_BERTH_PLANNING_API_URI : process.env.REACT_APP_BERTH_PLANNING_API_URI;
export const DATA_MANAGEMENT_API_CONTEXT_PATH = isDataManagementUsingKong ? process.env.REACT_APP_KONG_GATEWAY_DATA_MANAGEMENT_API_URI : process.env.REACT_APP_DATA_MANAGEMENT_API_URI;
export const RAAS_MANAGEMENT_API_CONTEXT_PATH = isRaasUsingKong ? process.env.REACT_APP_KONG_GATEWAY_RAAS_API_URI : process.env.REACT_APP_RAAS_API_URI;
export const ALESSIA_MANAGEMENT_API_CONTEXT_PATH = isAlessiaUsingKong ? process.env.REACT_APP_KONG_GATEWAY_ALESSIA_API_URI : process.env.REACT_APP_ALESSIA_API_URI;
