import {
  isAlessiaUsingKong,
  isBerthPlanningUsingKong,
  isControlTowerGeoMapUsingKong,
  isControlTowerUsingKong,
  isDataManagementUsingKong,
  isInventoryManagementUsingKong,
  isRaasUsingKong,
  isSupportUsingKong,
  isTerminalModelUsingKong,
  isVesselPlanningUsingKong,
  isWorkspaceUsingKong,
  isYardManagementUsingKong,
} from 'utils';
import {
  ALESSIA_MANAGEMENT_API_CONTEXT_PATH,
  BERTH_PLANNING_API_CONTEXT_PATH,
  CONTROL_TOWER_API_CONTEXT_PATH,
  DATA_MANAGEMENT_API_CONTEXT_PATH,
  GEOMAP_API_CONTEXT_PATH,
  INVENTORY_MANAGEMENT_API_CONTEXT_PATH,
  RAAS_MANAGEMENT_API_CONTEXT_PATH,
  SUPPORT_API_CONTEXT_PATH,
  TERMINAL_MODEL_API_CONTEXT_PATH,
  VESSEL_PLANNING_API_CONTEXT_PATH,
  WORKSPACE_API_CONTEXT_PATH,
  YARD_MANAGEMENT_API_CONTEXT_PATH,
} from './apiContextPath';
import { axiosWithIntercepter, tokenReference } from './axiosInstance';

const berthPlanningAxiosInstance = axiosWithIntercepter(BERTH_PLANNING_API_CONTEXT_PATH, isBerthPlanningUsingKong);
const controlTowerAxiosInstance = axiosWithIntercepter(CONTROL_TOWER_API_CONTEXT_PATH, isControlTowerUsingKong);
const controlTowerGeoMapAxiosInstance = axiosWithIntercepter(GEOMAP_API_CONTEXT_PATH, isControlTowerGeoMapUsingKong);
const dataManagementAxiosInstance = axiosWithIntercepter(DATA_MANAGEMENT_API_CONTEXT_PATH, isDataManagementUsingKong);
const inventoryManagementAxiosInstance = axiosWithIntercepter(INVENTORY_MANAGEMENT_API_CONTEXT_PATH, isInventoryManagementUsingKong);
const supportAxiosInstance = axiosWithIntercepter(SUPPORT_API_CONTEXT_PATH, isSupportUsingKong);
const terminalModelAxiosInstance = axiosWithIntercepter(TERMINAL_MODEL_API_CONTEXT_PATH, isTerminalModelUsingKong);
const vesselPlanningAxiosInstance = axiosWithIntercepter(VESSEL_PLANNING_API_CONTEXT_PATH, isVesselPlanningUsingKong);
const workspaceAxiosInstance = axiosWithIntercepter(WORKSPACE_API_CONTEXT_PATH, isWorkspaceUsingKong);
const yardManagementAxiosInstance = axiosWithIntercepter(YARD_MANAGEMENT_API_CONTEXT_PATH, isYardManagementUsingKong);
const raasAxiosInstance = axiosWithIntercepter(RAAS_MANAGEMENT_API_CONTEXT_PATH, isRaasUsingKong);
const alessiaAxiosInstance = axiosWithIntercepter(ALESSIA_MANAGEMENT_API_CONTEXT_PATH, isAlessiaUsingKong);

export { tokenReference, axiosWithIntercepter };

export {
  berthPlanningAxiosInstance,
  controlTowerAxiosInstance,
  controlTowerGeoMapAxiosInstance,
  dataManagementAxiosInstance,
  inventoryManagementAxiosInstance,
  supportAxiosInstance,
  terminalModelAxiosInstance,
  vesselPlanningAxiosInstance,
  workspaceAxiosInstance,
  yardManagementAxiosInstance,
  raasAxiosInstance,
  alessiaAxiosInstance,
};
