import { IRecorderControls, MediaAudioTrackConstraints, useAudioRecorder } from '../../hooks/useAudioRecorder';
import { discardSVG, micSVG, pauseSVG, resumeSVG, saveSVG } from '../../icons';
import '../../styles/audio-recorder.css';
import React, { Suspense, useEffect, useState } from 'react';

const LiveAudioVisualizer = React.lazy(async () => {
  const { LiveAudioVisualizer } = await import('react-audio-visualize');
  return { default: LiveAudioVisualizer };
});

interface StyleProps {
  AudioRecorderClass?: string;
  AudioRecorderStartSaveClass?: string;
  AudioRecorderTimerClass?: string;
  AudioRecorderStatusClass?: string;
  AudioRecorderPauseResumeClass?: string;
  AudioRecorderDiscardClass?: string;
}

export interface IAudioRecorder {
  onRecordingComplete?: (blob: Blob) => void;
  onNotAllowedOrFound?: (exception: DOMException) => any;
  recorderControls?: IRecorderControls;
  audioTrackConstraints?: MediaAudioTrackConstraints;
  downloadOnSavePress?: boolean;
  downloadFileExtension?: 'mp3' | 'wav' | 'webm';
  showVisualizer?: boolean;
  mediaRecorderOptions?: MediaRecorderOptions;
  classes?: StyleProps;
}

export const AudioRecorder: React.FC<IAudioRecorder> = ({
  onRecordingComplete,
  onNotAllowedOrFound,
  recorderControls,
  audioTrackConstraints,
  downloadOnSavePress = false,
  downloadFileExtension = 'webm',
  showVisualizer = false,
  mediaRecorderOptions,
}) => {
  const recordingFeatures = useAudioRecorder(audioTrackConstraints, onNotAllowedOrFound, mediaRecorderOptions);
  const { startRecording, stopRecording, togglePauseResume, recordingBlob, isRecording, isPaused, recordingTime, mediaRecorder } = recorderControls ?? recordingFeatures;

  const [shouldSave, setShouldSave] = useState(false);

  const stopAudioRecorder: (save?: boolean) => void = (save: boolean = true) => {
    setShouldSave(save);
    stopRecording();
  };

  const convertToDownloadFileExtension = async (webmBlob: Blob): Promise<Blob> => {
    const FFmpeg = await import('@ffmpeg/ffmpeg');
    const ffmpeg = FFmpeg.createFFmpeg({ log: false });
    await ffmpeg.load();

    const inputName = 'input.webm';
    const outputName = `output.${downloadFileExtension}`;

    ffmpeg.FS('writeFile', inputName, new Uint8Array(await webmBlob.arrayBuffer()));

    await ffmpeg.run('-i', inputName, outputName);

    const outputData: any = ffmpeg.FS('readFile', outputName);
    const outputBlob = new Blob([outputData.buffer], {
      type: `audio/${downloadFileExtension}`,
    });

    return outputBlob;
  };

  const downloadBlob = async (blob: Blob): Promise<void> => {
    if (!crossOriginIsolated && downloadFileExtension !== 'webm') {
      console.warn(
        `This website is not "cross-origin isolated". Audio will be downloaded in webm format, since mp3/wav encoding requires cross origin isolation. Please visit https://web.dev/cross-origin-isolation-guide/ and https://web.dev/coop-coep/ for information on how to make your website "cross-origin isolated"`
      );
    }

    const downloadBlob = crossOriginIsolated ? await convertToDownloadFileExtension(blob) : blob;
    const fileExt = crossOriginIsolated ? downloadFileExtension : 'webm';
    const url = URL.createObjectURL(downloadBlob);

    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = `audio.${fileExt}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  useEffect(() => {
    if ((shouldSave || recorderControls) && recordingBlob != null && onRecordingComplete != null) {
      onRecordingComplete(recordingBlob);
      if (downloadOnSavePress) {
        void downloadBlob(recordingBlob);
      }
    }
  }, [recordingBlob]);

  const showRecordingClass = isRecording ? 'recording' : '';
  const hideRecordingClass = !isRecording ? 'display-none' : '';

  return (
    <div className={`audio-recorder ${showRecordingClass}`} data-testid='audio_recorder'>
      <img src={isRecording ? saveSVG : micSVG} className={`audio-recorder-mic`} onClick={isRecording ? () => stopAudioRecorder() : startRecording} data-testid='ar_mic' title={isRecording ? 'Save recording' : 'Start recording'} />
      <span className={`audio-recorder-timer ${hideRecordingClass}`} data-testid='ar_timer'>
        {Math.floor(recordingTime / 60)}:{String(recordingTime % 60).padStart(2, '0')}
      </span>
      {showVisualizer ? (
        <span className={`audio-recorder-visualizer ${hideRecordingClass}`}>
          {mediaRecorder && (
            <Suspense fallback={<></>}>
              <LiveAudioVisualizer mediaRecorder={mediaRecorder} barWidth={2} gap={2} width={140} height={30} fftSize={512} maxDecibels={-10} minDecibels={-80} smoothingTimeConstant={0.4} />
            </Suspense>
          )}
        </span>
      ) : (
        <span className={`audio-recorder-status ${hideRecordingClass}`}>
          <span className='audio-recorder-status-dot'></span>Recording
        </span>
      )}
      <img src={isPaused ? resumeSVG : pauseSVG} className={`audio-recorder-options ${hideRecordingClass}`} onClick={togglePauseResume} title={isPaused ? 'Resume recording' : 'Pause recording'} data-testid='ar_pause' />
      <img src={discardSVG} className={`audio-recorder-options ${hideRecordingClass}`} onClick={() => stopAudioRecorder(false)} title='Discard Recording' data-testid='ar_cancel' />
    </div>
  );
};
