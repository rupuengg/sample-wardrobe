import micSVG from './mic.svg';
import pauseSVG from './pause.svg';
import resumeSVG from './play.svg';
import saveSVG from './save.svg';
import discardSVG from './stop.svg';

export { micSVG, pauseSVG, resumeSVG, saveSVG, discardSVG };
