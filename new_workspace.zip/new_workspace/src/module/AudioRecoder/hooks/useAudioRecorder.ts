import { useCallback, useState } from 'react';

export interface IRecorderControls {
  startRecording: () => void;
  stopRecording: () => void;
  togglePauseResume: () => void;
  recordingBlob?: Blob;
  isRecording: boolean;
  isPaused: boolean;
  recordingTime: number;
  mediaRecorder?: MediaRecorder;
}

export type MediaAudioTrackConstraints = Pick<MediaTrackConstraints, 'deviceId' | 'groupId' | 'autoGainControl' | 'channelCount' | 'echoCancellation' | 'noiseSuppression' | 'sampleRate' | 'sampleSize'>;

export const useAudioRecorder: (audioTrackConstraints?: MediaAudioTrackConstraints, onNotAllowedOrFound?: (exception: DOMException) => any, mediaRecorderOptions?: MediaRecorderOptions) => IRecorderControls = (
  audioTrackConstraints,
  onNotAllowedOrFound,
  mediaRecorderOptions
) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder>();
  const [timerInterval, setTimerInterval] = useState<any>();
  const [recordingBlob, setRecordingBlob] = useState<Blob>();

  const _startTimer: () => void = useCallback(() => {
    const interval = setInterval(() => {
      setRecordingTime(time => time + 1);
    }, 1000);
    setTimerInterval(interval);
  }, [setRecordingTime, setTimerInterval]);

  const _stopTimer: () => void = useCallback(() => {
    timerInterval != null && clearInterval(timerInterval);
    setTimerInterval(undefined);
  }, [timerInterval, setTimerInterval]);

  const startRecording: () => void = useCallback(() => {
    if (timerInterval != null) return;

    navigator.mediaDevices
      .getUserMedia({ audio: audioTrackConstraints ?? true })
      .then(stream => {
        setIsRecording(true);
        const recorder: MediaRecorder = new MediaRecorder(stream, mediaRecorderOptions);
        setMediaRecorder(recorder);
        recorder.start();
        _startTimer();

        recorder.addEventListener('dataavailable', event => {
          setRecordingBlob(event.data);
          recorder.stream.getTracks().forEach(t => t.stop());
          setMediaRecorder(undefined);
        });
      })
      .catch((err: DOMException) => {
        throw err;
      });
  }, [timerInterval, setIsRecording, setMediaRecorder, _startTimer, setRecordingBlob, onNotAllowedOrFound, mediaRecorderOptions]);

  const stopRecording: () => void = useCallback(() => {
    mediaRecorder?.stop();
    _stopTimer();
    setRecordingTime(0);
    setIsRecording(false);
    setIsPaused(false);
  }, [mediaRecorder, setRecordingTime, setIsRecording, setIsPaused, _stopTimer]);

  const togglePauseResume: () => void = useCallback(() => {
    setIsPaused(!isPaused);
    if (isPaused) {
      mediaRecorder?.resume();
      _startTimer();
    } else {
      _stopTimer();
      mediaRecorder?.pause();
    }
  }, [mediaRecorder, setIsPaused, _startTimer, _stopTimer]);

  return { startRecording, stopRecording, togglePauseResume, recordingBlob, isRecording, isPaused, recordingTime, mediaRecorder };
};
