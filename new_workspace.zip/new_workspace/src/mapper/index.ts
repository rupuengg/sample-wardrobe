import { ColDef, ColGroupDef } from 'ag-grid-community';
import { IBaseForm, QuayCraneEntityForm } from 'forms';
import {
  defaultChassisEquipmentEntity,
  defaultContainerHandlingVehicleEntity,
  defaultContainerSizeEntity,
  defaultContainerTypeEntity,
  defaultDamageCodeEntity,
  defaultDangerousCodeEntity,
  defaultEquipmentCodeEntity,
  defaultGradeCodeEntity,
  defaultHoldCodeEntity,
  defaultITPagerEntity,
  defaultInternalTractorEntity,
  defaultLineEntity,
  defaultLocationGroupEntity,
  defaultPilotOnBoardEntity,
  defaultQuayCraneEntity,
  defaultRailTerminalEntity,
  defaultReasonCodeEntity,
  defaultSpecialHandlingCodeEntity,
  defaultTieDownLocationEntity,
  defaultVesselEntity,
  defaultVoyageEntity,
  defaultYardBlockEntity,
  defaultYardCraneEntity,
  defaultYardZoneEntity,
} from 'mock-values';
import { defaultOperatorConfigEntity } from 'mock-values/OperatorConfig';
import {
  getChassisTypeColumnSetting,
  getContainerHandlingVehicleColumnSetting,
  getContainerSizeColumnSetting,
  getContainerTypeColumnSetting,
  getDamageCodeColumnsSetting,
  getDangerousCodeColumnSetting,
  getEquipmentCodeColumnSetting,
  getGradeCodeColumnSetting,
  getHoldCodeColumnSetting,
  getITPagerColumnSetting,
  getInternalTractorColumnSetting,
  getLineColumnSetting,
  getLocationGroupColumnSetting,
  getOperatorConfigColumnSetting,
  getPilotOnBoardColumnSetting,
  getQuayCraneColumnSetting,
  getRailTerminalColumnSetting,
  getReasonCodeColumnSetting,
  getSpecialHandlingCodeColumnSetting,
  getTieDownLocationColumnSetting,
  getVesselColumnSetting,
  getVoyageColumnSetting,
  getYardBlockColumnSetting,
  getYardCraneColumnSetting,
  getYardZoneColumnSetting,
} from 'constant';
import { CommonEntity } from 'entities';
import { E_Mapping_Data } from 'enums';
import { isPermissionExist } from 'utils';
import { DataApiPath, IEndpoint, defaultEntityDataParams, getEndpoint } from 'store';
import { mapFormWithValues } from 'components';
import { ANAInfoModel, AclType, Permission, PermissionName } from 'module/Ana';

function getMappingData(mappingData: E_Mapping_Data, entrypoint?: string, anaInfo?: ANAInfoModel): Permission | IBaseForm | (ColDef<any> | ColGroupDef<CommonEntity>)[] {
  if (!entrypoint) throw new Error('Please entrypoint');

  const getCondition = (fun_ColumnSetting: any, permission: Permission, frm?: IBaseForm, defaultEntity?: CommonEntity) => {
    switch (mappingData) {
      case E_Mapping_Data.COLUMN_SETTING:
        return fun_ColumnSetting.apply(fun_ColumnSetting, [anaInfo]);
      case E_Mapping_Data.FORM:
        return frm;
      case E_Mapping_Data.PERMISSION:
        return permission;
      case E_Mapping_Data.DEFAULT_ENTITY:
        return defaultEntity;
      default:
    }
  };

  switch (entrypoint) {
    case 'chassisEquipmentMaintenance':
      return getCondition(getChassisTypeColumnSetting, Permission.CHASSIS_TYPE, undefined, defaultChassisEquipmentEntity);
    case 'containerHandlingVehicleMaintenance':
      return getCondition(getContainerHandlingVehicleColumnSetting, Permission.CONTAINER_HANDLING_VEHICLE, undefined, defaultContainerHandlingVehicleEntity);
    case 'tractorEquipmentMaintenance':
      return getCondition(getInternalTractorColumnSetting, Permission.INTERNAL_TRACTOR, undefined, defaultInternalTractorEntity);
    case 'quayCraneMaintenance':
      return getCondition(getQuayCraneColumnSetting, Permission.QUAY_CRANE, QuayCraneEntityForm, defaultQuayCraneEntity);
    case 'terminalConfig':
      // Change in future
      return getCondition(getRailTerminalColumnSetting, Permission.TERMINAL_OPERATION_SETTING, undefined, defaultRailTerminalEntity);
    case 'lineMaintenance':
      return getCondition(getLineColumnSetting, Permission.LINE, undefined, defaultLineEntity);
    case 'yardCraneMaintenance':
      return getCondition(getYardCraneColumnSetting, Permission.YARD_CRANE, undefined, defaultYardCraneEntity);
    case 'yardBlockMaintenance':
      return getCondition(getYardBlockColumnSetting, Permission.YARD_BLOCK, undefined, defaultYardBlockEntity);
    case 'yardZoneMaintenance':
      return getCondition(getYardZoneColumnSetting, Permission.YARD_ZONE, undefined, defaultYardZoneEntity);
    case 'containerSizeMaintenance':
      return getCondition(getContainerSizeColumnSetting, Permission.CONTAINER_SIZE, undefined, defaultContainerSizeEntity);
    case 'containerTypeMaintenance':
      return getCondition(getContainerTypeColumnSetting, Permission.CONTAINER_TYPE, undefined, defaultContainerTypeEntity);
    case 'damageCodeMaintenance':
      return getCondition(getDamageCodeColumnsSetting, Permission.DAMAGE_CODE, undefined, defaultDamageCodeEntity);
    case 'dangerousCodeMaintenance':
      return getCondition(getDangerousCodeColumnSetting, Permission.DG_CODE, undefined, defaultDangerousCodeEntity);
    case 'equipmentCodeMaintenance':
      return getCondition(getEquipmentCodeColumnSetting, Permission.ECODE, undefined, defaultEquipmentCodeEntity);
    case 'gradeCodeMaintenance':
      return getCondition(getGradeCodeColumnSetting, Permission.GRADE_CODE, undefined, defaultGradeCodeEntity);
    case 'holdCodeMaintenance':
      return getCondition(getHoldCodeColumnSetting, Permission.HOLD_CODE, undefined, defaultHoldCodeEntity);
    case 'reasonCodeMaintenance':
      return getCondition(getReasonCodeColumnSetting, Permission.REASON_CODE, undefined, defaultReasonCodeEntity);
    case 'specialHandlingCodeMaintenance':
      return getCondition(getSpecialHandlingCodeColumnSetting, Permission.SPECIAL_HANDLING_CODE, undefined, defaultSpecialHandlingCodeEntity);
    case 'tieDownLocationMaintenance':
      return getCondition(getTieDownLocationColumnSetting, Permission.TIE_DOWN_LOCATION, undefined, defaultTieDownLocationEntity);
    case 'itPager':
      return getCondition(getITPagerColumnSetting, Permission.PAGER, undefined, defaultITPagerEntity);
    case 'locationGroupMaintenance':
      return getCondition(getLocationGroupColumnSetting, Permission.LOCATION_GROUP, undefined, defaultLocationGroupEntity);
    case 'pilotOnBoardMaintenance':
      return getCondition(getPilotOnBoardColumnSetting, Permission.PILOT_ON_BOARD, undefined, defaultPilotOnBoardEntity);
    case 'operatorConfig':
      // Change in future
      return getCondition(getOperatorConfigColumnSetting, Permission.PILOT_ON_BOARD, undefined, defaultOperatorConfigEntity);
    case 'vesselMaintenance':
      return getCondition(getVesselColumnSetting, Permission.VESSEL, undefined, defaultVesselEntity);
    case 'voyageGeneralInformation':
      return getCondition(getVoyageColumnSetting, Permission.VOY_INFO, undefined, defaultVoyageEntity);
    default:
      return getCondition([], Permission.LOGIN);
  }
}

export class Mapper {
  private path?: string;
  private entrypoint?: string;
  private sectionId?: string | null;
  private endpoint?: string | IEndpoint;
  private permission?: Permission;
  private anaInfo?: ANAInfoModel;
  private form?: IBaseForm;
  private defaultEntity?: CommonEntity;

  constructor(path: string, entrypoint: string, sectionId?: string | null, anaInfo?: ANAInfoModel) {
    this.path = path;
    this.entrypoint = entrypoint;
    this.sectionId = sectionId;
    this.anaInfo = anaInfo;
  }

  setEndpoint() {
    if (this.path && this.entrypoint) this.endpoint = getEndpoint(this.path, DataApiPath[this.entrypoint]);
  }

  getPermission() {
    return this.permission;
  }

  setAnaInfoPermission() {
    if (this.anaInfo && this.anaInfo.allHphPermission && this.permission) {
      if (this.permission === Permission.LOGIN) {
        this.anaInfo = {
          ...this.anaInfo,
          allHphPermission: this.anaInfo.allHphPermission,
          currentBu: this.anaInfo.currentBu,
          token: this.anaInfo.token,
          allowRead: !!this.anaInfo.token,
          allowUpdate: !!this.anaInfo.token,
          allowCreate: !!this.anaInfo.token,
          allowDelete: !!this.anaInfo.token,
          email: this.anaInfo.email,
        };
      } else {
        this.anaInfo = {
          ...this.anaInfo,
          allHphPermission: this.anaInfo.allHphPermission,
          currentBu: this.anaInfo.currentBu,
          token: this.anaInfo.token,
          allowRead: isPermissionExist(PermissionName[this.permission], AclType.READ, this.anaInfo.allHphPermission),
          allowUpdate: isPermissionExist(PermissionName[this.permission], AclType.UPDATE, this.anaInfo.allHphPermission),
          allowCreate: isPermissionExist(PermissionName[this.permission], AclType.CREATE, this.anaInfo.allHphPermission),
          allowDelete: isPermissionExist(PermissionName[this.permission], AclType.DELETE, this.anaInfo.allHphPermission),
          email: this.anaInfo.email,
        };
      }
    }
  }

  getEndpointParams() {
    this.setEndpoint();
    this.permission = getMappingData(E_Mapping_Data.PERMISSION, this.entrypoint) as Permission;
    this.defaultEntity = getMappingData(E_Mapping_Data.DEFAULT_ENTITY, this.entrypoint) as CommonEntity;
    this.form = mapFormWithValues(getMappingData(E_Mapping_Data.FORM, this.entrypoint) as IBaseForm, this.defaultEntity);
    this.setAnaInfoPermission();

    const { path, entrypoint, sectionId, endpoint, permission } = this;

    return {
      ...defaultEntityDataParams,
      path,
      entrypoint,
      sectionId,
      endpoint,
      permission,
    };
  }

  getColumnSetting() {
    return getMappingData(E_Mapping_Data.COLUMN_SETTING, this.entrypoint, this.anaInfo) as (ColDef<CommonEntity> | ColGroupDef<CommonEntity>)[];
  }

  getForm() {
    return this.form;
  }

  getDefaultEntity() {
    return this.defaultEntity;
  }
}
