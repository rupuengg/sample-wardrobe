import Keycloak from 'keycloak-js';
import React, { useEffect, useMemo, useState } from 'react';
import { OAuthContext } from './OAuthContext';

interface Props {
  config: string | Keycloak.KeycloakConfig;
  children: JSX.Element;
}

const Login = (props: Props) => {
  const [isAuthenticated, setAuthenticated] = useState<boolean>(false);
  const [keycloak] = useState(new Keycloak(props.config));
  const [keycloakRefreshCounter, setKeycloakRefreshCounter] = useState(1);

  useEffect(() => {
    const initKeycloak = async () => {
      try {
        const authenticated = await keycloak.init({
          onLoad: 'login-required',
          checkLoginIframe: false,
          pkceMethod: 'S256',
        });

        if (authenticated) {
          if (keycloak?.tokenParsed?.bu_url && !keycloak?.tokenParsed?.bu_url.includes(window.location.hostname) && process.env.NODE_ENV !== 'development') {
            window.location = keycloak.tokenParsed.bu_url;
          }
          setAuthenticated(true);
          setKeycloakRefreshCounter(prevState => prevState + 1);
        } else {
          keycloak.login();
        }
      } catch {
        console.error('Authentication Failed');
      }
    };

    if (!isAuthenticated) {
      initKeycloak();
    }
  }, [isAuthenticated, keycloak]);

  useEffect(() => {
    const refreshToken = async () => {
      try {
        // If token is expired or close to expiring, refresh it
        const refreshed = await keycloak.updateToken(60);
        if (refreshed) {
          setKeycloakRefreshCounter(prevState => prevState + 1);
        }
      } catch (error) {
        console.error('Failed to refresh token:', error);
        keycloak.logout();
        setAuthenticated(false);
      }
    };

    // Check every 30 seconds
    const refreshInterval = setInterval(refreshToken, 30 * 1000);

    // Also handle token expiration event
    keycloak.onTokenExpired = refreshToken;

    return () => {
      clearInterval(refreshInterval);
      keycloak.onTokenExpired = undefined;
    };
  }, [keycloak]);

  const memoKeycloak = useMemo(() => {
    return new Proxy(keycloak, {
      get: (target: Keycloak, prop: keyof Keycloak) => {
        return target[prop];
      },
    });
  }, [keycloak, keycloakRefreshCounter]);

  return isAuthenticated ? <OAuthContext.Provider value={memoKeycloak}>{props.children}</OAuthContext.Provider> : <React.Fragment></React.Fragment>;
};

export { Login };
