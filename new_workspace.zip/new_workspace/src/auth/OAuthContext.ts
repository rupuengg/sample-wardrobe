import Keycloak from 'keycloak-js';
import React from 'react';

const OAuthContext = React.createContext<Keycloak | undefined>(undefined);

export { OAuthContext };
