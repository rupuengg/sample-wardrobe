import React, { useCallback } from 'react';
import { InputField } from 'veronica-ui-component/dist/component/core';
import { IBaseForm } from './BaseForm';

export const TextField: React.FC<IBaseForm> = ({ key, fieldLabel, fieldName, fieldValue, valueType = 'text', error, isSavedClicked, isRequired, onChange }) => {
  const handleChange = useCallback(
    (e: any) => {
      if (onChange && e) onChange(e.currentTarget.name.toString(), e.currentTarget.value.toString());
    },
    [onChange]
  );

  return React.createElement(InputField, {
    key: key,
    label: fieldLabel,
    optional: !isRequired,
    errorMessage: isSavedClicked ? error : '', // Check save button is clicked
    type: valueType, // Type may be text | number
    value: fieldValue?.toString(), // Pass value
    name: fieldName, // Field name is mandatory
    onChange: handleChange,
  });
};
