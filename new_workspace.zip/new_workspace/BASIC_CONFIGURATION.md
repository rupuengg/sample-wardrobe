# Basic Configuration

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## File Structures
```
.
|-- src
|   |-- components
|   |-- connectedComponents
|   |-- constants
|   |-- containers
|   |-- contextAction
|   |-- contexts
|   |-- entities
|   |-- entrypoint
|   |-- helpers
|   |-- forms
|   |-- hooks
|   |-- model
|   |-- layouts
|   |-- mockData
|   |-- model
|   |-- navigations
|   |-- store
|   |-- utils
|   |-- validation
|-- App.tsx
|-- index.tsx
```